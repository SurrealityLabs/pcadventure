/* if_cs.h - Crystal Semiconductor CS8900 network interface header          */
/*                                                                          */
/* Copyright 2000 Crystal Semiconductor Corp.                               */
/*                                                                          */
/*               Last release: v2.08a                                       */
/* Mod level for last release: 08a                                         */


/*
modification history
--------------------
03a,14May99,kml  Added the definition,PKTPG_LOGIC_ADDRESS_FILTER, for Multicast. 
                 Added the definition, RX_CTL_PROM_A, for Promiscuous mode.

02a,31Mar99,kml  Added the definition, BSD43_DRIVER, to tell if BSD interace
                 4.3 is used. By default, BSD 4.4 is used.

01g.25nov97,jla  Added defs to help a page fault with hard resets.
                 HARD_RESET does hard chip resets
                 SOFT_RESET does a softer, kinder sort of reset

01f,11apr97,rks  Added BUF_CFG_ALL_IE define (early tx support)

01e,27mar97,rks	 Moved typedefs back to sysEnet.c so if_cs.h could be included
                 from config.h

01d,24feb97,rks  Moved typedefs back to this file (needed in sysEnet.c)
                 Removed byte-swaped constant defs and now use BYTE_SWAP macro

01c,16dec96,rks  Moved the CS_SOFTC structure definition to sysEnet.c
                 since some of its data types are platform dependent.
                 Added register masks and defintions for _BIG_ENDIAN systems.

01b,16nov96,rks  modified TX_CFG_ALL_IE to NOT set AnyColliE

01a,12jul96,q_s  written.
*/

#ifndef __INCif_csh
#define __INCif_csh

#ifdef __cplusplus
extern "C" {
#endif

/* If BSD 4.3 interface is to be used, enable the BSD43_DRIVE definition */
/* Otherwise, BSD 4.4 will be used by default */
/* #define BSD43_DRIVER */

/*
Macro for byte-swapping required for "big-endian" CPUs.  This macro is defined
based on the _BYTE_ORDER definition in arch.h.  It is the opposite of the
definition for the standard "hton host-to-network conversion" macros
defined in h/netinet/in.h because the CS8900 is "little-endian" by design.
*/

#if _BYTE_ORDER == _LITTLE_ENDIAN
#define BYTE_SWAP(x)    (x)
#else
#define BYTE_SWAP(x)    ((((x) & 0x00ff) << 8) | (((x) & 0xff00) >> 8))
#endif

/* Receive buffer status */

#define RXBUF_FREE          0x0000
#define RXBUF_ALLOCATED     0x0001
#define RXBUF_LOANED        0x0002


/* Defines for hard or soft chip resets */
#define SOFT_RESET 
/* #define HARD_RESET */

/* Config Flags in cs_softc */

#define CFGFLG_MEM_MODE     0x0001
#define CFGFLG_USE_SA       0x0002
#define CFGFLG_IOCHRDY      0x0004
#define CFGFLG_DCDC_POL     0x0008
#define CFGFLG_FDX          0x0010
#define CFGFLG_NOT_EEPROM   0x8000
#define CFGFLG_PROMISC_MODE 0x0200 /* Promiscuous@kml if set, PROMISC mode */


/* Media Type in cs_softc */

#define MEDIA_AUI           0x0001           /* AUI  */
#define MEDIA_10BASE2       0x0002           /* BNC  */
#define MEDIA_10BASET       0x0003           /* RJ45 */


/* IO Port Offsets */

#define PORT_RXTX_DATA     0x0000
#define PORT_RXTX_DATA_1   0x0002
#define PORT_TX_CMD        0x0004
#define PORT_TX_LENGTH     0x0006
#define PORT_ISQ           0x0008
#define PORT_PKTPG_PTR     0x000A
#define PORT_PKTPG_DATA    0x000C
#define PORT_PKTPG_DATA_1  0x000E


/* PacketPage Offsets */

#define PKTPG_EISA_NUM     0x0000
#define PKTPG_PRODUCT_ID   0x0002
#define PKTPG_IO_BASE      0x0020
#define PKTPG_INT_NUM      0x0022
#define PKTPG_MEM_BASE     0x002C
#define PKTPG_EEPROM_CMD   0x0040
#define PKTPG_EEPROM_DATA  0x0042
#define PKTPG_RX_CFG       0x0102
#define PKTPG_RX_CTL       0x0104
#define PKTPG_TX_CFG       0x0106
#define PKTPG_BUF_CFG      0x010A
#define PKTPG_LINE_CTL     0x0112
#define PKTPG_SELF_CTL     0x0114
#define PKTPG_BUS_CTL      0x0116
#define PKTPG_TEST_CTL     0x0118
#define PKTPG_ISQ          0x0120
#define PKTPG_RX_EVENT     0x0124
#define PKTPG_TX_EVENT     0x0128
#define PKTPG_BUF_EVENT    0x012C
#define PKTPG_RX_MISS      0x0130
#define PKTPG_TX_COL       0x0132
#define PKTPG_LINE_ST      0x0134
#define PKTPG_SELF_ST      0x0136
#define PKTPG_BUS_ST       0x0138
#define PKTPG_TX_CMD       0x0144
#define PKTPG_TX_LENGTH    0x0146
#define PKTPG_LOGIC_ADDRESS_FILTER    0x0150  /*@kml*/
#define PKTPG_IND_ADDR     0x0158
#define PKTPG_RX_STATUS    0x0400
#define PKTPG_RX_LENGTH    0x0402
#define PKTPG_RX_FRAME     0x0404
#define PKTPG_TX_FRAME     0x0A00


/* EEPROM Offsets */

#define EEPROM_IND_ADDR_H  0x001C
#define EEPROM_IND_ADDR_M  0x001D
#define EEPROM_IND_ADDR_L  0x001E
#define EEPROM_ISA_CFG     0x001F
#define EEPROM_MEM_BASE    0x0020
#define EEPROM_XMIT_CTL    0x0023
#define EEPROM_ADPTR_CFG   0x0024



/* Chip Identification */

#define EISA_NUM_CRYSTAL    BYTE_SWAP(0x630E)
#define PROD_ID_MASK        BYTE_SWAP(0xE000)
#define PROD_ID_CS8900      BYTE_SWAP(0x0000)
#define PROD_ID_CS8920      BYTE_SWAP(0x4000)
#define PROD_ID_CS892X      BYTE_SWAP(0x6000)
#define PROD_REV_MASK       BYTE_SWAP(0x1F00)


/* Register Numbers */  

#define REG_NUM_MASK       BYTE_SWAP(0x003F)
#define REG_NUM_RX_EVENT   BYTE_SWAP(0x0004)
#define REG_NUM_TX_EVENT   BYTE_SWAP(0x0008)
#define REG_NUM_BUF_EVENT  BYTE_SWAP(0x000C)
#define REG_NUM_RX_MISS    BYTE_SWAP(0x0010)
#define REG_NUM_TX_COL     BYTE_SWAP(0x0012)


/* Self Control Register */ 

#define SELF_CTL_RESET     BYTE_SWAP(0x0040)
#define SELF_CTL_HC1E      BYTE_SWAP(0x2000)
#define SELF_CTL_HCB1      BYTE_SWAP(0x8000)


/* Self Status Register */  

#define SELF_ST_INIT_DONE  BYTE_SWAP(0x0080)
#define SELF_ST_SI_BUSY    BYTE_SWAP(0x0100)
#define SELF_ST_EEP_PRES   BYTE_SWAP(0x0200)
#define SELF_ST_EEP_OK     BYTE_SWAP(0x0400)
#define SELF_ST_EL_PRES    BYTE_SWAP(0x0800)


/* EEPROM Command Register */  

#define EEPROM_CMD_READ    BYTE_SWAP(0x0200)
#define EEPROM_CMD_ELSEL   BYTE_SWAP(0x0400)


/* Bus Control Register */

#define BUS_CTL_USE_SA     BYTE_SWAP(0x0200)
#define BUS_CTL_MEM_MODE   BYTE_SWAP(0x0400)
#define BUS_CTL_IOCHRDY    BYTE_SWAP(0x1000)
#define BUS_CTL_INT_ENBL   BYTE_SWAP(0x8000)
#define BUS_CTL_INT_DIS_MASK BYTE_SWAP(0x7FFF)


/* Bus Status Register */  

#define BUS_ST_TX_BID_ERR  BYTE_SWAP(0x0080)
#define BUS_ST_RDY4TXNOW   BYTE_SWAP(0x0100)


/* Line Control Register */ 

#define LINE_CTL_RX_ON     BYTE_SWAP(0x0040)
#define LINE_CTL_TX_ON     BYTE_SWAP(0x0080)
#define LINE_CTL_AUI_ONLY  BYTE_SWAP(0x0100)
#define LINE_CTL_10BASET   BYTE_SWAP(0x0000)


/* Test Control Register */  

#define TEST_CTL_DIS_LT    BYTE_SWAP(0x0080)
#define TEST_CTL_ENDEC_LP  BYTE_SWAP(0x0200)
#define TEST_CTL_AUI_LOOP  BYTE_SWAP(0x0400)
#define TEST_CTL_DIS_BKOFF BYTE_SWAP(0x0800)
#define TEST_CTL_FDX       BYTE_SWAP(0x4000)


/* Receiver Configuration Register */  

#define RX_CFG_SKIP        BYTE_SWAP(0x0040)
#define RX_CFG_RX_OK_IE    BYTE_SWAP(0x0100)
#define RX_CFG_CRC_ERR_IE  BYTE_SWAP(0x1000)
#define RX_CFG_RUNT_IE     BYTE_SWAP(0x2000)
#define RX_CFG_X_DATA_IE   BYTE_SWAP(0x4000)
#define RX_CFG_ALL_IE      BYTE_SWAP(0x7100)


/* Receiver Event Register */  

#define RX_EVENT_DRIBBLE   BYTE_SWAP(0x0080)
#define RX_EVENT_RX_OK     BYTE_SWAP(0x0100)
#define RX_EVENT_IND_ADDR  BYTE_SWAP(0x0400)
#define RX_EVENT_BCAST     BYTE_SWAP(0x0800)
#define RX_EVENT_CRC_ERR   BYTE_SWAP(0x1000)
#define RX_EVENT_RUNT      BYTE_SWAP(0x2000)
#define RX_EVENT_X_DATA    BYTE_SWAP(0x4000)


/* Receiver Control Register */ 
#define RX_CTL_PROM_A      BYTE_SWAP(0x0080)  /* Promiscuous@kml*/
#define RX_CTL_RX_OK_A     BYTE_SWAP(0x0100)
#define RX_CTL_MCAST_A     BYTE_SWAP(0x0200)
#define RX_CTL_IND_A       BYTE_SWAP(0x0400)
#define RX_CTL_BCAST_A     BYTE_SWAP(0x0800)
#define RX_CTL_CRC_ERR_A   BYTE_SWAP(0x1000)
#define RX_CTL_RUNT_A      BYTE_SWAP(0x2000)
#define RX_CTL_X_DATA_A    BYTE_SWAP(0x4000)


/* Transmit Configuration Register */  

#define TX_CFG_LOSS_CRS_IE BYTE_SWAP(0x0040)
#define TX_CFG_SQE_ERR_IE  BYTE_SWAP(0x0080)
#define TX_CFG_TX_OK_IE    BYTE_SWAP(0x0100)
#define TX_CFG_OUT_WIN_IE  BYTE_SWAP(0x0200)
#define TX_CFG_JABBER_IE   BYTE_SWAP(0x0400)
#define TX_CFG_16_COLL_IE  BYTE_SWAP(0x8000)
#define TX_CFG_ALL_IE      BYTE_SWAP(0x87C0)


/* Transmit Event Register */  

#define TX_EVENT_LOSS_CRS  BYTE_SWAP(0x0040)
#define TX_EVENT_SQE_ERR   BYTE_SWAP(0x0080)
#define TX_EVENT_TX_OK     BYTE_SWAP(0x0100)
#define TX_EVENT_OUT_WIN   BYTE_SWAP(0x0200)
#define TX_EVENT_JABBER    BYTE_SWAP(0x0400)
#define TX_EVENT_COLL_MASK BYTE_SWAP(0x7800)
#define TX_EVENT_16_COLL   BYTE_SWAP(0x8000)


/* Transmit Command Register */  

#define TX_CMD_START_5     BYTE_SWAP(0x0000)
#define TX_CMD_START_381   BYTE_SWAP(0x0080)
#define TX_CMD_START_1021  BYTE_SWAP(0x0040)
#define TX_CMD_START_ALL   BYTE_SWAP(0x00C0)
#define TX_CMD_FORCE       BYTE_SWAP(0x0100)
#define TX_CMD_ONE_COLL    BYTE_SWAP(0x0200)
#define TX_CMD_NO_CRC      BYTE_SWAP(0x1000)
#define TX_CMD_NO_PAD      BYTE_SWAP(0x2000)


/* Buffer Configuration Register */  

#define BUF_CFG_SW_INT     BYTE_SWAP(0x0040)
#define BUF_CFG_RDY4TX_IE  BYTE_SWAP(0x0100)
#define BUF_CFG_TX_UNDR_IE BYTE_SWAP(0x0200)
#define BUF_CFG_MISOFLO_IE BYTE_SWAP(0x2000)
#define BUF_CFG_COLOFLO_IE BYTE_SWAP(0x1000)
#define BUF_CFG_ALL_IE     BYTE_SWAP(0x3340)

/* Buffer Event Register */  

#define BUF_EVENT_SW_INT   BYTE_SWAP(0x0040)
#define BUF_EVENT_RDY4TX   BYTE_SWAP(0x0100)
#define BUF_EVENT_TX_UNDR  BYTE_SWAP(0x0200)
#define BUF_EVENT_RX_MISS  BYTE_SWAP(0x0400)


/* ISA Configuration from EEPROM */  

#define ISA_CFG_IRQ_MASK   BYTE_SWAP(0x000F)
#define ISA_CFG_USE_SA     BYTE_SWAP(0x0080)
#define ISA_CFG_IOCHRDY    BYTE_SWAP(0x0100)
#define ISA_CFG_MEM_MODE   BYTE_SWAP(0x8000)


/* Memory Base from EEPROM */  

#define MEM_BASE_MASK      BYTE_SWAP(0xFFF0)


/* Adpater Configuration from EEPROM */  

#define ADPTR_CFG_MEDIA    BYTE_SWAP(0x0060)
#define ADPTR_CFG_10BASET  BYTE_SWAP(0x0020)
#define ADPTR_CFG_AUI      BYTE_SWAP(0x0040)
#define ADPTR_CFG_10BASE2  BYTE_SWAP(0x0060)
#define ADPTR_CFG_DCDC_POL BYTE_SWAP(0x0080)


/* Transmission Control from EEPROM */  

#define XMIT_CTL_FDX       BYTE_SWAP(0x8000)


#ifdef __cplusplus
}
#endif

#endif  /* __INCif_csh */
