/* sysEnet.c - pc386/486 system-dependent module for CS8900 Ethernet driver */
/*                                                                          */
/* Copyright 2000 Crystal Semiconductor Corp.                               */
/*                                                                          */
/*               Last release: v2.08a                                       */
/* Mod level for last release: 08a                                          */


/*
MODIFICATION HISTORY
--------------------
v2.07a,09Oct00, kml  -Padded 2 bytes in RxBuf to make IP header in the WORD boundary.
                     -Fixed the bug that if CPU type is MIPS, an extra byte is sent
					  when an odd-aligned buffer and odd length data are passed.
 
v2.04a,24Sep99, kml  -Take out IFF_MULTICAST in BSD43 mode because not supported.
                     -Change receiving buffer size from 32 to 64.
                     -Correction: If the memory address parameter is zero, the CS8900 operates in the
                      mode specified by EEPROM or the Config Flag parameter.

02a,31Mar99,kml  converted to BSD44 driver, merge from SENS

10f,11apr97,rks  Added variables for "early tx" support to CS_SOFTC structure
                 (TxUnderruns, TotalTxUnderruns, TxStartCMD, and TxLenght.

10e,05apr97,rks  Added CS_MAX_NET_JOBS and STRESS_TESTING defines.

10d,11mar97,rks  Moved some typedefs to this file so "config.h" could include
                 "if_cs.h" easily. 

01c,25feb97,rks  Changed SysEnetAddrGet parameters to Unit, IA addr pointer

01b,31jan97,rks  Modified sysEnetAddrGet to take Ethernet address from EEPROM
                 or from the csEnetAddr array based on the value of the 
                 GET_ENET_ADDR_FROM_BOARD flag.
		 
01a,16dec96,rks  Written (using routines originally written by q_s in "if_cs.c".
*/


/*
DESCRIPTION

This module provides pc386/pc486 board-specific routines and data types require
by the Crystal Semiconductor CS8900 Ethernet network interface driver.  It 
implements five routines called from the "if_cs.c" main driver module:

* sysEnetGetConfig( CS_SOFTC *pCS )
This routine takes configuration parameters not specifed to csAttach(), if any,
from non-volatile storage (e.g. an attached EEPROM) and puts them in the 
cs_softc structure. If all the parameters were specified to csAttach(), then 
this routine does not attempt to read the EEPROM.

* sysEnetAddrGet( int Unit, unsigned char *pAddr )
This routine obtains the Ethernet MAC address from non-volatile storage or from 
the "csEnetAddr" array defined in sysEnet.c and saves it in the arpcom 
structure.

* sysEnetHWInit( CS_SOFTC *pCS )
This routine uses global variables in the cs_softc structure to configure the 
adapter for the board-specific IO circuitry and supported media types.

* sysEnetIntEnable( CS_SOFTC *pCS )
This routine enables the interrupt used by the CS8900 at the system level. 
 
* sysEnetIntDisable( CS_SOFTC *pCS )
This routine disables the interrupt used by the CS8900 at the system level.  It 
is not currently used by this driver.

*/



/* DEFINES */

/* ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ *
 * Driver Configuration Defines                                            *
 * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ */

/* Maximum number of CS8900 chips supported */

#define CS_MAX_NUM_UNITS        1 


/* Maximum number of receive buffers */ 
     
#define CS_NUM_RX_BUFFERS       64


/* Maximum number of elements (pointers) in local TX and RX queues */

#define CS_MAX_QUEUE   320  /* MAX_MBUF (1500 - defined in mbuf.h) */



/* Set STRESS_TESTING TRUE to suppress excessive debug messages */

#define STRESS_TESTING 		TRUE


/* Initial TXStartCMD (number of bytes to buffer before CS8900 starts the TX */
/* Select one of: [TX_CMD_START_5 | TX_CMD_START_381 | TX_CMD_START_1021 | 
 * TX_CMD_START_ALL ] */

#define CS_INITIAL_START_CMD	TX_CMD_START_5


/* Number of underruns with current TXStartCMD before TXStartCMD is set to next value */

#define CS_TX_UNDRUN_TRHSHOLD   3 


/* BSP type supported by this driver */  

#define CS_BSP_TYPE	"i[3|4]86"          


/* ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ *
 * Miscellaneous and BSP-specific defines                                  *
 * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ */


/* Define a unique cluster type */

#define MC_LOANED	5       


/* 
This flag determines if the Ethernet address is taked from EEPROM or from
the csEnetAddr array defined below.  Define as 0 to take the Ethernet address
from csEnetAddr.  WARNING! The Ethernet address must be unique for each Ethernet
device on the network.
*/

#define GET_ENET_ADDR_FROM_BOARD  1


/* 
These macros are used to communicate with the CS8900 in iX86 IO space.  For the 
pc386/pc486 BSPs, they just call system routines provided by VxWorks/PCX86 for 
IO space access.  They need to be replaced with system calls appropriate for 
VxWorks on other architectures. 
*/
 
/* Macros used to provide platform independence for IO accesses */
#define SYS_ENET_OUT_WORD(port, value)	        sysOutWord((port), (value))
#define SYS_ENET_IN_WORD(port)			sysInWord(port)
#define SYS_ENET_IN_BYTE(port)			sysInByte(port)





/* TYPEDEFS */

/* Individual Address (Ethernet Address) */
typedef struct
{
   USHORT word[3];
} IA, *PIA;


/* Receive Frame Buffer */
struct rxbuf
{
   struct rxbuf *pNext;
   UCHAR         Status;
   UCHAR         RefCount;
   USHORT        Length;
   USHORT        PAD_ME; /*IP header must be in the WORD boundary. */
   /* Ethernet header has 14 bytes. Pad 2 bytes to make IP header in the WORD boundary.*/ 
   UCHAR         Data[SIZEOF_ETHERHEADER+ETHERMTU];
};

typedef struct rxbuf RXBUF, *PRXBUF;
typedef struct mbuf TXBUF, *PTXBUF, *PMBUF;



typedef struct 
{
    void  *Queue[CS_MAX_QUEUE+1];
    int    Head;
    int    Tail;   

} CIR_QUEUE; 


typedef USHORT IOADDR;    /* IO space address is 16-bit */


/* Driver control structure for a single unit */

typedef struct
{
   struct     arpcom ArpCom;
   IOADDR     IOAddr;           /* This data type is platform dependent */
   USHORT     IntLevel;
   USHORT     IntVector;
   USHORT    *pPacketPage;      
   USHORT     MediaType;
   USHORT     ConfigFlags;
   PRXBUF     pFreeRxBuff;
   BOOL       InMemoryMode;
   BOOL       Resetting;
   USHORT     RxDepth;
   USHORT     MaxRxDepth;
   USHORT     MaxTxDepth;
   USHORT     TxQueueDepth;
   USHORT     MaxTxQueueDepth;
   UINT       LoanCount;
   UINT	      Rdy4TxInts;
   PTXBUF     pTxFrameChain;
   BOOL       TxInProgress;
   BOOL       InISR;
   CIR_QUEUE *pTxBuffFreeList;
   CIR_QUEUE *pRxBuffProcessList;
   CIR_QUEUE *pTxQueue;
   UINT	      NetJobDepth;
   USHORT     TxStartCMD;
   USHORT     TxUnderruns;
   UINT       TotalTxUnderruns;
   UINT       TxLength;
} CS_SOFTC;




/* EXTERNALS */

IMPORT UINT sysVectorIRQ0;           /* vector for IRQ0 */




/* LOCALS */

unsigned char csEnetAddr [6] = { 0x08, 0x00, 0x20, 0x74, 0x80, 0xa7 };

/* Instance variables */
LOCAL CS_SOFTC cs_softc[CS_MAX_NUM_UNITS];  
CIR_QUEUE TxBuffFreeList;
CIR_QUEUE RxBuffProcessList;
CIR_QUEUE TxQueue;





/* FORWARD DECLARATIONS */
LOCAL STATUS sysEnetGetConfig( CS_SOFTC *pCS );
LOCAL STATUS sysEnetAddrGet( int Unit, unsigned char *pAddr );
LOCAL void sysEnetHWInit( CS_SOFTC *pCS );
LOCAL STATUS sysEnetIntEnable( CS_SOFTC *pCS );
/* Not required for this BSP
LOCAL STATUS sysEnetIntDisable( CS_SOFTC *pCS );
*/

/* sub-routines for above functions */

LOCAL STATUS csGetUnspecifiedParms( CS_SOFTC *pCS );
LOCAL STATUS csValidateParms( CS_SOFTC *pCS );
LOCAL STATUS csReadEEPROM( CS_SOFTC *pCS, USHORT Offset, USHORT *pValue );

#ifdef TRUE
/* These routines defined in if_cs.c but available for use here. */
/* Ifdef FALSE if none are called from this module */
#define DECLARED_IN_SYS_ENET
LOCAL USHORT csReadPacketPage( CS_SOFTC *pCS, USHORT Offset );
LOCAL void csWritePacketPage( CS_SOFTC *pCS, USHORT Offset, USHORT Value );
#endif







/* ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ *
 * pc386/486 Board-specific routines                                       *
 * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ */

#define MAXLOOP       0x8888  /* Delay loop counter  */        


/******************************************************************************
*
* sysEnetGetConfig - Get any CS8900 parameters not specifed to csAttach
*
* This routine gets parameters that were not specifed to csAttach() from an 
* EEPROM, if used, and puts them in the cs_softc structure.  If all the 
* parameters were specified to csAttach(), then this routine does not attempt 
* to read the EEPROM.
*
* RETURNS: OK or ERROR
*
*/

LOCAL STATUS sysEnetGetConfig( CS_SOFTC *pCS )
{
	/* Get parameters, which were not specified, from the EEPROM */
   if ( csGetUnspecifiedParms(pCS) == ERROR )
      return ERROR;

	/* Verify that parameters are valid */
   if ( csValidateParms(pCS) == ERROR )
      return ERROR;

   /* If memory address was specified but configuration flags were not */
   if ( pCS->pPacketPage !=0 )
      pCS->ConfigFlags |= CFGFLG_MEM_MODE;  /* Implictly set memory mode */

   /* If the interrupt vector was not specified then derive it */
   if ( pCS->IntVector == 0 )
      pCS->IntVector = sysVectorIRQ0 + pCS->IntLevel;

	return OK;

}




/*******************************************************************************
*
* sysEnetAddrGet - saves the Ethernet address to the arpcom structure
*
* If a pointer to an Ethernet address string was passed-in to the csAttach()
* routine, then this routine coverts the address string to an Ethernet address
* and saves it in the arpcom structure.  If an Ethernet address string was
* not passed-in, then the Ethernet address is read from the EEPROM and saved
* in the arpcom structure.
*
* RETURNS: OK or ERROR
*
*/

LOCAL STATUS sysEnetAddrGet( int Unit, unsigned char *pAddr )
{
   USHORT SelfStatus;
   PIA pIA;
   FAST CS_SOFTC *pCS;

   /* We only support one unit */
   if ( Unit >= CS_MAX_NUM_UNITS )
      return ERROR;

   pCS = &cs_softc[Unit];

   /* Setup pointer for the Ethernet address */
   pIA = (PIA)pAddr;

   /* If the Ethernet address in EEPROM */
   if ( GET_ENET_ADDR_FROM_BOARD )   /* defined in config.h */
   {
      /* Verify that the EEPROM is present and OK */
      SelfStatus = csReadPacketPage( pCS, PKTPG_SELF_ST );
      if ( !((SelfStatus & SELF_ST_EEP_PRES) && (SelfStatus & SELF_ST_EEP_OK)))
      {
         printf("\ncs0 - EEPROM is missing or bad\n");
         return ERROR;
      }

      /* Get Ethernet address from the EEPROM */
      if ( csReadEEPROM(pCS,EEPROM_IND_ADDR_H,&pIA->word[0]) == ERROR )
         return ERROR;
      if ( csReadEEPROM(pCS,EEPROM_IND_ADDR_M,&pIA->word[1]) == ERROR )
         return ERROR;
      if ( csReadEEPROM(pCS,EEPROM_IND_ADDR_L,&pIA->word[2]) == ERROR )
         return ERROR;
   }
   else  /* Use Ethernet Address defined in csEnetAddr */
      bcopyBytes ((char *) csEnetAddr, (char *) pIA, 6);

   return OK;
}




/*******************************************************************************
*
* sysEnetHWInit - configure the adapter for board-specific IO and media support
*
* This routine uses global variables in the cs_softc structure to configure the 
* adapter for the board-specific IO circuitry and media types supported.
*        
* RETURNS: Nothing
*         
*/

LOCAL void sysEnetHWInit( CS_SOFTC *pCS )
{
   USHORT BusCtl;
   USHORT SelfCtl;

   /* If memory mode is enabled */
   if ( pCS->ConfigFlags & CFGFLG_MEM_MODE )
   {
      /* If external logic is present for address decoding */
      if ( csReadPacketPage(pCS,PKTPG_SELF_ST) & SELF_ST_EL_PRES )
      {
         /* Program the external logic to decode address bits SA20-SA23 */
         csWritePacketPage( pCS, PKTPG_EEPROM_CMD,
               ((UINT)(pCS->pPacketPage)>>20) | EEPROM_CMD_ELSEL );
      }

      /* Setup chip for memory mode */
      csWritePacketPage( pCS, PKTPG_MEM_BASE, (UINT)(pCS->pPacketPage)&0xFFFF );
      csWritePacketPage( pCS, PKTPG_MEM_BASE+2, (UINT)(pCS->pPacketPage)>>16 );
      BusCtl = BUS_CTL_MEM_MODE;
      if ( pCS->ConfigFlags & CFGFLG_USE_SA )
         BusCtl |= BUS_CTL_USE_SA;
      csWritePacketPage( pCS, PKTPG_BUS_CTL, BusCtl );

      /* We are in memory mode now! */
      pCS->InMemoryMode = TRUE;
   }

   /* If IOCHRDY is enabled then clear the bit in the BusCtl register */
   BusCtl = csReadPacketPage( pCS, PKTPG_BUS_CTL );
   if ( pCS->ConfigFlags & CFGFLG_IOCHRDY )
      csWritePacketPage( pCS, PKTPG_BUS_CTL, BusCtl & ~BUS_CTL_IOCHRDY );
   else
      csWritePacketPage( pCS, PKTPG_BUS_CTL, BusCtl | BUS_CTL_IOCHRDY );

   /* Set the Line Control register to match the media type */
   if ( pCS->MediaType == MEDIA_10BASET )
      csWritePacketPage( pCS, PKTPG_LINE_CTL, LINE_CTL_10BASET );
   else
      csWritePacketPage( pCS, PKTPG_LINE_CTL, LINE_CTL_AUI_ONLY );

   /* Set the BSTATUS/HC1 pin to be used as HC1 */
   /* HC1 is used to enable the DC/DC converter */
   SelfCtl = SELF_CTL_HC1E;

   /* If the media type is 10Base2 */
   if ( pCS->MediaType == MEDIA_10BASE2 )
   {
      /* Enable the DC/DC converter */
      /* If the DC/DC converter has a low enable */
      if ( (pCS->ConfigFlags & CFGFLG_DCDC_POL) == 0 )
         /* Set the HCB1 bit, which causes the HC1 pin to go low */
         SelfCtl |= SELF_CTL_HCB1;
   }
   else  /* Media type is 10BaseT or AUI */
   {
      /* Disable the DC/DC converter */
      /* If the DC/DC converter has a high enable */
      if ( (pCS->ConfigFlags & CFGFLG_DCDC_POL) != 0 )
         /* Set the HCB1 bit, which causes the HC1 pin to go low */
         SelfCtl |= SELF_CTL_HCB1;
   }
   csWritePacketPage( pCS, PKTPG_SELF_CTL, SelfCtl );

   /* If media type is 10BaseT */
   if ( pCS->MediaType == MEDIA_10BASET )
   {
      /* If full duplex mode then set the FDX bit in TestCtl register */
      if ( pCS->ConfigFlags & CFGFLG_FDX )
         csWritePacketPage( pCS, PKTPG_TEST_CTL, TEST_CTL_FDX );
   }

}



/******************************************************************************
*
* sysEnetIntEnable - enable CS8900 interrupts at the system level
*
* This routine enables the interrupt used by the CS8900 at the system level.  
* For the i386/i486 BSPs, this is done by making the system call 
* sysIntEnablePIC to enable the CS8900's interrupt at the 8259 PIC.
*
* RETURNS: OK or ERROR
*/

LOCAL STATUS sysEnetIntEnable( CS_SOFTC *pCS )
{
   /* Enable interrupt at the 8259 PIC */
   if ( sysIntEnablePIC(pCS->IntLevel) == ERROR )
   {
      return ERROR;
   }
   return OK;
}



/******************************************************************************
*
* sysEnetIntDisable - disable CS8900 interrupts at the system level
*
* This routine disables the interrupt used by the CS8900 at the system level.  
* For the i386/i486 BSPs, this is done by making the system call 
* sysIntDisablePIC to disable the CS8900's interrupt at the 8259 PIC.
*
* NOTE: This routine is not currently required by the CS8900 driver.
*
* RETURNS: OK or ERROR
*/

/* Not required for this BSP 

LOCAL STATUS sysEnetIntDisable( CS_SOFTC *pCS )
{
   
   if ( sysIntDisablePIC(pCS->IntLevel) == ERROR )
   {
      return ERROR;
   }
   return OK;
}

*/




/* ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ *
 * Support routines for the above board-specific routines                      *
 * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ */


/*******************************************************************************
*
* csGetUnspecifiedParms
*
*
*/

LOCAL STATUS csGetUnspecifiedParms( CS_SOFTC *pCS )
{
   USHORT SelfStatus;
   USHORT ISAConfig;
   USHORT MemBase;
   USHORT AdapterConfig;
   USHORT XmitCtl;

   /* If all of these parameters were specified */
   if ( pCS->ConfigFlags!=0 && pCS->pPacketPage!=NULL && pCS->IntLevel!=0 &&
         pCS->MediaType!=0 )
      return OK;  /* Don't need to get anything from the EEPROM */

   /* Verify that the EEPROM is present and OK */
   SelfStatus = csReadPacketPage( pCS, PKTPG_SELF_ST );
   if ( !((SelfStatus & SELF_ST_EEP_PRES) && (SelfStatus & SELF_ST_EEP_OK)) )
   {
      printf("\ncs0 - EEPROM is missing or bad\n");
      return ERROR;
   }

   /* Get ISA configuration from the EEPROM */
   if ( csReadEEPROM(pCS,EEPROM_ISA_CFG,&ISAConfig) == ERROR )
      return ERROR;

   /* Get adapter configuration from the EEPROM */
   if ( csReadEEPROM(pCS,EEPROM_ADPTR_CFG,&AdapterConfig) == ERROR )
      return ERROR;

   /* Get transmission control from the EEPROM */
   if ( csReadEEPROM(pCS,EEPROM_XMIT_CTL,&XmitCtl) == ERROR )
      return ERROR;

   /* If the configuration flags were not specified */
   if ( pCS->ConfigFlags == 0 )
   {
      /* Copy the memory mode flag */
      if ( ISAConfig & ISA_CFG_MEM_MODE )
         pCS->ConfigFlags |= CFGFLG_MEM_MODE;

      /* Copy the USE_SA flag */
      if ( ISAConfig & ISA_CFG_USE_SA )
         pCS->ConfigFlags |= CFGFLG_USE_SA;

      /* Copy the IO Channel Ready flag */
      if ( ISAConfig & ISA_CFG_IOCHRDY )
         pCS->ConfigFlags |= CFGFLG_IOCHRDY;

      /* Copy the DC/DC Polarity flag */
      if ( AdapterConfig & ADPTR_CFG_DCDC_POL )
         pCS->ConfigFlags |= CFGFLG_DCDC_POL;

      /* Copy the Full Duplex flag */
      if ( XmitCtl & XMIT_CTL_FDX )
         pCS->ConfigFlags |= CFGFLG_FDX;
   }

   /* If the PacketPage pointer was not specified */
   if ( pCS->pPacketPage == NULL )
   {
      /* If memory mode is enabled */
      if ( pCS->ConfigFlags & CFGFLG_MEM_MODE )
      {
         /* Get the memory base address from EEPROM */
         if ( csReadEEPROM(pCS,EEPROM_MEM_BASE,&MemBase) == ERROR )
            return ERROR;

         MemBase &= MEM_BASE_MASK;  /* Clear unused bits */

         /* Setup the PacketPage pointer */
         pCS->pPacketPage = (USHORT *)(((ULONG)MemBase)<<8);
      }
   }

   /* If the interrupt level was not specified */
   if ( pCS->IntLevel == 0 )
   {
      /* Get the interrupt level from the ISA config */
      pCS->IntLevel = ISAConfig & ISA_CFG_IRQ_MASK;
      if ( pCS->IntLevel == 3 )
         pCS->IntLevel = 5;
      else
         pCS->IntLevel += 10;
   }

   /* If the media type was not specified */
   if ( pCS->MediaType == 0 )
   {
      switch( AdapterConfig & ADPTR_CFG_MEDIA )
      {
         case ADPTR_CFG_AUI:
            pCS->MediaType = MEDIA_AUI;
            break;
         case ADPTR_CFG_10BASE2:
            pCS->MediaType = MEDIA_10BASE2;
            break;
         case ADPTR_CFG_10BASET:
         default:
            pCS->MediaType = MEDIA_10BASET;
            break;
      }
   }

   return OK;
}




/*******************************************************************************
*
* csValidateParms
*
* This routine verifies that the memory address, interrupt level and media
* type are valid.  If any of these parameters are invalid, then and error
* message is printed and ERROR is returned.
*
*/

LOCAL STATUS csValidateParms( CS_SOFTC *pCS )
{
   int MemAddr;

   MemAddr = (int)(pCS->pPacketPage);

   if ( (MemAddr & 0x000FFF) != 0 )
   {
      printf("\ncs0 - Memory address (0x%X) must start on a 4K boundry\n",
            MemAddr );
      return ERROR;
   }

   if ( MemAddr > 0xFFF000 )
   {
      printf("\ncs0 - Memory address (0x%X) is too large\n", MemAddr );
      return ERROR;
   }

   if ( !(pCS->IntLevel==5 || pCS->IntLevel==10 || pCS->IntLevel==11 ||
         pCS->IntLevel==12) )
   {
      printf("\ncs0 - Interrupt level (%d) is invalid\n", pCS->IntLevel );
      return ERROR;
   }

   if ( !(pCS->MediaType==MEDIA_AUI || pCS->MediaType==MEDIA_10BASE2 ||
         pCS->MediaType==MEDIA_10BASET) )
   {
      printf("\ncs0 - Media type (%d) is invalid\n", pCS->MediaType );
      return ERROR;
   }

   return OK;
}




/*******************************************************************************
*
* csReadEEPROM
*
* This routine reads a word from the EEPROM at the specified offset.
*
*/

LOCAL STATUS csReadEEPROM( CS_SOFTC *pCS, USHORT Offset, USHORT *pValue )
{
   int x;

   /* Ensure that the EEPROM is not busy */
   for ( x=0; x < MAXLOOP; x++ )
      if ( !(csReadPacketPage(pCS,PKTPG_SELF_ST)&SELF_ST_SI_BUSY) )
         break;
   if ( x == MAXLOOP )
   {
      printf("\ncs0 - Can not read from EEPROM\n");
      return ERROR;
   }

   /* Issue the command to read the offset within the EEPROM */
   csWritePacketPage( pCS, PKTPG_EEPROM_CMD, Offset | EEPROM_CMD_READ );

   /* Wait until the command is completed */
   for ( x=0; x<MAXLOOP; x++ )
      if ( !(csReadPacketPage(pCS,PKTPG_SELF_ST)&SELF_ST_SI_BUSY) )
         break;
   if ( x == MAXLOOP )
   {
      printf("\ncs0 - Can not read from EEPROM\n");
      return ERROR;
   }

   /* Get the EEPROM data from the EEPROM Data register */
   *pValue = csReadPacketPage( pCS, PKTPG_EEPROM_DATA );

   return OK;
}








