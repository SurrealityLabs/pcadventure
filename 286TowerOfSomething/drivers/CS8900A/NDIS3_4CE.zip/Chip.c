//---------------------------------------------------------------------------
//
//  Copyright (C) 1996-1997. Unpublished Work of Crystal Semiconductor Corp.
//  All Rights Reserved.
//
//  THIS WORK IS AN UNPUBLISHED WORK AND CONTAINS CONFIDENTIAL,
//  PROPRIETARY AND TRADE SECRET INFORMATION OF CRYSTAL SEMICONDUCTOR.
//  ACCESS TO THIS WORK IS RESTRICTED TO (I) CRYSTAL SEMICONDUCTOR EMPLOYEES
//  WHO HAVE A NEED TO KNOW TO PERFORM TASKS WITHIN THE SCOPE OF THEIR
//  ASSIGNMENTS  AND (II) ENTITIES OTHER THAN CRYSTAL SEMICONDUCTOR WHO
//  HAVE ENTERED INTO  APPROPRIATE LICENSE AGREEMENTS.  NO PART OF THIS
//  WORK MAY BE USED, PRACTICED, PERFORMED, COPIED, DISTRIBUTED, REVISED,
//  MODIFIED, TRANSLATED, ABRIDGED, CONDENSED, EXPANDED, COLLECTED,
//  COMPILED,LINKED,RECAST, TRANSFORMED, ADAPTED IN ANY FORM OR BY ANY
//  MEANS,MANUAL, MECHANICAL, CHEMICAL, ELECTRICAL, ELECTRONIC, OPTICAL,
//  BIOLOGICAL, OR OTHERWISE WITHOUT THE PRIOR WRITTEN PERMISSION AND
//  CONSENT OF CRYSTAL SEMICONDUCTOR . ANY USE OR EXPLOITATION OF THIS WORK
//  WITHOUT THE PRIOR WRITTEN CONSENT OF CRYSTAL SEMICONDUCTOR  COULD
//  SUBJECT THE PERPETRATOR TO CRIMINAL AND CIVIL LIABILITY.
//
//---------------------------------------------------------------------------

/* vc20init.c  - CS8920 VChip Initialization */


#include "ends4isa.h"
#include "cshrd.h"


#ifndef WIN_CE
#pragma NDIS_INIT_FUNCTION(VchipGetConfig)
#pragma NDIS_INIT_FUNCTION(VchipStartup)
#endif

/* Vchip Global variables.  WARNING: In some environments, these variables */
/* will be truncated from the data segment after initialization time!      */

#define MAX_CHIPS 4   // should I be using CHIP_COUNT in vchip.h ????

DWORD IOBaseList[MAX_CHIPS] = {0,0,0,0};
extern int EEPROM_NOT_FOUND;


/******************************************************************************
*
* VchipGetConfig()
*
* Caller must fill in pChip->SerialNumber. SerialNumber of -1 means first
* use first available chip found.
*
******************************************************************************/

WORD VchipGetConfig( PCHIP pChip)
{
   PORT IOBase;
   WORD Result;
   WORD SelfStatus;
   WORD AdapterConfig;
   WORD AutoNegControl;
   DWORD step;


 
  // 
  // The steps count down inorder to produce "tighter" code.
  //
  for (step=8,Result=SUCCESS; step && Result==SUCCESS; step--) {

   switch (step) {
   case 8:
        
        IOBase=pChip->Config.IOBase;
        /* Read the self status register */
        SelfStatus = ReadPacketPage( pChip, IOBase, CRYSTAL_SELF_STATUS_REGISTER );

   		/* If CS8900 or CS8920 with PnP disabled */
   		if ( (pChip->Config.ChipType == CS8900_PROD_ID_LOW) ||
   		     ( (pChip->Config.ChipType == CS89xx_PROD_ID_LOW) &&
   		       (SelfStatus & CRYSTAL_SSR_PNP_DISABLE) ) )

   		{
   		   Result = GetConfigFromEEPROM( pChip );
   		}
   		else  /* Plug and Play is enabled */
   		{
   		   Result = GetConfigFromPnP( pChip );
   		}
   break;
   case 7:
   	   	/* Read the Ethernet address from the EEPROM */
   	   	Result = ReadEEPROM( pChip, EE_ADDRESS_OEM_IA_W1,
   	   	      &pChip->Config.EthernetAddr.Part[0] );
   break;
   case 6:
   		Result = ReadEEPROM( pChip, EE_ADDRESS_OEM_IA_W2,
   		      &pChip->Config.EthernetAddr.Part[1] );
   break;
   case 5:
   		Result = ReadEEPROM( pChip, EE_ADDRESS_OEM_IA_W3,
   		      &pChip->Config.EthernetAddr.Part[2] );
   break;
   case 4:
   	   	Result = ReadEEPROM( pChip, EE_ADDRESS_VRHC, &AdapterConfig );
   break;
   case 3:
   	   	/* Get media type from the adapter configuration */
   	   	pChip->Config.RequestedMediaType = ((AdapterConfig&EE_MEDIA_MASK)>>
   	   	      EE_MEDIA_SHIFT);
   break;
   case 2:
   		/* Read auto-negotiation control from the EEPROM */
   		Result = ReadEEPROM( pChip, EE_ADDRESS_CTL, &AutoNegControl );
   break;
   case 1:
        Result=AddIOBase(IOBase);
   break;
   } /* endswitch */
  } /* endfor */
  
  
  /* Get duplex mode from auto-negotiation control */
  if ( AutoNegControl & EE_AUTONEG_ENABLE )
     pChip->Config.RequestedDuplexMode = DUPLEX_AUTO_NEGOTIATE;
  else if ( AutoNegControl & EE_FORCE_FDX )
     pChip->Config.RequestedDuplexMode = DUPLEX_FULL;
  else  /* Force half duplex */
     pChip->Config.RequestedDuplexMode = DUPLEX_HALF;

  pChip->Config.MediaSpeed    = 10;
  pChip->Config.BusType       = BUS_ISA;
  pChip->Config.BusSlot       = (WORD)UNSPECIFIED;
  pChip->Config.MaxTxCount    = CRYSTAL_TRANSMIT_PACKET_MAXIMUM;
  pChip->Config.LookAheadSize = (WORD)UNSPECIFIED;
  pChip->Config.Flags         = 0;
  pChip->Config.CurrentDuplexMode = DUPLEX_NONE;
  pChip->Config.DetectedMediaType = MEDIA_NONE;

  return CHIP_SUCCESS;


}


/******************************************************************************
*
* GetConfigFromPnP()
*
******************************************************************************/

WORD GetConfigFromPnP( PCHIP pChip )
{
   PORT IOBase;
   BYTE Byte;
   union
   {
      WORD Word;
      BYTE Byte[2];
   } Value;

   IOBase = pChip->Config.IOBase;

   /* Read memory base address from PnP registers */
   NdisRawWritePortUshort( (PORT)(IOBase+CRYSTAL_ADDRESS_PORT), CRYSTAL_PNP_REG_MBAL1 );
   NdisRawReadPortUchar( (PORT)(IOBase+CRYSTAL_DATA_PORT), &Value.Byte[0] );
   NdisRawWritePortUshort( (PORT)(IOBase+CRYSTAL_ADDRESS_PORT), CRYSTAL_PNP_REG_MBAH1 );
   NdisRawReadPortUchar( (PORT)(IOBase+CRYSTAL_DATA_PORT), &Value.Byte[1] );

   /* If memory base address is not specified */
   if ( Value.Word == 0 )
   {
      pChip->Config.MemoryBase = (DWORD)UNSPECIFIED;
      pChip->Config.MemorySize = (WORD)UNSPECIFIED;
   }
   else  /* The memory base is specified */
   {
      pChip->Config.MemoryBase = (((DWORD)Value.Word)<<EE_MEM_BASE_ADJUST);
      pChip->Config.MemorySize = CRYSTAL_MEMORY_SIZE;
   }

   /* Read ROM base address from PnP registers */
   NdisRawWritePortUshort( (PORT)(IOBase+CRYSTAL_ADDRESS_PORT), CRYSTAL_PNP_REG_MBAL0 );
   NdisRawReadPortUchar( (PORT)(IOBase+CRYSTAL_DATA_PORT), &Value.Byte[0] );
   NdisRawWritePortUshort( (PORT)(IOBase+CRYSTAL_ADDRESS_PORT), CRYSTAL_PNP_REG_MBAH0 );
   NdisRawReadPortUchar( (PORT)(IOBase+CRYSTAL_DATA_PORT), &Value.Byte[1] );

   /* If ROM base address is not specified */
   if ( Value.Word == 0 )
   {
      pChip->Config.ROMBase = (DWORD)UNSPECIFIED;
      pChip->Config.ROMSize = (WORD)UNSPECIFIED;
   }
   else  /* The ROM base is specified */
   {
      pChip->Config.MemoryBase = (((DWORD)Value.Word)<<EE_MEM_BASE_ADJUST);
      pChip->Config.ROMSize = CRYSTAL_ROM_SIZE;
   }

   /* Read interrupt request line from PnP register */
   NdisRawWritePortUshort( (PORT)(IOBase+CRYSTAL_ADDRESS_PORT), CRYSTAL_PNP_REG_IRQ_S0 );
   NdisRawReadPortUchar( (PORT)(IOBase+CRYSTAL_DATA_PORT), &Byte );

   /* If the interrupt request line is not specified */
   if ( Byte == 0 )
   {
      pChip->Config.IntLine = (BYTE)UNSPECIFIED;
      return FAILURE;
   }
   else  /* The interrupt request line is specified */
   {
      pChip->Config.IntLine = Byte;
   }

   /* Read DMA channel from PnP register */
   NdisRawWritePortUshort( (PORT)(IOBase+CRYSTAL_ADDRESS_PORT), CRYSTAL_PNP_REG_DMASX );
   NdisRawReadPortUchar( (PORT)(IOBase+CRYSTAL_DATA_PORT), &Byte );

   /* If the DMA channel is not specified */
   if ( Byte == 0 )
   {
      pChip->Config.DMALine = (BYTE)UNSPECIFIED;
   }
   else  /* The DMA channel is specified */
   {
      pChip->Config.DMALine = Byte;
   }

   return SUCCESS;
}


/******************************************************************************
*
* GetConfigFromEEPROM()
*
******************************************************************************/

WORD GetConfigFromEEPROM( PCHIP pChip )
{
   WORD Result;
   WORD ISAConfig;
   WORD MemBase;

   /* Read the ISA configuration from the EEPROM */
   Result = ReadEEPROM( pChip, EE_ADDRESS_FLAGS, &ISAConfig );
   if ( Result != SUCCESS ) return FAILURE;

   /* If memory mode is enabled */
   if ( ISAConfig & EE_MEM_FLAG )
   {
      /* Read the memory base address from the EEPROM */
      Result = ReadEEPROM( pChip, EE_ADDRESS_MEM_BASE, &MemBase );
      if ( Result != SUCCESS ) return FAILURE;

      MemBase &= EE_MEMORY_MASK;  /* Clear unused bits */

      pChip->Config.MemoryBase = (((DWORD)MemBase)<<EE_MEM_BASE_ADJUST);
      pChip->Config.MemorySize = CRYSTAL_MEMORY_SIZE;
   }
   else  /* Memory mode is disabled */
   {
      pChip->Config.MemoryBase = (DWORD)UNSPECIFIED;
      pChip->Config.MemorySize = (WORD)UNSPECIFIED;
   }

   /* If a boot ROM is installed */
   if ( ISAConfig & EE_BOOT_PROM_FLAG )
   {
      /* Read the ROM base address from the EEPROM */
      Result = ReadEEPROM( pChip, EE_ADDRESS_BOOT_BASE, &MemBase );
      if ( Result != SUCCESS ) return FAILURE;

      MemBase &= EE_MEMORY_MASK;  /* Clear unused bits */

      pChip->Config.ROMBase = (((DWORD)MemBase)<<EE_MEM_BASE_ADJUST);
      pChip->Config.ROMSize = CRYSTAL_ROM_SIZE;
   }
   else  /* A boot ROM is not installed */
   {
      pChip->Config.ROMBase = (DWORD)UNSPECIFIED;
      pChip->Config.ROMSize = (WORD)UNSPECIFIED;
   }

   /* Get the interrupt line from the ISA configuration */
   pChip->Config.IntLine = ISAConfig & EE_INTERRUPT_MASK;
   
//@drsa 11-3-97 3.21 add cs8900 support   
   if (pChip->Config.ChipType == CS8900_PROD_ID_LOW) {

      // Map EEPROM IRQ value to IRQ
      if (pChip->Config.IntLine == 3)
         pChip->Config.IntLine = 5;
      else
         pChip->Config.IntLine += 10;

   }

   pChip->Config.DMALine = (ISAConfig & EE_DMA_MASK) >> EE_DMA_ADJUST;
   if (pChip->Config.ChipType == CS8900_PROD_ID_LOW) {

      // Map EEPROM DMA value to DMA channel
      if (pChip->Config.DMALine == 3)
         pChip->Config.DMALine = (BYTE)UNSPECIFIED;
      else
         pChip->Config.DMALine += 5;

   } else {   // it is a CS8920

      if ( (ISAConfig & EE_DMA_MASK) == 0 )
         pChip->Config.DMALine = (BYTE)UNSPECIFIED;

   }


   return SUCCESS;
}


/******************************************************************************
*
* FindNextChip()
*
* If next chip is found, then its IOBase is returned.
* If next chip is not found, then zero is returned.
*
******************************************************************************/

PORT FindNextChip( PCHIP pChip, PORT StartingIOBase )
{
   PORT IOBase;
   WORD Value;

   /* Scan the IO space for our chip */
   for ( IOBase=StartingIOBase; IOBase<CRYSTAL_MAX_PORT_ADDRESS;
         IOBase+=CRYSTAL_NEXT_PORT_OFFSET )
   {

      if (SkipIOBase(IOBase) == FALSE)
      {
         /* Read the address port (packet page pointer) */
         NdisRawReadPortUshort( (PORT)(IOBase+CRYSTAL_ADDRESS_PORT), &Value );

         /* If the contents of the address port is 0x3xxx */
         if ( (Value & CRYSTAL_SCAN_MASK) == CRYSTAL_SCAN_SIGNATURE )
         {
            /* Read the transmit command port */
            NdisRawReadPortUshort( (PORT)(IOBase+CRYSTAL_TRANSMIT_COMMAND_PORT), &Value );

            /* If the lower 6 bits of the transmit command port is 9 */
            if ( (Value & CRYSTAL_REG_NUMBER_MASK)==CRYSTAL_REG_NUMBER_TX_CMD )
            {
               /* Read the EISA ID from the packet page */
               Value = ReadPacketPage( pChip, IOBase, CRYSTAL_CHIPEISA_ID );

               /* If the EISA ID is for Crystal Semiconductor */
               if ( Value == CS89XX_ID )
               {
                  /* Read the product ID from the packet page */
                  Value = ReadPacketPage( pChip, IOBase, CRYSTAL_PRODUCT_ID );

             
//@drsa  11-3-97  3.21  add cs8900 support             
                  /* If the product ID is for CS8900 or CS8920 */
                  if ( ((Value & PRODUCT_ID_MASK) == CS89xx_PROD_ID_LOW) ||
                       ((Value & PRODUCT_ID_MASK) == CS8920_PROD_ID_LOW) ||
                       ((Value & PRODUCT_ID_MASK) == CS8900_PROD_ID_LOW)   )
                  {
                    return IOBase;  /* Found a chip! */
                  }
               }
            }
         }
      }
   }

   return 0;  /* Did not find a chip */
}


/******************************************************************************
*
* VchipStartup()
*
******************************************************************************/

WORD VchipStartup( PCHIP pChip )
{
   PCD   pData;
   PORT  IOBase;
   WORD  Result;
   WORD  ISAConfig;
   WORD  AdapterConfig;


   pData    = pChip->pData;
   IOBase = pChip->Config.IOBase;

   /* Initialize configuration flags to zero */
   pData->ConfigFlags = 0;

   /* Read adpater configuration from the EEPROM */
   Result = ReadEEPROM( pChip, EE_ADDRESS_VRHC, &AdapterConfig );
   if ( Result != SUCCESS )
   {
      return Result;
   }

   /* Get polarity of DC/DC converter enable pin from AdapterConfig */
   if ( AdapterConfig & EE_DCDC_POLARITY )
      pData->ConfigFlags |= CFGFLG_DCDC_POLARITY;

   /* Get available Hardware configuration (CFGFLG_MEDIA_CAP) */
   pData->ConfigFlags |= (AdapterConfig & EE_CKT_MASK) << 4;

   /* Read the ISA configuration from the EEPROM */
   Result = ReadEEPROM( pChip, EE_ADDRESS_FLAGS, &ISAConfig );
   if ( Result != SUCCESS )
   {
      return Result;
   }

   /* Get I/O-channel-ready from ISA configuration */
   if ( ISAConfig & EE_IOCHRDY_ENBL )
      pData->ConfigFlags |= CFGFLG_IOCHRDY;

   

   Result = VchipReset( pChip );             //@drsa
   if ( Result != CHIP_SUCCESS )             //@drsa
   {                                         //@drsa
      return Result;                         //@drsa
   }                                         //@drsa
   

   // @kml 6/30/99
  // /* Check to make sure the chip is functioning */
  // Result = CrystalTestInternalLoopBack( pChip );
  // if ( Result != CHIP_SUCCESS )
  // {
  //    return Result;
  // }
//
  // Result = VchipReset( pChip );
  // if ( Result != CHIP_SUCCESS )
  // {
  //    return Result;
  // }

   // @kml 6/30/99 Wait for the LinkOK bit in Line Control Reg.
   VominiDelay(100);     
   DetectMedia( pChip );

  while ( pChip->Config.DetectedMediaType == MEDIA_PENDING )
  {
 	  if (pChip->Config.CurrentDuplexMode == DUPLEX_PENDING) {
		  // @kml Auto Config Duplex mode
		  VominiDelay( 2500 ); 
	  } else {
   // @kml 6/30/99 quick init time when in Force Full or Half Duplex mode
		  VominiDelay( 100 ); 
	  }
      DetectMedia( pChip );
   }

   if ( pChip->Config.DetectedMediaType != MEDIA_NONE )
   {
      if ( pChip->Config.DetectedMediaType != MEDIA_BASE_T )
      {
         Result = VchipReset( pChip );             //@rosa avoids pending receives
         if ( Result != CHIP_SUCCESS )             //@rosa
         {                                         //@rosa
            return Result;                         //@rosa
         }                                         //@rosa
      }

      /* Initialize the chip */
      Result = VchipInit( pChip );
      if ( Result != CHIP_SUCCESS )
      {
         return Result;
      }
   }


   /* Must start Timer routine to detect cable Status */
    Result = VominiStartTimer( pChip, VchipDetectMediaDaemon, 2500,
         &pData->DetectMediaTimer, NULL ); 

   if ( Result != CHIP_SUCCESS )
   {
      return Result;
   }

   return CHIP_SUCCESS;
}


/******************************************************************************
*
* VchipInit()
*
* Note: This driver does not support memory mode.
*
******************************************************************************/

WORD VchipInit( PCHIP pChip )
{
   PCD  pData;
   PORT IOBase;
   WORD BusControl;
   WORD SelfControl;
   //@drs 11-3-97  3.21 add cs8900 support
   WORD IntLine;

   pData    = pChip->pData;
   IOBase = pChip->Config.IOBase;

   if (( pChip->Config.DetectedMediaType == MEDIA_PENDING ) ||
       ( pChip->Config.DetectedMediaType == MEDIA_NONE ))
      return CHIP_SUCCESS;

   pData->TransmitBidPending = FALSE;
   pData->TransmitInProgress = FALSE;
   pData->TransmitThresholdCount = 0;
   pData->TransmitStarted = FALSE;
   pData->StartTX = FALSE;
   pData->TransmitCommand = CRYSTAL_TCR_TX_START_381_BYTES;
   pData->CurrentReceiveConfiguration = CRYSTAL_DEFAULT_RX_CONFIG_VALUE;

   InitQueues( pChip );

   /* Put Ethernet address into the Individual Address register */
   WritePacketPage( pChip, IOBase, CRYSTAL_INDIVIDUAL_ADDRESS,
         pChip->Config.EthernetAddr.Part[0] );
   WritePacketPage( pChip, IOBase, CRYSTAL_INDIVIDUAL_ADDRESS+2,
         pChip->Config.EthernetAddr.Part[1] );
   WritePacketPage( pChip, IOBase, CRYSTAL_INDIVIDUAL_ADDRESS+4,
         pChip->Config.EthernetAddr.Part[2] );

   /* If IOCHRDY is enabled then clear the bit in the BusControl register */
   BusControl = ReadPacketPage( pChip, IOBase, CRYSTAL_BUS_CONTROL_REGISTER );
   if ( pData->ConfigFlags & CFGFLG_IOCHRDY )
      WritePacketPage( pChip, IOBase, CRYSTAL_BUS_CONTROL_REGISTER,
            (WORD)(BusControl & ~CRYSTAL_BCR_IO_CHANNEL_READY_ON) );
   else
      WritePacketPage( pChip, IOBase, CRYSTAL_BUS_CONTROL_REGISTER,
            (WORD)(BusControl | CRYSTAL_BCR_IO_CHANNEL_READY_ON) );

   /* Set the Line Control register to match the media type */
   if ( pChip->Config.DetectedMediaType == MEDIA_BASE_T )
      WritePacketPage( pChip, IOBase, CRYSTAL_LINE_CONTROL_REGISTER,
            CRYSTAL_LCR_DEFAULT_VALUE );
   else
      WritePacketPage( pChip, IOBase, CRYSTAL_LINE_CONTROL_REGISTER,
            CRYSTAL_LCR_AUI_ONLY );

   /* Set the BSTATUS/HC1 pin to be used as HC1 */
   /* HC1 is used to enable the DC/DC converter */
   SelfControl = CRYSTAL_SCR_HCO_1_ENABLE;

   /* If the media type is 10Base2 */
   if ( pChip->Config.DetectedMediaType == MEDIA_BASE_2 )
   {
      /* Enable the DC/DC converter */
      /* If the DC/DC converter has a low enable */
      if ( (pData->ConfigFlags & CFGFLG_DCDC_POLARITY) == 0 )
         /* Set the HCB1 bit, which causes the HC1 pin to go low */
         SelfControl |= CRYSTAL_SCR_HCO_1;
      else
         SelfControl &= ~CRYSTAL_SCR_HCO_1;
   }
   else  /* Media type is 10BaseT or AUI */
   {
      /* Disable the DC/DC converter */
      /* If the DC/DC converter has a high enable */
      if ( (pData->ConfigFlags & CFGFLG_DCDC_POLARITY) != 0 )
         /* Set the HCB1 bit, which causes the HC1 pin to go low */
         SelfControl |= CRYSTAL_SCR_HCO_1;
      else
         SelfControl &= ~CRYSTAL_SCR_HCO_1;
   }
   WritePacketPage( pChip, IOBase, CRYSTAL_SELF_CONTROL_REGISTER, SelfControl );

   /* Initialize the config and control registers */
   WritePacketPage( pChip, IOBase, CRYSTAL_RX_CONFIG_REGISTER,
         CRYSTAL_DEFAULT_RX_CONFIG_VALUE );
   WritePacketPage( pChip, IOBase, CRYSTAL_RX_CONTROL_REGISTER,
         CRYSTAL_RCR_DEFAULT_VALUE );
   WritePacketPage( pChip, IOBase, CRYSTAL_TX_CONFIG_REGISTER,
         CRYSTAL_TCR_DEFAULT_VALUE );

   //@drs 11-3-97  3.21 add cs8900 support
   //
   // Do not enable early interrupts if it is a CS8900
   // Revision E or lower.
   //
   if ((pChip->Config.ChipType == CS8900_PROD_ID_LOW) &&
       (pChip->Config.ChipRev <= 4)) {
      WritePacketPage( pChip, IOBase, CRYSTAL_BUFFER_CONFIG_REGISTER,
            CRYSTAL_BCR_DEFAULT_VALUE);
   } else {
      WritePacketPage( pChip, IOBase, CRYSTAL_BUFFER_CONFIG_REGISTER,
            CRYSTAL_BCR_DEFAULT_VALUE | CRYSTAL_BCR_ENABLE_EARLY_INTERRUPTS );
   }

   /* Setup initial filtering criteria */
   VchipChangeFiltering( pChip );

   //@drs 11-3-97  3.21 add cs8900 support
   IntLine = pChip->Config.IntLine;
   if (pChip->Config.ChipType == CS8900_PROD_ID_LOW) {
      IntLine = (IntLine != 5) ? (IntLine - 10) : 3;
      WritePacketPage( pChip, IOBase, CRYSTAL_ISA_INTERRUPT_NUMBER, IntLine );
   } else {    // CS8920
      /* Set the interrupt level in the Plug and Play register */
      WritePacketPage( pChip, IOBase, CRYSTAL_PNP_REG_IRQ_S0, IntLine );
   }

   /* Enable reception and transmission of frames */
   WritePacketPage( pChip, IOBase, CRYSTAL_LINE_CONTROL_REGISTER,
       (WORD)(ReadPacketPage( pChip, IOBase,CRYSTAL_LINE_CONTROL_REGISTER) |
       CRYSTAL_LCR_SERIAL_RX_ON | CRYSTAL_LCR_SERIAL_TX_ON) );

   /* Enable interrupt at the chip */
   VchipEnableInterrupts( pChip );

   return CHIP_SUCCESS;
}


/******************************************************************************
*
* InitQueues()
*
******************************************************************************/

void InitQueues( PCHIP pChip )
{
   PCD   pData = pChip->pData;


   pData->TransmitQueue.Head = pData->TransmitQueue.Tail = NULL;
}


/******************************************************************************
*
* VchipReset()
*
******************************************************************************/

WORD VchipReset( PCHIP pChip )
{
   PCD  pData;
   PORT IOBase;
   BYTE  Byte;
   int  x;

   pData    = pChip->pData;
   IOBase = pChip->Config.IOBase;


   /* We are now resetting the chip */
   /* A spurious interrupt is generated by the chip when it is reset. */
   /* This variable informs the interrupt handler to ignore this interrupt. */
   pData->Resetting = TRUE;

   /* Issue a reset command to the chip */
   WritePacketPage( pChip, IOBase, CRYSTAL_SELF_CONTROL_REGISTER,
         CRYSTAL_SCR_POWER_ON_RESET );


   /* Delay for 20 milliseconds */
   VominiDelay( 20 );

   /* Transition SBHE to switch chip from 8-bit to 16-bit */
   NdisRawReadPortUchar( (PORT)(IOBase+CRYSTAL_ADDRESS_PORT), &Byte   );
   NdisRawReadPortUchar( (PORT)(IOBase+CRYSTAL_ADDRESS_PORT+1), &Byte );
   NdisRawReadPortUchar( (PORT)(IOBase+CRYSTAL_ADDRESS_PORT), &Byte   );
   NdisRawReadPortUchar( (PORT)(IOBase+CRYSTAL_ADDRESS_PORT+1), &Byte );

   /* Wait until the EEPROM is not busy */
   for ( x=0; x<MAXLOOP; x++ )
      if ( !(ReadPacketPage(pChip,IOBase,CRYSTAL_SELF_STATUS_REGISTER) &
            CRYSTAL_SSR_SI_BUSY) )
         break;
   if ( x == MAXLOOP ) return CHIP_FAILURE;

   /* Wait until initialization is done */
   for ( x=0; x<MAXLOOP; x++ )
      if ( ReadPacketPage(pChip,IOBase,CRYSTAL_SELF_STATUS_REGISTER) &
            CRYSTAL_SSR_INIT_DONE )
         break;
   if ( x == MAXLOOP ) return CHIP_FAILURE;

   /* Reset is no longer in progress */
   pData->Resetting = FALSE;

   return CHIP_SUCCESS;
}


/******************************************************************************
*
* VchipShutdown()
*
******************************************************************************/

void VchipShutdown( PCHIP pChip )
{
   PCD  pData;
   PORT IOBase;
   WORD SelfStatus;

   pData    = pChip->pData;
   IOBase = pChip->Config.IOBase;

   VominiStopTimer( pChip, pData->DetectMediaTimer );

   VchipReset( pChip );

   /* Read the self status register */
   SelfStatus = ReadPacketPage( pChip, IOBase, CRYSTAL_SELF_STATUS_REGISTER );

   /* If Plug and Play is not disabled */
   if ( !(SelfStatus & CRYSTAL_SSR_PNP_DISABLE) )
   {
      /* Put the interrupt level in the Plug and Play register */
      WritePacketPage( pChip, IOBase, CRYSTAL_PNP_REG_IRQ_S0, pChip->Config.IntLine );
   }

   DeleteIOBase( pChip->Config.IOBase );

}


/******************************************************************************
*
* VchipTest()
*
******************************************************************************/

void VchipTest( PCHIP pChip )
{
   PORT IOBase;
   WORD BuffConfig;

   IOBase = pChip->Config.IOBase;

   /* Generate a software initiated interrupt */
   BuffConfig = ReadPacketPage( pChip, IOBase, CRYSTAL_BUFFER_CONFIG_REGISTER );
   BuffConfig |= CRYSTAL_BCR_GENERATE_SW_INTERRUPT;
   WritePacketPage( pChip, IOBase, CRYSTAL_BUFFER_CONFIG_REGISTER, BuffConfig );
}


/******************************************************************************
*
* ReadEEPROM()
*
******************************************************************************/

WORD ReadEEPROM( PCHIP pChip, WORD Offset, WORD *pValue )
{
   PORT IOBase;
   int x;

   IOBase = pChip->Config.IOBase;

   /* Ensure that the EEPROM is not busy */
   for ( x=0; x<MAXLOOP; x++ )
      if ( !(ReadPacketPage(pChip,IOBase,CRYSTAL_SELF_STATUS_REGISTER) &
            CRYSTAL_SSR_SI_BUSY) )
         break;
   if ( x == MAXLOOP ) return FAILURE;

   /* Issue the command to read the offset within the EEPROM */
   WritePacketPage( pChip, IOBase, CRYSTAL_EEPROM_COMMAND_REGISTER,
         (WORD)(Offset | EEPROM_READ_REGISTER) );

   /* Wait until the command is completed */
   for ( x=0; x<MAXLOOP; x++ )
      if ( !(ReadPacketPage(pChip,IOBase,CRYSTAL_SELF_STATUS_REGISTER) &
            CRYSTAL_SSR_SI_BUSY) )
         break;
   if ( x == MAXLOOP ) return FAILURE;

   /* Get the EEPROM data from the EEPROM Data register */
   *pValue = ReadPacketPage( pChip, IOBase, CRYSTAL_EEPROM_DATA_WORD );

   return SUCCESS;
}


/******************************************************************************
*
* ReadPacketPage()
*
******************************************************************************/

WORD ReadPacketPage( PCHIP pChip, PORT IOBase, WORD Offset )
{
   WORD Value;

   NdisRawWritePortUshort( (PORT)(IOBase+CRYSTAL_ADDRESS_PORT), Offset );
   NdisRawReadPortUshort( (PORT)(IOBase+CRYSTAL_DATA_PORT), &Value );

   return Value;
}


/******************************************************************************
*
* WritePacketPage()
*
******************************************************************************/

void WritePacketPage( PCHIP pChip, PORT IOBase, WORD Offset, WORD Value )
{

   NdisRawWritePortUshort( (PORT)(IOBase+CRYSTAL_ADDRESS_PORT), Offset );
   NdisRawWritePortUshort( (PORT)(IOBase+CRYSTAL_DATA_PORT), Value );

}

/******************************************************************************
*
* AddIOBase()
*
******************************************************************************/

WORD AddIOBase( PORT IOBase )
{
   WORD i;

   for (i=0; i < MAX_CHIPS; i++)
   {
      if (IOBaseList[i] == 0)
      {
         IOBaseList[i] = IOBase;
         return SUCCESS;
      }
   }
   return FAILURE;
}

/******************************************************************************
*
* DeleteIOBase()
*
******************************************************************************/

WORD DeleteIOBase( PORT IOBase )
{
   WORD i;
   for (i=0; i < MAX_CHIPS; i++)
   {
      if (IOBaseList[i] == IOBase)
      {
         IOBaseList[i] = 0;
         return SUCCESS;
      }
   }
   return FAILURE;
}

/******************************************************************************
*
* SkipIOBase()
*
******************************************************************************/

WORD SkipIOBase( PORT IOBase )
{
   WORD i;
   for (i=0; i < MAX_CHIPS; i++)
   {
      if (IOBaseList[i] == IOBase)
         return TRUE;
   }
   return FALSE;
}



/******************************************************************************
*
* VchipGetConfig()
*
* Caller must fill in pChip->SerialNumber. SerialNumber of -1 means first
* use first available chip found.
*
******************************************************************************/

NDIS_STATUS VchipFindIOBase( PCHIP pChip, PORT StartPort)
{
   PORT IOBase;
   WORD Result;
   WORD SelfStatus;
   DWORD SerialNumber;


 // @kml 6/23/99
 //  for ( IOBase=CRYSTAL_STARTING_PORT; ; IOBase+=CRYSTAL_NEXT_PORT_OFFSET )
  for ( IOBase=StartPort; ; IOBase+=CRYSTAL_NEXT_PORT_OFFSET )
  {
      IOBase = FindNextChip ( pChip, IOBase );
      if ( IOBase == 0 ) {
         return NDIS_STATUS_FAILURE;
	  }

      /* Read the product ID from the packet page */
      Result = ReadPacketPage( pChip, IOBase, CRYSTAL_PRODUCT_ID );
      pChip->Config.ChipType = Result & PRODUCT_ID_MASK;
      pChip->Config.ChipRev  = Result & REVISION_ID_MASK;


      /* Read the self status register */
      SelfStatus = ReadPacketPage( pChip, IOBase, CRYSTAL_SELF_STATUS_REGISTER );

     
	  /* @kml 05/08/00 If the EEPROM is not present or the EEPROM is not OK,
	     then sofeware reset the chip. */
     pChip->Config.IOBase = IOBase;

      if ( !(SelfStatus & CRYSTAL_SSR_EEPROM_PRESENT) ||
           !(SelfStatus & CRYSTAL_SSR_EEPROM_OK)        )		   
      {
 	         VchipReset( pChip );

             /* Read the self status register */
             SelfStatus = ReadPacketPage( pChip, IOBase, CRYSTAL_SELF_STATUS_REGISTER );
	  }


	  /* If the EEPROM is present and the EEPROM is OK */
      if ( (SelfStatus & CRYSTAL_SSR_EEPROM_PRESENT) &&
           (SelfStatus & CRYSTAL_SSR_EEPROM_OK)        )
      {
		  /* @kml 05/08/00 */
       /*  pChip->Config.IOBase = IOBase;*/

         /* Read the Serial Number */
         Result = ReadEEPROM( pChip, EE_SERIAL_NUMBER_LOW,
               (WORD *)&SerialNumber );

         SerialNumber <<= 16;

         Result |= ReadEEPROM( pChip, EE_SERIAL_NUMBER_HIGH,
               (WORD *)&SerialNumber );

         /* Found if Serial Number was unspecified */
         /* or the Serial Number read from EEPROM  */
         /* matches the specified serial number.   */

         if ((Result == SUCCESS) &&
             ((pChip->SerialNumber == UNSPECIFIED) ||
              (pChip->SerialNumber == SerialNumber)  ))
            break;

      }	/* endif */
      else { /* @kml 10/20/00 EEPROM is not present */
		  EEPROM_NOT_FOUND=TRUE;
		  SerialNumber=UNSPECIFIED;
          break;
	  }

   } /* endfor */
   pChip->Config.IOSize = CRYSTAL_IO_SIZE;
   pChip->SerialNumber = SerialNumber;

   return NDIS_STATUS_SUCCESS;
}





