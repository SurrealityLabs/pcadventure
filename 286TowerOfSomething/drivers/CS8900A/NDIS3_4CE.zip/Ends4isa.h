//---------------------------------------------------------------------------
//
//  Copyright (C) 1996-1997. Unpublished Work of Crystal Semiconductor Corp.
//  All Rights Reserved.
//
//  THIS WORK IS AN UNPUBLISHED WORK AND CONTAINS CONFIDENTIAL,
//  PROPRIETARY AND TRADE SECRET INFORMATION OF CRYSTAL SEMICONDUCTOR.
//  ACCESS TO THIS WORK IS RESTRICTED TO (I) CRYSTAL SEMICONDUCTOR EMPLOYEES
//  WHO HAVE A NEED TO KNOW TO PERFORM TASKS WITHIN THE SCOPE OF THEIR
//  ASSIGNMENTS  AND (II) ENTITIES OTHER THAN CRYSTAL SEMICONDUCTOR WHO
//  HAVE ENTERED INTO  APPROPRIATE LICENSE AGREEMENTS.  NO PART OF THIS
//  WORK MAY BE USED, PRACTICED, PERFORMED, COPIED, DISTRIBUTED, REVISED,
//  MODIFIED, TRANSLATED, ABRIDGED, CONDENSED, EXPANDED, COLLECTED,
//  COMPILED,LINKED,RECAST, TRANSFORMED, ADAPTED IN ANY FORM OR BY ANY
//  MEANS,MANUAL, MECHANICAL, CHEMICAL, ELECTRICAL, ELECTRONIC, OPTICAL,
//  BIOLOGICAL, OR OTHERWISE WITHOUT THE PRIOR WRITTEN PERMISSION AND
//  CONSENT OF CRYSTAL SEMICONDUCTOR . ANY USE OR EXPLOITATION OF THIS WORK
//  WITHOUT THE PRIOR WRITTEN CONSENT OF CRYSTAL SEMICONDUCTOR  COULD
//  SUBJECT THE PERPETRATOR TO CRIMINAL AND CIVIL LIABILITY.
//
//---------------------------------------------------------------------------

/* v8920.h */


#ifndef _ends4isa_

#include <ndis.h>

#define _ends4isa_



// Strings/messages containing vendor specific information
#define VENDOR_FILEDESCRIPTION_STR   "Crystal LAN(tm) CS8920 Ethernet Network Driver"
#define VENDOR_PRODUCT_NAME_STR      "Crystal LAN(tm) CS8920 Ethernet Adapter"

//forward pointer declaration
typedef struct CHIP_t  *PCHIP;

typedef unsigned char   BYTE;
typedef unsigned short  WORD;
typedef unsigned long   DWORD;
typedef unsigned char  *PBYTE;
typedef unsigned short *PWORD;
typedef unsigned long  *PDWORD;
typedef void           *PVOID;

typedef DWORD            PORT;

#define UNSPECIFIED (-1)

#define TRUE        1
#define FALSE       0
#define SUCCESS     0
#define FAILURE     1


/* Ethernet Address */

typedef struct
{
   WORD Part[3];
} EA,  *PEA;


/* Chip Configuration */

typedef struct CFG_t
{
   PORT  IOBase;
   WORD  IOSize;        /* In bytes */
   DWORD MemoryBase;
   WORD  MemorySize;    /* In bytes */
   DWORD ROMBase;
   WORD  ROMSize;       /* In bytes */
   BYTE  IntLine;
   BYTE  DMALine;
   EA    EthernetAddr;
   WORD  MediaSpeed;     /* 10 = 10 Mbit */
   BYTE  RequestedMediaType;
   BYTE  DetectedMediaType;
   BYTE  RequestedDuplexMode;
   BYTE  CurrentDuplexMode;
   BYTE  Filtering;
   BYTE  BusType;
   WORD  BusSlot;
   BYTE  MaxTxCount;
   BYTE  MaxRxCount;
   WORD  LookAheadSize;
   DWORD Flags;
//@drs 11-3-97 3.21  add cs8900 support
   WORD   ChipType;
   WORD   ChipRev;
} CFG,  *PCFG;


/* Bus Type */

#define BUS_ISA         0
#define BUS_MCA         1
#define BUS_EISA        2
#define BUS_PCMCIA      3
#define BUS_PCI         4
#define BUS_VESA        5


/* Media Type */

#define MEDIA_AUTO_DETECT       0x00
#define MEDIA_BASE_T            0x01
#define MEDIA_BASE_AUI          0x02
#define MEDIA_BASE_2            0x03
#define MEDIA_PENDING           0xFE
#define MEDIA_NONE              0xFF


/* Duplex Mode */

#define DUPLEX_AUTO_NEGOTIATE   0x00
#define DUPLEX_HALF             0x01
#define DUPLEX_FULL             0x02
#define DUPLEX_PENDING          0xFE
#define DUPLEX_NONE             0xFF


/* Filtering */

#define FILTER_INDIVIDUAL_ACCEPT   0x01
#define FILTER_BROADCAST_ACCEPT    0x02
#define FILTER_MULTICAST_ACCEPT    0x04
#define FILTER_PROMISCUOUS_ACCEPT  0x08


/* Transmit Errors */

#define TX_ERR_NO_BUFFER        0x0001
#define TX_ERR_TOO_BIG          0x0002
#define TX_ERR_TOO_MANY_FRAGS   0x0004
#define TX_ERR_SQE_ERROR        0x0008
#define TX_ERR_JABBER           0x0010
#define TX_ERR_LOCK_FAIL        0x0020
#define TX_ERR_EXCESS_COLL      0x0100
#define TX_ERR_UNDERRUN         0x0200
#define TX_ERR_OUT_OF_WIN       0x0400
#define TX_ERR_LOSS_CRS         0x1000
#define TX_ERR_FRAME_ABORT      0x2000


/* Receive Errors */

#define RX_ERR_CRC_ERROR        0x0001
#define RX_ERR_EXTRA_DATA       0x0002
#define RX_ERR_RUNT             0x0004
#define RX_ERR_FRAMING          0x0008
#define RX_ERR_OVERRUN          0x0010
#define RX_ERR_RX_ERR           0x0020
#define RX_ERR_RX_MISS          0x0100
#define RX_ERR_DRIBBLE          0x0200
#define RX_ERR_TOO_MANY_FRAGS   0x0400
#define RX_ERR_NO_BUFFER        0x0800


/* Flags */

#define FLAG_BUS_MASTER         0x00000001
#define FLAG_INTERRUPT_SHARED   0x00000002


/* Override permission bits */

#define OVERRIDE_IO_BASE        0x0001
#define OVERRIDE_MEM_BASE       0x0002
#define OVERRIDE_ROM_BASE       0x0004
#define OVERRIDE_INT_LINE       0x0008
#define OVERRIDE_DMA_LINE       0x0010
#define OVERRIDE_ETHER_ADDR     0x0020
#define OVERRIDE_MEDIA_TYPE     0x0040
#define OVERRIDE_DUPLEX_MODE    0x0080
#define OVERRIDE_FILTERING      0x0100


/* Chip Result Codes */

#define CHIP_SUCCESS            0
#define CHIP_FAILURE            1



/* Timer Event Handler Type */

typedef void (* TIMER_EVENT_HANDLER)( PCHIP pChip, WORD TimerID, PVOID pParm );

#define MAX_TIMERS 1

typedef struct
{
   NDIS_MINIPORT_TIMER     TimerHandle;
   WORD                    TimerActive;
   TIMER_EVENT_HANDLER TimerRoutine;
   WORD                    TimerID;
   PCHIP                   pChip;
   PVOID                   pParm;
} VOMINITIMER, *PVOMINITIMER;

typedef struct
{

   VOMINITIMER             Timers[MAX_TIMERS];


} VOMINIPDATA, *PVOMINIPDATA;




#define VP_MAX_FRAMESIZE 1514
#define VP_MIN_FRAMESIZE   60
#define VP_HEADERSIZE      14
#define CRYSTAL_MCAST_LIST_SIZE 32  // @kml 6/24/99 changed from 6 ro 32

typedef struct txqueueelement
{
  PNDIS_PACKET    NextPacket;
  NDIS_STATUS     XmitRC;
} TXQUEUEELEMENT, *PTXQUEUEELEMENT;




typedef struct
{
   char McastAddress[ETH_LENGTH_OF_ADDRESS];

}  CRYSTALMCASTADDRESS, *PCRYSTALMCASTADDRESS;

typedef struct
{

   NDIS_HANDLE vpMiniportAdapterHandle;
   PVOID       VMHandle;
   PVOID       VOSHandle;
   PCHIP       pChip;
   UCHAR       PermanentNetworkAddress[ETH_LENGTH_OF_ADDRESS];
   UCHAR       CurrentNetworkAddress[ETH_LENGTH_OF_ADDRESS];
   WORD        ProtocolLookahead;
   ULONG       PacketFilter;
   ULONG       CableConnected;
   ULONG       CurrentState;
   ULONG       XmitOKs;
   ULONG       XmitErrors;
   ULONG       XmitOneCollisions;
   ULONG       XmitMoreCollisions;
   ULONG       XmitMaxCollisions;
   ULONG       XmitLateCollisions;
   ULONG       XmitUnderrun;
   ULONG       XmitLostCRS;
   ULONG       RcvOKs;
   ULONG       RcvErrors;
   ULONG       RcvNoBuffers;
   ULONG       RcvErrorAlignments;
   ULONG       RcvCRCErrors;
   ULONG       RcvOverrun;
   PNDIS_PACKET TxQueueHead;

   CRYSTALMCASTADDRESS McastList[CRYSTAL_MCAST_LIST_SIZE];
   ULONG       McastListSize;

} VPMINIPDATA, *PVPMINIPDATA;

// This MACRO sets up pvMini_Context and MiniportAdapterHandle from MiniportAdapterContext
#define VPM_SetupMiniContext \
    PVPMINIPDATA pvMini_Context = (PVPMINIPDATA)MiniportAdapterContext; \
    NDIS_HANDLE MiniportAdapterHandle = pvMini_Context->vpMiniportAdapterHandle; \
    PCHIP pChip = pvMini_Context->pChip;

#define VPM_SetupMiniContextFromPchip \
    PVPMINIPDATA pvMini_Context = (PVPMINIPDATA)(pChip->pPSD); \
    NDIS_HANDLE MiniportAdapterHandle = pvMini_Context->vpMiniportAdapterHandle; \




#define UNDERRUN_THRESHOLD                      6

#define ENQ_PACKET(Packet, Queue)           \
    if (Queue.Tail == NULL) {               \
       Queue.Head = Queue.Tail = Packet;    \
    } else {                                \
       Queue.Tail->Next = Packet;           \
       Queue.Tail = Packet;                 \
    }                                       \
    Queue.Tail->Next = NULL;

#define DEQ_PACKET(pPacket, pQueue)            \
    if (pPacket != NULL) {                     \
       *pPacket = pQueue.Head;                 \
       if (pQueue.Head != NULL) {              \
          if (pQueue.Head == pQueue.Tail) {    \
             pQueue.Tail = pQueue.Head->Next;  \
          }                                    \
          pQueue.Head = pQueue.Head->Next;     \
       }                                       \
    }

#define CRYSTAL_INDICATE_MAXIMUM 1514
#define CRYSTAL_MINIMUM_FRAME_SIZE 16



/* Transmit Request */
typedef struct _TRANSMIT_QUEUE_ELEMENT {
   struct _TRANSMIT_QUEUE_ELEMENT *Next;       // Ptr to next element in receive queue
   WORD   PacketSize;
} TRANSMIT_QUEUE_ELEMENT, *PTRANSMIT_QUEUE_ELEMENT;

#define CRYSTAL_TRANSMIT_PACKET_MAXIMUM          3

typedef struct _TRANSMIT_QUEUE {
   PTRANSMIT_QUEUE_ELEMENT Head;
   PTRANSMIT_QUEUE_ELEMENT Tail;
} TRANSMIT_QUEUE;

/* Chip Data */

typedef struct
{
  
   UCHAR  RxFlatBuff[CRYSTAL_INDICATE_MAXIMUM+4];
   ULONG  RxPacketSize; 
   DWORD  NeedToIssueRcvCmpltFlag;
   TRANSMIT_QUEUE TransmitQueue;
   WORD   TransmitBidPending;
   WORD   TransmitInProgress;   // If an element is on the Queue, tx is in progress
   WORD   TransmitStarted;
   WORD   TransmitThresholdCount;
   WORD   TransmitCommand;
   WORD   StartTX;
   WORD   CurrentReceiveConfiguration;
   WORD   Resetting;
   WORD   ConfigFlags;
   WORD   DetectMediaTimer;
   PVOID                   PortOffset;
   PVOID                   vIOSpace;
   NDIS_MINIPORT_INTERRUPT InterruptObject;
} CD,  *PCD;



/* Config Flags */

#define CFGFLG_IOCHRDY          0x0001
#define CFGFLG_DCDC_POLARITY    0x0002
// Media Capability
#define CFGFLG_MEDIA_CAP_BASE_T   0x0010
#define CFGFLG_MEDIA_CAP_BASE_AUI 0x0020
#define CFGFLG_MEDIA_CAP_BASE_2   0x0040


#define CRC_PRIME               0xFFFFFFFF;
#define CRC_POLYNOMIAL          0x04C11DB6;


/* Instance Chip Data */

typedef struct CHIP_t
{
   DWORD     SerialNumber;  /* Adapter Serial number from EEPROM */
   CFG       Config;        /* Common chip configuration */
   PCD           pData;     /* Chip Interface private data */
   PVPMINIPDATA  pPSD;      /* Protocol interface private data */
   PVOMINIPDATA  pOSD;      /* Timer private data */

   CD              lowerdata;       // pointed to by pData
   VPMINIPDATA 	   higherdata;      // pointed to by pPSD
   VOMINIPDATA     timerdata;       // pointed to by pOSD

} CHIP,  *PCHIP;


//
// Used when registering ourselves with NDIS.
//

#ifdef NDIS40_MINIPORT
#define CRYSTAL_NDIS_MAJOR_VERSION 4
#define CRYSTAL_NDIS_MINOR_VERSION 0x0
#else
#define CRYSTAL_NDIS_MAJOR_VERSION 3
#define CRYSTAL_NDIS_MINOR_VERSION 0x0
#endif

// Version information exists here, in .RC file, and in NT .INF file
#define CRYSTAL_MAJOR_VERSION 3
//@drs 10-28-97 chg version from 3.04 to 3.20
//@drs 11-03-97 chg version from 3.20 to 3.21
#define CRYSTAL_MINOR_VERSION 21
#define CRYSTAL_VERSION_STRING "3.21"







/* Prototypes */

NTSTATUS
DriverEntry(
    IN PDRIVER_OBJECT DriverObject,
    IN PUNICODE_STRING RegistryPath
    );


static
NDIS_STATUS
CrystalInitialize(
    OUT PNDIS_STATUS OpenErrorStatus,
    OUT PUINT SelectedMediumIndex,
    IN PNDIS_MEDIUM MediumArray,
    IN UINT MediumArraySize,
    IN NDIS_HANDLE MiniportAdapterHandle,
    IN NDIS_HANDLE ConfigurationHandle
    );

extern
void
CrystalDisableInterrupt(
    IN  NDIS_HANDLE MiniportAdapterContext
    );

extern
void
CrystalEnableInterrupt(
    IN  NDIS_HANDLE MiniportAdapterContext
    );

extern
void
CrystalHandleInterrupt(
    IN  NDIS_HANDLE MiniportAdapterContext
    );

extern
void
CrystalInterruptService(
    OUT PBOOLEAN InterruptRecognized,
    OUT PBOOLEAN QueueDpc,
    IN PVOID Context
    );

extern
NDIS_STATUS
CrystalReset(
    OUT PBOOLEAN AddressingReset,
    IN NDIS_HANDLE MiniportAdapterContext
    );

extern
void
CrystalHalt(
    IN NDIS_HANDLE MiniportAdapterContext
    );

extern
void
CrystalShutdown(
    IN NDIS_HANDLE MiniportAdapterContext
    );

extern
BOOLEAN
CrystalCheckForHang(
    IN PVOID MiniportAdapterContext
    );


extern
NDIS_STATUS
CrystalSend(
    IN NDIS_HANDLE MiniportAdapterHandle,
    IN PNDIS_PACKET Packet,
    IN UINT SendFlags
    );

extern
VOID
CrystalSendPackets(
    IN NDIS_HANDLE  MiniportAdapterContext,
    IN PPNDIS_PACKET  PacketArray,
    IN UINT  NumberOfPackets
    );

extern
NDIS_STATUS
CrystalTransferData(
    OUT PNDIS_PACKET  Packet,
    OUT PUINT  BytesTransferred,
    IN NDIS_HANDLE  MiniportAdapterHandle,
    IN NDIS_HANDLE  MacReceiveContext,
    IN UINT  ByteOffset,
    IN UINT  BytesToTransfer
    );

extern
NDIS_STATUS
CrystalQueryInformation(
    IN NDIS_HANDLE MiniportAdapterContext,
    IN NDIS_OID Oid,
    IN PVOID InformationBuffer,
    IN ULONG InformationBufferLength,
    OUT PULONG BytesWritten,
    OUT PULONG BytesNeeded
    );

extern
NDIS_STATUS
CrystalSetInformation(
    IN NDIS_HANDLE MiniportAdapterContext,
    IN NDIS_OID Oid,
    IN PVOID InformationBuffer,
    IN ULONG InformationBufferLength,
    OUT PULONG BytesRead,
    OUT PULONG BytesNeeded
    );





WORD  VominiStartup(PVOMINIPDATA pOSD, NDIS_HANDLE MiniportAdapterHandle );
void  VominiShutdown( PVOID pOSD );
WORD  VominiStartTimer( PCHIP pChip, TIMER_EVENT_HANDLER pEventHandler,
           DWORD mSecondDuration, PWORD pTimerID, PVOID pParm );
void  VominiStopTimer( PCHIP pChip, WORD TimerID );
void  VominiDelay( DWORD mSecondDuration );



extern
DWORD
GetSerialNumber(
    IN NDIS_HANDLE ConfigHandle,
        IN NDIS_ENVIRONMENT_TYPE OSType
    );

extern
NDIS_STATUS
GetNetworkAddress(
    IN NDIS_HANDLE ConfigHandle,
    OUT PUCHAR CurrentNetworkAddress
    );

extern
BYTE
GetDuplexMode(
    IN NDIS_HANDLE ConfigHandle
    );

extern
NDIS_ENVIRONMENT_TYPE
GetOSType(
    IN NDIS_HANDLE ConfigHandle
    );


VOID
VominiTimerDaemon(
   IN PVOID SystemSpecific1,
   IN PVOID Context,
   IN PVOID SystemSpecific2,
   IN PVOID SystemSpecific3
   );


WORD VchipGetConfig( PCHIP pChip);
WORD AssignedUserDefinedConfig(PCHIP pChip);
WORD VchipStartup( PCHIP pChip );
WORD VchipInit( PCHIP pChip );
void VchipChangeLookAhead( PCHIP pChip );
WORD VchipReset( PCHIP pChip );
void VchipShutdown( PCHIP pChip );
void VchipMulticastDeleteAll( PCHIP pChip );
void VchipMulticastAddAll( PCHIP pChip );
void VchipMulticastAdd( PCHIP pChip, PEA pMulticastAddr );
void VchipMulticastDelete( PCHIP pChip, PEA pMulticastAddr );
void VchipChangeFiltering( PCHIP pChip );
void VpsSendError( PCHIP pChip, WORD Errors );
void VpsRecvError( PCHIP pChip, WORD Errors );
WORD VchipISR( PCHIP pChip );
void VchipEnableInterrupts( PCHIP pChip );
void VchipDisableInterrupts( PCHIP pChip );
void VpsMediaChanged( PCHIP pChip );
void VchipTest( PCHIP pChip );


WORD GetConfigFromPnP( PCHIP pChip );
WORD GetConfigFromEEPROM( PCHIP pChip );
PORT FindNextChip( PCHIP pChip, PORT StartingIOBase );
void InitQueues( PCHIP pChip );
WORD ReadEEPROM( PCHIP pChip, WORD Offset, WORD *pValue );
WORD ReadPacketPage( PCHIP pChip, PORT IOBase, WORD Offset );
void WritePacketPage( PCHIP pChip, PORT IOBase, WORD Offset, WORD Value );
WORD AddIOBase( PORT IOBase );
WORD DeleteIOBase( PORT IOBase );
WORD SkipIOBase( PORT IOBase );



void DetectMedia( PCHIP pChip );
void VchipDetectMediaDaemon(PCHIP pChip, WORD TimerID, PVOID pParm);
BOOLEAN CrystalTestInternalLoopBack( PCHIP pChip );

NDIS_STATUS VchipFindIOBase( PCHIP pChip , PORT StartPort);

#endif


