//---------------------------------------------------------------------------
//
//  Copyright (C) 1996-1997. Unpublished Work of Crystal Semiconductor Corp.
//  All Rights Reserved.
//
//  THIS WORK IS AN UNPUBLISHED WORK AND CONTAINS CONFIDENTIAL,
//  PROPRIETARY AND TRADE SECRET INFORMATION OF CRYSTAL SEMICONDUCTOR.
//  ACCESS TO THIS WORK IS RESTRICTED TO (I) CRYSTAL SEMICONDUCTOR EMPLOYEES
//  WHO HAVE A NEED TO KNOW TO PERFORM TASKS WITHIN THE SCOPE OF THEIR
//  ASSIGNMENTS  AND (II) ENTITIES OTHER THAN CRYSTAL SEMICONDUCTOR WHO
//  HAVE ENTERED INTO  APPROPRIATE LICENSE AGREEMENTS.  NO PART OF THIS
//  WORK MAY BE USED, PRACTICED, PERFORMED, COPIED, DISTRIBUTED, REVISED,
//  MODIFIED, TRANSLATED, ABRIDGED, CONDENSED, EXPANDED, COLLECTED,
//  COMPILED,LINKED,RECAST, TRANSFORMED, ADAPTED IN ANY FORM OR BY ANY
//  MEANS,MANUAL, MECHANICAL, CHEMICAL, ELECTRICAL, ELECTRONIC, OPTICAL,
//  BIOLOGICAL, OR OTHERWISE WITHOUT THE PRIOR WRITTEN PERMISSION AND
//  CONSENT OF CRYSTAL SEMICONDUCTOR . ANY USE OR EXPLOITATION OF THIS WORK
//  WITHOUT THE PRIOR WRITTEN CONSENT OF CRYSTAL SEMICONDUCTOR  COULD
//  SUBJECT THE PERPETRATOR TO CRIMINAL AND CIVIL LIABILITY.
//
//---------------------------------------------------------------------------

#include "ends4isa.h"


//****************************************************************************
//
// Local type definitions and declarations
//
//****************************************************************************

//****************************************************************************
//
// Static variables declarations
//
//****************************************************************************


//****************************************************************************
//
// Function prototypes for functions local to this file
//
//****************************************************************************

ULONG  stol(
        PUCHAR szSerialnumber);



extern
DWORD
GetSerialNumber(
    IN NDIS_HANDLE ConfigHandle,
        IN NDIS_ENVIRONMENT_TYPE OSType
    )

{
    NDIS_STATUS Status;
    NDIS_STRING AdapterSerialNumberString = NDIS_STRING_CONST("Serial");
    PNDIS_CONFIGURATION_PARAMETER ReturnedValue;
        DWORD SerialNumber;

#ifdef WIN_CE
	return (DWORD)UNSPECIFIED;
#endif   
   
    NdisReadConfiguration(
          &Status,
          &ReturnedValue,
          ConfigHandle,
          &AdapterSerialNumberString,
          NdisParameterString
          );

    if (Status != NDIS_STATUS_SUCCESS) {

       return (DWORD)UNSPECIFIED;    // No serial number was configured

    } else {

       USHORT MaxLength;
       PUCHAR Buffer;

       UCHAR  zBuffer[9];
       USHORT k;

       MaxLength = ReturnedValue->ParameterData.StringData.MaximumLength;
       Buffer    = (PUCHAR) ReturnedValue->ParameterData.StringData.Buffer;

       for (k=0; k<9 && k<MaxLength; k++) {

          if (OSType == NdisEnvironmentWindows)
             zBuffer[k] = Buffer[k];    //WIN95 & WFW do NOT use UNICODE strings
          else // Windows NT
             zBuffer[k] = Buffer[k*2];  //NT uses UNICODE strings

       } /* endfor */

       zBuffer[k] = 0x00;  // null terminate the string

           SerialNumber = stol(zBuffer);

           return ( (SerialNumber == 0) ? (DWORD)UNSPECIFIED : SerialNumber );

        }

}

extern
NDIS_STATUS
GetNetworkAddress(
    IN NDIS_HANDLE ConfigHandle,
    OUT PUCHAR CurrentNetworkAddress
    )

{
	     NDIS_STATUS Status;

#ifdef WIN_CE
    NDIS_STRING MACAddrString[3]= { NDIS_STRING_CONST("MACAddress1"),
                                    NDIS_STRING_CONST("MACAddress2"), 
		                            NDIS_STRING_CONST("MACAddress3")};
    PNDIS_CONFIGURATION_PARAMETER ReturnedValue;
	USHORT MacAddr[3];
	int i;
	USHORT tmpVal;

	for (i=0; i<3; i++) {
      
        NdisReadConfiguration(
                &Status,
                &ReturnedValue,
                ConfigHandle,
                &MACAddrString[i],
                NdisParameterHexInteger
        );


         if (Status == NDIS_STATUS_SUCCESS) {
                tmpVal=(USHORT)ReturnedValue->ParameterData.IntegerData;
				MacAddr[i]= ((tmpVal & 0x00ff) << 8)| ((tmpVal & 0xff00) >> 8);
		 } else {
		      return NDIS_STATUS_FAILURE;
		 }
    } /* end for i loop */


	/* MAcAddr=0000:0000:0000 means to use EEPROM setting, so return Failure.*/
	if ( MacAddr[0] == 0 && MacAddr[1] == 0 && MacAddr[2] == 0) {
        		      return NDIS_STATUS_FAILURE;
	}

     NdisMoveMemory(CurrentNetworkAddress,
                    (unsigned char *)MacAddr,
                   (ULONG) ETH_LENGTH_OF_ADDRESS);

 
     return NDIS_STATUS_SUCCESS;


#else
        PUCHAR NetworkAddress;
        UINT Length;


        NdisReadNetworkAddress(
                &Status,
        (PVOID *)&NetworkAddress,
        &Length,
        ConfigHandle
        );

    //
    // Make sure that the address is the right length and
    // at least one of the bytes is non-zero.
    //
    if ((Status == NDIS_STATUS_SUCCESS) &&
          (Length == ETH_LENGTH_OF_ADDRESS) &&
          (( NetworkAddress[0] |
             NetworkAddress[1] |
             NetworkAddress[2] |
             NetworkAddress[3] |
             NetworkAddress[4] |
             NetworkAddress[5]) != 0)) {

        NdisMoveMemory(CurrentNetworkAddress,
                       NetworkAddress,
                      (ULONG) ETH_LENGTH_OF_ADDRESS);

    } else {

       Status = NDIS_STATUS_FAILURE;
    }

        return Status;

#endif
}

extern
BYTE
GetDuplexMode(
    IN NDIS_HANDLE ConfigHandle
    )

{
    NDIS_STATUS Status;
    NDIS_STRING DuplexModeString             = NDIS_STRING_CONST("DuplexMode"); // @251
    PNDIS_CONFIGURATION_PARAMETER ReturnedValue;
    IN BYTE         DuplexMode;

#ifdef WIN_CE


      
        DuplexMode = DUPLEX_HALF;
        NdisReadConfiguration(
                &Status,
        &ReturnedValue,
        ConfigHandle,
        &DuplexModeString,
        NdisParameterInteger
        );

	if (Status == NDIS_STATUS_SUCCESS) {
		switch (ReturnedValue->ParameterData.IntegerData) {
		               case  0:
                                DuplexMode = DUPLEX_AUTO_NEGOTIATE;
                                break;
                        case  1:
                                DuplexMode = DUPLEX_HALF;
                                break;
                        case  2:
                                DuplexMode = DUPLEX_FULL;
                                break;
                }

    }

    return DuplexMode;

#else      
      
        DuplexMode = DUPLEX_NONE;
        NdisReadConfiguration(
                &Status,
        &ReturnedValue,
        ConfigHandle,
        &DuplexModeString,
        NdisParameterString
        );

    if (Status == NDIS_STATUS_SUCCESS) {
		switch (ReturnedValue->ParameterData.StringData.Buffer[0]) {
		               case '0':
                                DuplexMode = DUPLEX_AUTO_NEGOTIATE;
                                break;
                        case '1':
                                DuplexMode = DUPLEX_HALF;
                                break;
                        case '2':
                                DuplexMode = DUPLEX_FULL;
                                break;
                }

    }

    return DuplexMode;
#endif      

}


extern
NDIS_ENVIRONMENT_TYPE
GetOSType(
    IN NDIS_HANDLE ConfigHandle
    )

{

#ifdef WIN_CE   
return(NdisEnvironmentWindowsCe);
#else   
    NDIS_STATUS Status;
    NDIS_STRING EnvironmentString = NDIS_STRING_CONST("Environment");
    PNDIS_CONFIGURATION_PARAMETER ReturnedValue;

    NdisReadConfiguration(
        &Status,
        &ReturnedValue,
        ConfigHandle,
        &EnvironmentString,
        NdisParameterString
        );

    if ((Status == NDIS_STATUS_SUCCESS) &&
            (ReturnedValue->ParameterType == NdisParameterInteger))

       return (ReturnedValue->ParameterData.IntegerData);

        else

           return (NdisEnvironmentWindows);

#endif   
}


ULONG  stol(
        PUCHAR szSerialnumber)
{

    ULONG  value=0;

        for (; *szSerialnumber != 0; szSerialnumber++) {

        value <<= 4;

                if ((*szSerialnumber >= '0') && (*szSerialnumber <= '9')) {

               value += *szSerialnumber - '0';

                } else if ((*szSerialnumber >= 'a') && (*szSerialnumber <= 'f')) {

               value += *szSerialnumber - 'a' + 10;

                } else if ((*szSerialnumber >= 'A') && (*szSerialnumber <= 'F')) {

               value += *szSerialnumber - 'A' + 10;
        }
        }

        return value;

}   /* end stol */


