  This file describes the steps to build the CS8900 NDIS 4 Driver for Windows
  OS (2000, NT, 98, 95) and WinCE.

=================================================================================
======================  Defines Used in Compiler  ===============================
=================================================================================

The follwoing defines can be used in the sources file.


ALIGNMENT_32BITS

The define is for SH3 32bit-alignment.  If your processor needs 32 bit aligment
in CopyPacketToChip() like SH3, use this define.  The define will increase process
time to transmit a frame.
 

V8920

If your chip is 8920 and you want to enable the Received_Packet_Look_Ahead option,
use this define.


EARLY_INTERRUPTS

If you want to enable the early interrupt function on the chip, use the definition.
The function is CPU_intensive.

The default C_DEFINES used in the Src4win for Windows OS is 
C_DEFINES=$(C_DEFINES) -DNDIS_MINIPORT_DRIVER -DV8920 -DEARLY_INTERRUPTS

and the default C_DEFINES used in the Src4ce for WinCE is 
C_DEFINES=$(C_DEFINES) -DNDIS_MINIPORT_DRIVER -DNDIS40_MINIPORT -DWIN_CE

For Network Card without EEPROM: User can assigne the default values in the
AssignedUserDefinedConfig() function in the ends4isa.c file.


=================================================================================
==============  Build the CS8900 NDIS 4 Driver for Windows OS  ==================
=================================================================================

1. Got to the directory \ddk\src\network.
2. Make subdirectories .\ends4isa, and .\ends4isa\i386\free.
3. Copy the source files to the ends4isa directory.
4. Edit the Src4win file to set the compiler flag options as described above.
5. Start the Free Build Environments Shell.
6. In the Free Build Environments window, go to the ends4isa directory.
7. Copy the Src4win file to the Sources file.
   copy src4win sources
8. Copy the MAKEFILE.win to MAKEFILE.
    copy MAKEFILE.win MAKEFILE
9. Type "bld4win".  The output ends4isa.sys will reside in .\i386\free
    



=================================================================================
=============  Build the CS8900 NDIS DLL Lib for WinCE 2.12   ===================
=================================================================================

If your WinCE version is 2.x:

1. Got to the directory \WinCE_Directory\Public\Common\Oak\Drivers\NetCard
2. Make a subdirectory CS8900
3. Copy the source files to the CS8900 directory.
4. Edit the Src4ce file to set the compiler flag options as described above.
5. Start the MinShell (in the WinCE Platform builder) for the type of
   your processor.
6. In the MinShell window, go to the CS8900 directory.
7. Copy the Src4ce file to the Sources file.
   copy src4ce sources
8. Copy the MAKEFILE.ce to MAKEFILE.
    copy MAKEFILE.ce MAKEFILE
9. Type "build".  The output Ends4Isa.dll will reside in 
    \WinCE_Directory\Platform\Odo\target\YourCpuType\YourCpuSubType\CE\Retail
10. Modify your Project.reg. Please read the segment "Ends4Isa DLL Example
    for WinCE Registry" in this file.


=================================================================================
============    Build the CS8900 NDIS DLL Lib for WinCE 3.0   ===================
=================================================================================

If your WinCE version is 3.x:

1. Got to the directory \WinCE_Directory\Public\Common\Oak\Drivers\NetCard
2. Make a subdirectory CS8900
3. Copy the source files to the CS8900 directory.
4. Edit the Src4ce file to set the compiler flag options as described above.
5. Copy the Src4ce file to the Sources file.
     copy src4ce sources
  Copy the MAKEFILE.ce to MAKEFILE.
     copy MAKEFILE.ce MAKEFILE
6. Start the CE Platform Builder then click File -> Open Workspace.  
   Select your Platform.
8. Add CS8900.cec to Catalog:
   Click File -> Manage Platform Builder Component -> Import new.
   Go to \WinCE_Directory\Public\Common\Oak\Drivers\NetCard\CS8900
   and select CS8900.cec.
9. Click View -> Catalog. The CS8900Ethernet component is in
   the \Drivers. directory.
10. Add CS8900Ethernet to your platform:
    Click CS8900Ethernet in Catalog then click Platform -> Insert
	-> Selected Catalog Component.
12. Modify Project.bib.  Add the following line to Project.bib in the
    MODULES segment:
	   Ends4Isa.dll       $(_FLATRELEASEDIR)\Ends4Isa.dll  NK  SH
13. Modify your Project.reg. Please read the segment "Ends4Isa DLL Example
    for WinCE Registry" in this file.
14. The step is optional. Build the CS8900 Dll driver Ends4Isa.dll:
    Click View -> Worksapce -> Platform -> Component -> CS8900Ethernet.
    Click Build -> Build Selected Components.
    The output Ends4Isa.dll will reside in 
    \WinCE_Directory\Platform\YourPlatform\target\YourCpuType\YourCpuSubType\CE\Debug
15. Build the nk.bin image for download:
    Click Build -> Rebuild Platform.


=================================================================================
================== Ends4Isa DLL Example for WinCE Registry ===================
=================================================================================

The following is an example to include Ends4Isa.dll in the WinCE registry.
Add the following segment to the Project.reg file for WinCE to load 
Ends4Isa.dll when booting.

In the segment [HKEY_LOCAL_MACHINE\Comm\CS89001\Parms],
the Ethernet Physical Address stored in EEPROM can be overridden by the
MACAddress entry, and the Duplex Mode can be specified by the DuplexMode entry.

; @CESYSGEN IF CE_MODULES_ENDS4ISA
[HKEY_LOCAL_MACHINE\Comm\ENDS4ISA]
   "DisplayName"="CS8900 Ethernet Driver"
   "Group"="NDIS"
   "ImagePath"="ends4isa.dll"

[HKEY_LOCAL_MACHINE\Comm\ENDS4ISA\Linkage]
   "Route"=multi_sz:"ENDS4ISA1"

[HKEY_LOCAL_MACHINE\Comm\ENDS4ISA1]
   "DisplayName"="CS8900 Ethernet Driver"
   "Group"="NDIS"
   "ImagePath"="ends4isa.dll"

[HKEY_LOCAL_MACHINE\Comm\ENDS4ISA1\Parms]
   ; BusNumber=0 and BusType=1 are proper for ix86 ISA bus.
   ; Change the entries depend on your hardware.
   ; Do NOT delete BusNumber or BusType, otherwise ends4isa.dll won't be loaded.
   "BusNumber"=dword:0
   "BusType"=dword:1
   ; DuplexMode: 0:AutoDetect; 1:HalfDuplex; 2:FullDuplex.
   "DuplexMode"=dword:1
   ; The Ethernet Physical Address. For example,
   ; Ethernet Address 00:24:20:10:bf:03 is MACAddress1=0024,
   ; MACAddress2=2010,and MACAddress3=bf03.
   ; MACAddress=0000:0000:0000 means to read it from EEPROM.
   "MACAddress1"=dword:0000
   "MACAddress2"=dword:0000
   "MACAddress3"=dword:0000

[HKEY_LOCAL_MACHINE\Comm\ENDS4ISA1\Parms\TcpIp]
   ; This should be MULTI_SZ
   "DefaultGateway"=""
   ; This should be SZ... If null it means use LAN, else WAN and Interface.
   "LLInterface"=""
   ; Use zero for broadcast address? (or 255.255.255.255)
   "UseZeroBroadcast"=dword:0
   ; Thus should be MULTI_SZ, the IP address list
   "IpAddress"="0.0.0.0"
   ; This should be MULTI_SZ, the subnet masks for the above IP addresses
   "Subnetmask"="0.0.0.0"
   "EnableDHCP"=dword:1

[HKEY_LOCAL_MACHINE\Comm\Tcpip\Linkage]
   ; This should be MULTI_SZ
   ; This is the list of llip drivers to load
   "Bind"=multi_sz:"Ends4Isa1"

; @CESYSGEN ENDIF CE_MODULES_ENDS4ISA

