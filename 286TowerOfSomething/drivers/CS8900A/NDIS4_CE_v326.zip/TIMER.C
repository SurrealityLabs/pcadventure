//---------------------------------------------------------------------------
//
//  Copyright (C) 1996-1997. Unpublished Work of Crystal Semiconductor Corp.
//  All Rights Reserved.
//
//  THIS WORK IS AN UNPUBLISHED WORK AND CONTAINS CONFIDENTIAL,
//  PROPRIETARY AND TRADE SECRET INFORMATION OF CRYSTAL SEMICONDUCTOR.
//  ACCESS TO THIS WORK IS RESTRICTED TO (I) CRYSTAL SEMICONDUCTOR EMPLOYEES
//  WHO HAVE A NEED TO KNOW TO PERFORM TASKS WITHIN THE SCOPE OF THEIR
//  ASSIGNMENTS  AND (II) ENTITIES OTHER THAN CRYSTAL SEMICONDUCTOR WHO
//  HAVE ENTERED INTO  APPROPRIATE LICENSE AGREEMENTS.  NO PART OF THIS
//  WORK MAY BE USED, PRACTICED, PERFORMED, COPIED, DISTRIBUTED, REVISED,
//  MODIFIED, TRANSLATED, ABRIDGED, CONDENSED, EXPANDED, COLLECTED,
//  COMPILED,LINKED,RECAST, TRANSFORMED, ADAPTED IN ANY FORM OR BY ANY
//  MEANS,MANUAL, MECHANICAL, CHEMICAL, ELECTRICAL, ELECTRONIC, OPTICAL,
//  BIOLOGICAL, OR OTHERWISE WITHOUT THE PRIOR WRITTEN PERMISSION AND
//  CONSENT OF CRYSTAL SEMICONDUCTOR . ANY USE OR EXPLOITATION OF THIS WORK
//  WITHOUT THE PRIOR WRITTEN CONSENT OF CRYSTAL SEMICONDUCTOR  COULD
//  SUBJECT THE PERPETRATOR TO CRIMINAL AND CIVIL LIABILITY.
//
//---------------------------------------------------------------------------

#include "ends4isa.h"



WORD  VominiStartup(PVOMINIPDATA pOSD, NDIS_HANDLE MiniportAdapterHandle )
{
   WORD Result = SUCCESS;
   WORD i;

      NdisZeroMemory(pOSD, sizeof(VOMINIPDATA));
      for (i=0; i<MAX_TIMERS; i++) {

         pOSD->Timers[i].TimerActive = FALSE;
         pOSD->Timers[i].TimerID = i;

         NdisMInitializeTimer(
            &pOSD->Timers[i].TimerHandle,
            MiniportAdapterHandle,
            VominiTimerDaemon,
            &pOSD->Timers[i]
            );

      } /* endfor */
   return Result;
};

void  VominiShutdown( PVOID pOSD )
{
   WORD i;
   BOOLEAN Cancelled;

   for (i=0; i<MAX_TIMERS; i++) {
      if (((PVOMINIPDATA)pOSD)->Timers[i].TimerActive) {
         NdisMCancelTimer( &(((PVOMINIPDATA)pOSD)->Timers[i].TimerHandle),
                           &Cancelled );
      } /* endif */
   } /* endfor */

};

WORD  VominiStartTimer( PCHIP pChip, TIMER_EVENT_HANDLER pEventHandler,
           DWORD mSecondDuration, PWORD pTimerID, PVOID pParm )
{
   WORD Result = SUCCESS;
   WORD i;

   PVPMINIPDATA pvMini_Context = (PVPMINIPDATA)(pChip->pPSD); 
   NDIS_HANDLE MiniportAdapterHandle = pvMini_Context->vpMiniportAdapterHandle; 
   PVOMINIPDATA pOSD = pChip->pOSD;

   for (i=0; i<MAX_TIMERS; i++) {
      if (pOSD->Timers[i].TimerActive == FALSE) {
         break;
      } /* endif */
   } /* endfor */

   if (i < MAX_TIMERS) {
      *pTimerID = i;
      pOSD->Timers[i].pChip = pChip;
      pOSD->Timers[i].pParm = pParm;
      pOSD->Timers[i].TimerActive = TRUE;
      pOSD->Timers[i].TimerRoutine = pEventHandler;
      NdisMSetTimer( &(pOSD->Timers[i].TimerHandle), mSecondDuration );
   } else {
      Result = FAILURE;
   } /* endif */

   return Result;

};

void  VominiStopTimer( PCHIP pChip, WORD TimerID )
{
   BOOLEAN Cancelled;

   PVPMINIPDATA pvMini_Context = (PVPMINIPDATA)(pChip->pPSD); 
   NDIS_HANDLE MiniportAdapterHandle = pvMini_Context->vpMiniportAdapterHandle; 
   PVOMINIPDATA pOSD = pChip->pOSD;

   NdisMCancelTimer( &(pOSD->Timers[TimerID].TimerHandle), &Cancelled );
   pOSD->Timers[TimerID].TimerActive = FALSE;

};

VOID
VominiTimerDaemon(
   IN PVOID SystemSpecific1,
   IN PVOID Context,
   IN PVOID SystemSpecific2,
   IN PVOID SystemSpecific3
   )

{
   PVOMINITIMER pTimer = (PVOMINITIMER)Context;
   pTimer->TimerActive = FALSE;
   pTimer->TimerRoutine( pTimer->pChip, pTimer->TimerID, pTimer->pParm );

}

VOID VominiDelay( DWORD mSecondDuration )
{
   DWORD i;
   DWORD uSecondDuration = mSecondDuration*1000;

   for (i=0; i<uSecondDuration/50; i++) {
      NdisStallExecution( (DWORD) (50) );
   } /* endfor */
}




