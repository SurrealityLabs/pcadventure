  This file describes the steps to build the CS8900 NDIS 4 Driver for Windows
  OS (2000, NT, 98, 95) and WinCE. The last section describes the required
  changes for ARM and SH3 processors. 

=================================================================================
======================  Defines Used in Compiler  ===============================
=================================================================================

The following defines can be used in the sources file.

1. ARM_PROCESSOR

  If your processor type is ARM or Strong ARM, and OS is WinCE, ARM_PROCESSOR must be
  defined in the sources file.  For example:
  CDEFINES=$(CDEFINES) -DNDIS_MINIPORT_DRIVER -DNDIS40_MINIPORT -DWIN_CE -DARM_PROCESSOR 

  For ARM user, please read the section "Required Modifications for ARM".


2. SH3_PROCESSOR

  If your processor type is SH3, and OS is WinCE, SH3_PROCESSOR must be
  defined in the sources file.  For example:

  CDEFINES=$(CDEFINES) -DNDIS_MINIPORT_DRIVER -DNDIS40_MINIPORT -DWIN_CE -DSH3_PROCESSOR 

  For SH3 user, please read the section "Required Modifications for SH3".


3. V8920

  If your chip is 8920 and you want to enable the Received_Packet_Look_Ahead option,
  use this define.


4. EARLY_INTERRUPTS

  If you want to enable the early interrupt function on the chip, use the definition.
  The function is CPU_intensive.


The default C_DEFINES used in the Src4win for Windows OS is 
C_DEFINES=$(C_DEFINES) -DNDIS_MINIPORT_DRIVER -DV8920 -DEARLY_INTERRUPTS

and the default C_DEFINES used in the Src4ce for WinCE is 
C_DEFINES=$(C_DEFINES) -DNDIS_MINIPORT_DRIVER -DNDIS40_MINIPORT -DWIN_CE

For Network Card without EEPROM: User can assign the default values in the
AssignedUserDefinedConfig() function in the ends4isa.c file.



=================================================================================
==============  Build the CS8900 NDIS 4 Driver for Windows OS  ==================
=================================================================================

1. Got to the directory \ddk\src\network.
2. Make subdirectories .\ends4isa, and .\ends4isa\i386\free.
3. Copy the source files to the ends4isa directory.
4. Edit the Src4win file to set the compiler flag options as described above.
5. Start the Free Build Environments Shell.
6. In the Free Build Environments window, go to the ends4isa directory.
7. Copy the Src4win file to the Sources file.
   copy src4win sources
8. Copy the MAKEFILE.win to MAKEFILE.
    copy MAKEFILE.win MAKEFILE
9. Type "bld4win".  The output ends4isa.sys will reside in .\i386\free
    



=================================================================================
=============  Build the CS8900 NDIS DLL Lib for WinCE 2.12   ===================
=================================================================================

If your WinCE version is 2.x:

1. Got to the directory \WinCE_Directory\Public\Common\Oak\Drivers\NetCard
2. Make a subdirectory CS8900
3. Copy the source files to the CS8900 directory.
4. Edit the Src4ce file to set the compiler flag options as described above.
5. Start the MinShell (in the WinCE Platform builder) for the type of
   your processor.
6. In the MinShell window, go to the CS8900 directory.
7. Copy the Src4ce file to the Sources file.
   copy src4ce sources
8. Copy the MAKEFILE.ce to MAKEFILE.
    copy MAKEFILE.ce MAKEFILE
9. Type "build".  The output Ends4Isa.dll will reside in 
    \WinCE_Directory\Platform\Odo\target\YourCpuType\YourCpuSubType\CE\Retail
10. Modify your Project.reg. Please read the segment "Ends4Isa DLL Example
    for WinCE Registry" in this file.



=================================================================================
============    Build the CS8900 NDIS DLL Lib for WinCE 3.0   ===================
=================================================================================

If your WinCE version is 3.x:

1. Got to the directory \WinCE_Directory\Public\Common\Oak\Drivers\NetCard
2. Make a subdirectory CS8900
3. Copy the source files to the CS8900 directory.
4. Edit the Src4ce file to set the compiler flag options as described above.
5. Copy the Src4ce file to the Sources file.
     copy src4ce sources
  Copy the MAKEFILE.ce to MAKEFILE.
     copy MAKEFILE.ce MAKEFILE
6. Start the CE Platform Builder then click File -> Open Workspace.  
   Select your Platform.
8. Add CS8900.cec to Catalog:
   Click File -> Manage Platform Builder Component -> Import new.
   Go to \WinCE_Directory\Public\Common\Oak\Drivers\NetCard\CS8900
   and select CS8900.cec.
9. Click View -> Catalog. The CS8900Ethernet component is in
   the \Drivers. directory.
10. Add CS8900Ethernet to your platform:
    Click CS8900Ethernet in Catalog then click Platform -> Insert
	-> Selected Catalog Component.
12. Modify Project.bib.  Add the following line to Project.bib in the
    MODULES segment:
	   Ends4Isa.dll       $(_FLATRELEASEDIR)\Ends4Isa.dll  NK  SH
13. Modify your Project.reg. Please read the segment "Ends4Isa DLL Example
    for WinCE Registry" in this file.
14. The step is optional. Build the CS8900 Dll driver Ends4Isa.dll:
    Click View -> Workspace -> Platform -> Component -> CS8900Ethernet.
    Click Build -> Build Selected Components.
    The output Ends4Isa.dll will reside in 
    \WinCE_Directory\Platform\YourPlatform\target\YourCpuType\YourCpuSubType\CE\Debug
15. Build the nk.bin image for download:
    Click Build -> Rebuild Platform,
	then Build -> Make Image.



=================================================================================
================== Ends4Isa DLL Example for WinCE Registry ===================
=================================================================================

The following is an example to include Ends4Isa.dll in the WinCE registry.
Add the following segment to the Project.reg file for WinCE to load 
Ends4Isa.dll when booting.

In the segment [HKEY_LOCAL_MACHINE\Comm\ENDS4ISA1\Parms],
the Ethernet Physical Address stored in EEPROM can be overridden by the
MACAddress entry, and the Duplex Mode can be specified by the DuplexMode entry.

; @CESYSGEN IF CE_MODULES_ENDS4ISA
[HKEY_LOCAL_MACHINE\Comm\ENDS4ISA]
   "DisplayName"="CS8900 Ethernet Driver"
   "Group"="NDIS"
   "ImagePath"="ends4isa.dll"

[HKEY_LOCAL_MACHINE\Comm\ENDS4ISA\Linkage]
   "Route"=multi_sz:"ENDS4ISA1"

[HKEY_LOCAL_MACHINE\Comm\ENDS4ISA1]
   "DisplayName"="CS8900 Ethernet Driver"
   "Group"="NDIS"
   "ImagePath"="ends4isa.dll"

[HKEY_LOCAL_MACHINE\Comm\ENDS4ISA1\Parms]
   ; BusNumber=0 and BusType=1 are proper for ix86 ISA bus.
   ; Change the entries depend on your hardware.
   ; Do NOT delete BusNumber or BusType, otherwise ends4isa.dll won't be loaded.
   "BusNumber"=dword:0
   "BusType"=dword:1
   ; DuplexMode: 0:AutoDetect; 1:HalfDuplex; 2:FullDuplex.
   "DuplexMode"=dword:1
   ; The Ethernet Physical Address. For example,
   ; Ethernet Address 00:24:20:10:bf:03 is MACAddress1=0024,
   ; MACAddress2=2010,and MACAddress3=bf03.
   ; MACAddress=0000:0000:0000 means to read it from EEPROM.
   "MACAddress1"=dword:0000
   "MACAddress2"=dword:0000
   "MACAddress3"=dword:0000

[HKEY_LOCAL_MACHINE\Comm\ENDS4ISA1\Parms\TcpIp]
   ; This should be MULTI_SZ
   "DefaultGateway"=""
   ; This should be SZ... If null it means use LAN, else WAN and Interface.
   "LLInterface"=""
   ; Use zero for broadcast address? (or 255.255.255.255)
   "UseZeroBroadcast"=dword:0
   ; Thus should be MULTI_SZ, the IP address list
   "IpAddress"="0.0.0.0"
   ; This should be MULTI_SZ, the subnet masks for the above IP addresses
   "Subnetmask"="0.0.0.0"
   "EnableDHCP"=dword:1

[HKEY_LOCAL_MACHINE\Comm\Tcpip\Linkage]
   ; This should be MULTI_SZ
   ; This is the list of llip drivers to load
   "Bind"=multi_sz:"Ends4Isa1"

; @CESYSGEN ENDIF CE_MODULES_ENDS4ISA



=================================================================================
===============         Required Modifications for SH3           ================
=================================================================================

The CS8900 WinCE driver supports only the IO mode. The SH3's address lines should be 
connected to CS8900 in a special way to enable IO mode on CS8900.  Thus, the SH3's
address lines become  CS8900's IO port lines.

First, SH3_PROCESSOR must be defined in the sources file:

CDEFINES=$(CDEFINES) -DNDIS_MINIPORT_DRIVER -DNDIS40_MINIPORT -DWIN_CE -DSH3_PROCESSOR 


Second, change the values of CS8900_INTERRUPT_REQUEST_PIN_NUM and 
CS8900_IOPORT_MEM_ADDR in cshrd.h. 

The CS8900 has four interrupt request output pins that can be connected directly 
to Processor. Only one interrupt output pin is connected to SH3. 
CS8900_INTERRUPT_PIN_NUM defines which interrupt pin is used.
 0:  INTRQ0
 1:  INTRQ1
 2:  INTRQ2
 3:  INTRQ3
#define CS8900_INTERRUPT_REQUEST_PIN_NUM     0 /* or other number: 0-3 */

For SH3, CS8900_IOPORT_MEM_ADDR is the physical memory address of the CS8900 IO 
port according to your target board:

#define CS8900_IOPORT_MEM_ADDR     0x????????L



Third, you need to modify WinCE's kernel to hook up the Ethernet Interrupt to the
SH3 processor. Please read WinCE's on-line help first to get some ISR ideas.  For
WinCE 3.0, the ISR information is in

Operating System Development -> Costuming a Platform -> Creating an OEM Adaptation Layer
-> Enhancing OAL Functionality -> Implementing an ISR


The following instructions will give you ideas how to modify the 
WinCE kernel. 
 
The following steps describes what to do to hookup IRQ2 to its service routine:
 
1) In OEMInit( ) function in platform\YourPlatform\kernel\HAL\cfwp2.c, add
   {
     // Set Priority 4 to Ether_ISR, but you can choose different
       priority based on your platform.
       HookInterrupt(4, Ether_ISR);
   }

2) In OEMInterruptEnable/Disable/Done() functions in cfwp2.c, add
   {
    case SYSINTR_ETHER: /*It may not work for your processor.  Please find out the
     way to disable and enable the Ethernet interrupt. */
    _REGW (IPRC) = (_REGW(IPRC) & ETHERNET_IPRC_IRQ2_MASK)|ETHERNET_IPRC_IRQ2_INT;

    // for disable function it will be
    //_REGW (IPRC) = (_REGW(IPRC) & ETHERNET_IPRC_IRQ2_MASK);
    break;
   }

3) Create an ISR routine Ether_ISR in the "fwp2.src" file
   under .\Hal\Shx directory.

  .export _Ether_ISR
  LEAF_ENTRY _Ether_ISR
  mov.l #IPRC,R6 ; Interrupt priority register
  C (IPRC)
  mov.w @R6,R0
  mov.l #IPRC_IRQ2_MASK,R1 ;
  and R1,R0 ; Set IRQ2 to priority 0
  mov.w R0,@R6 ; Mask IRQ2
  ;
  mov.l #IRR0,R6 ; Interrupt request register 0
  (IRR0)
  mov.b @R6,R0
  mov #(~IRR0_IRQ2R & 0xFF),R0 ; Clear IRQ2 interrupt flag
  and R1,R0 ;
  mov.b R0,@R6 ;
  rts
  mov #SYSINTR_ETHER, r0

4) Put "SYSINTR_ETHER" in both "OALintr.h" and "OALintr.inc" files.

  SYSINTR_ETHER: SYSINTR_FIRMWARE+10
  SYSINTR_ETHER: .equ SYSINTR_FIRMWARE+10

  They are the interrupt IDs used by the CE kernel. SYSINTR_ETHER is independent from 
  the interrupt line connection between Processor and MAC.

5) If you can not use SYSINTR_ETHER = SYSINTR_FIRMWARE+10, and would like to define
   your own value, make sure your define isn't conflict with other interrupts.

   Assume the followings are the new defines:
    
   SYSINTR_ETHER: SYSINTR_FIRMWARE+??
   SYSINTR_ETHER: .equ SYSINTR_FIRMWARE+??

   In CrystalInitialize() in Ends4Isa.c, change one line from:

   #if ( defined(ARM_PROCESSOR) || defined(SH3_PROCESSOR))
	  /* Since SYSINTR_ETHER = SYSINTR_FIRMWARE+10 defined in OALint.h, 
	     pChip->Config.IntLine must be 10 here for CE kernel to map CS8900 ISR
	     to SYSINTR_ETHER. */
      pChip->Config.IntLine = 10; //Change this line only.
 
   to:

    pChip->Config.IntLine = ?? ; //SYSINTR_ETHER - SYSINTR_FIRMWARE
 


=================================================================================
===============         Required Modifications for ARM           ================
=================================================================================

The CS8900 WinCE driver supports only the IO mode. The ARM's address lines should be 
connected to CS8900 in a special way to enable IO mode on CS8900.  Thus, the ARM's
address lines become  CS8900's IO port lines. 

First, ARM_PROCESSOR must be defined in the sources file:
CDEFINES=$(CDEFINES) -DNDIS_MINIPORT_DRIVER -DNDIS40_MINIPORT -DWIN_CE -DARM_PROCESSOR 

Second, change the values of CS8900_INTERRUPT_REQUEST_PIN_NUM and 
CS8900_IOPORT_MEM_ADDR in cshrd.h. 

The CS8900 has four interrupt request output pins that can be connected directly 
to Processor. Only one interrupt output pin is connected to ARM.
CS8900_INTERRUPT_PIN_NUM defines which interrupt pin is used.
 0:  INTRQ0
 1:  INTRQ1
 2:  INTRQ2
 3:  INTRQ3
#define CS8900_INTERRUPT_REQUEST_PIN_NUM     0 /* or other number: 0-3 */

For ARM and Strong ARM, CS8900_IOPORT_MEM_ADDR is the un-buffered & un-cashed 
virtual address(range 0xA0000000-0xBFFFFFFF). Its buffered & cashed virtual address 
(ragne 0x80000000-0x9FFFFFFF) should be defined in OEMAddressTable.

#define CS8900_IOPORT_MEM_ADDR     0x????????L


Third, you need to modify WinCE's kernel to hook up the Ethernet Interrupt to the
ARM processor.  Please read WinCE's on-line help first to get some ISR ideas.  For
WinCE 3.0, the ISR information is in

Operating System Development -> Costuming a Platform -> Creating an OEM Adaptation Layer
-> Enhancing OAL Functionality -> Implementing an ISR

The following instructions will give you ideas how to modify the 
WinCE kernel.
 
1) In OEMInterruptEnable/Disable/Done() functions in 
   platform\YourPlatform\kernel\HAL\cfwp2.c, modify the code to enable and
   disable the Ethernet interrupt according to your target board:

   {
    case SYSINTR_ETHER: /*It may not work for your processor.  Please find out the
     way to disable and enable the Ethernet interrupt. */
     _REGW(IPRC) = (_REGW(IPRC) & ETHERNET_IPRC_IRQ2_MASK)|ETHERNET_IPRC_IRQ2_INT;

     // for disable function it will be
     //_REGW (IPRC) = (_REGW(IPRC) & ETHERNET_IPRC_IRQ2_MASK);
     break;
    }


2) Put "SYSINTR_ETHER" in both "OALintr.h" and "OALintr.inc" files.

   SYSINTR_ETHER: SYSINTR_FIRMWARE+10
   SYSINTR_ETHER: .equ SYSINTR_FIRMWARE+10

   They are the interrupt IDs used by the CE kernel. SYSINTR_ETHER is independent from 
   the interrupt line connection between Processor and MAC.


3) If you can not use SYSINTR_ETHER = SYSINTR_FIRMWARE+10, and would like to define
   your own value, make sure your define isn't conflict with other interrupts.

   Assume the followings are the new defines:
    
   SYSINTR_ETHER: SYSINTR_FIRMWARE+??
   SYSINTR_ETHER: .equ SYSINTR_FIRMWARE+??

   In CrystalInitialize() in Ends4Isa.c, change one line from:

   #if ( defined(ARM_PROCESSOR) || defined(SH3_PROCESSOR))
	  /* Since SYSINTR_ETHER = SYSINTR_FIRMWARE+10 defined in OALint.h, 
	     pChip->Config.IntLine must be 10 here for CE kernel to map CS8900 ISR
	     to SYSINTR_ETHER. */
      pChip->Config.IntLine = 10; //Change this line only.
 
   to:

    pChip->Config.IntLine = ?? ; //SYSINTR_ETHER - SYSINTR_FIRMWARE
 
 
4) If your ARM type is SA1110, ARM920, or ARM720, look at INT1110.c, INT920.c, or INT720O.c
   in the .\HAL\ARM directory respectively. Modify the following code segment in 
   EMInterruptHandler() so  ArmInterruptHandler() can be correctly called when Interrupts
   are coming.
     
  The following code is extracted from SA1110.c. It needs modifications to
  correctly read and write interrupt registers
		  .
	  } else if(my_sa1100_intreg & GPIO_1) {
      	//Clear the GPIO interrupt
		sa1100_gpio->gedr = GPIO_1;
	    
        //
        // For SA1100, we allow the system tick only to interrupt any of the 
        // Odo FPGA interrupt handlers. This is to show the use of nested 
        // interrupts on ARM.
        //
        dwSavedICMR = sa1100_int_ctlr->icmr;
		sa1100_int_ctlr->icmr = OS_TIMER0;
        INTERRUPTS_ON();
        
        // Call common FPGA interrupt handler code with TIMER interrupt enabled.
	    dwRet = ArmInterruptHandler();
        
        INTERRUPTS_OFF();
		sa1100_int_ctlr->icmr = dwSavedICMR;
        
	    return dwRet;
    }


5) Modify the code segment in ArmInterruptHandler() in the .\HAL\ARM\ARMint.c:

    else if ( (my_odo_isr_reg & odo_etherIntr) != 0 )
    {
        // mask the debug Ethernet interrupt
        odo_cpu->odo_cpuMr &= ~odo_etherIntr;
        GOTO_EXIT(SYSINTR_ETHER);
    }
 
    so it can properly determine if there is an Ethernet Interrupt. If yes, then 
	clear the Ethernet Interrupt mask or do nothing depending on your target board.
	GOTO_EXIT(SYSINTR_ETHER) must be called if there is an Ethernet Interrupt.


6) Since WinCE's ISR can process only one Interrupt at a time, 
   modify the code segment in ArmInterruptHandler() in the .\HAL\ARM\ARMint.c:

EXIT: 
    //
    // Since all of the FPGA interrupts are multiplexed on one signal to the CPU
    // we need to be careful when multiple interrupts are pending. We have
    // cleared the interrupt at the CPU early on. If there's another interrupt
    // that needs processing, we need to force a new interrupt. We do this by
    // clearing the cpuMr register and reinstating it.
    //
    wMrTemp = odo_cpu->odo_cpuMr;
    odo_cpu->odo_cpuMr = 0x0000;
    odo_cpu->odo_cpuMr = wMrTemp;
    return (iRet);

    according to your target board so the pending interrupts can be processed 
	next time.
