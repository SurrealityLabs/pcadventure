
/****************************************************************************
  (C) Unpublished Work of ZeitNet, Inc.  All  Rights Reserved.              *
                                                                            *
    THIS WORK IS AN UNPUBLISHED WORK AND CONTAINS CONFIDENTIAL,             *
    PROPRIETARY AND TRADE SECRET INFORMATION OF ZEITNET, INC.  ACCESS       *
    TO THIS WORK IS RESTRICTED TO (I) ZEITNET EMPLOYEES WHO HAVE A          *
    NEED TO KNOW TO PERFORM TASKS WITHIN THE SCOPE OF THEIR ASSIGNMENTS     *
    AND (II) ENTITIES OTHER THAN ZEITNET WHO HAVE ENTERED INTO              *
    APPROPRIATE LICENSE AGREEMENTS.  NO PART OF THIS WORK MAY BE USED,      *
    PRACTICED, PERFORMED, COPIED, DISTRIBUTED, REVISED, MODIFIED,           *
    TRANSLATED, ABRIDGED, CONDENSED, EXPANDED, COLLECTED, COMPILED,         *
    LINKED,RECAST, TRANSFORMED, ADAPTED IN ANY FORM OR BY ANY MEANS,        *
      MANUAL, MECHANICAL, CHEMICAL, ELECTRICAL, ELECTRONIC, OPTICAL,        *
      BIOLOGICAL, OR OTHERWISE WITHOUT THE PRIOR WRITTEN PERMISSION AND     *
    CONSENT OF ZEITNET. ANY USE OR EXPLOITATION OF THIS WORK WITHOUT        *
    THE PRIOR WRITTEN CONSENT OF ZEITNET COULD SUBJECT THE PERPETRATOR      *
    TO CRIMINAL AND CIVIL LIABILITY.                                        *
                                                                            *
****************************************************************************/
//---------------------------------------------------------------------------
//
//  Copyright (C) 1996-1997. Unpublished Work of Crystal Semiconductor Corp.
//  All Rights Reserved.
//
//  THIS WORK IS AN UNPUBLISHED WORK AND CONTAINS CONFIDENTIAL,
//  PROPRIETARY AND TRADE SECRET INFORMATION OF CRYSTAL SEMICONDUCTOR.
//  ACCESS TO THIS WORK IS RESTRICTED TO (I) CRYSTAL SEMICONDUCTOR EMPLOYEES
//  WHO HAVE A NEED TO KNOW TO PERFORM TASKS WITHIN THE SCOPE OF THEIR
//  ASSIGNMENTS  AND (II) ENTITIES OTHER THAN CRYSTAL SEMICONDUCTOR WHO
//  HAVE ENTERED INTO  APPROPRIATE LICENSE AGREEMENTS.  NO PART OF THIS
//  WORK MAY BE USED, PRACTICED, PERFORMED, COPIED, DISTRIBUTED, REVISED,
//  MODIFIED, TRANSLATED, ABRIDGED, CONDENSED, EXPANDED, COLLECTED,
//  COMPILED,LINKED,RECAST, TRANSFORMED, ADAPTED IN ANY FORM OR BY ANY
//  MEANS,MANUAL, MECHANICAL, CHEMICAL, ELECTRICAL, ELECTRONIC, OPTICAL,
//  BIOLOGICAL, OR OTHERWISE WITHOUT THE PRIOR WRITTEN PERMISSION AND
//  CONSENT OF CRYSTAL SEMICONDUCTOR . ANY USE OR EXPLOITATION OF THIS WORK
//  WITHOUT THE PRIOR WRITTEN CONSENT OF CRYSTAL SEMICONDUCTOR  COULD
//  SUBJECT THE PERPETRATOR TO CRIMINAL AND CIVIL LIABILITY.
//
//---------------------------------------------------------------------------

/*++
Copyright (c) 1994  ZeitNet Inc.

Module Name:
    cshrd.h

Abstract:
    This file contains the hardware-related definitions for
    the CRYSTAL driver.


Author:
    Sateesh. A Kumar(Sat).
    Creation date 11-Mar-1994

Environment:
    This driver is expected to work in DOS, OS2 and NT at the equivalent
    of kernel mode.

    Architecturally, there is an assumption in this driver that we are
    on a little endian machine.

Revision History:


12 November 1994 10:00  ASK/PI
  -  Modified PACKET_PAGE structures to reflect changes incorporated
       in data sheet of CS8921 v0.21 October 6 1994.

  -  Structure for PnP (Plug and Play) registers  were  defined.

  -  A new bit CRYSTAL_LCR_NWAY_ENABLE  is introduced in Line control Register.

  -  A new bit CRYSTAL_LCR_NWAY_PULSES  is introduced in Line control Register.

  -  A new bit CRYSTAL_LSR_NWAY_FDX     is introduced in Line Status Register.

  -  A new bit CRYSTAL_LSR_NWAY_ACTIVE is introduced in Line Status Register.

   By                Date
  Prashanth (PI)     5-1-95

Struture for CRYSTAL_DMA_FRAME        is defined

   By      : Prashanth
   DATE    : 19 th May 1995
   VERSION : 0.02

 This code is merged for sparrow and rattler. The Code can auto
 Detect type of card and configure accordingly

   DATE    : 25 th May 1995

     - This header file has defines for  EEPROM Ver .01

   DATE    : 14 th Jun 1995
   VERSION : 1.0

 -----------------------------------------------------------------------------

   DATE    : 10th May 1996
   VERSION : 2.29
   PERSON  : Mike Gibson

   Change Flag:  @250


   Add definition for EEPROM bit that indicates the driver should load
   even if the cable is not attached.
 -----------------------------------------------------------------------------

   DATE    : 07th Nov 1996
   VERSION : 2.30
   PERSON  : Bob Sharp

   Change Flag:  @253

   Added support for detecting Chip Revision
 -----------------------------------------------------------------------------
--*/

#ifndef _CRYSTALHARDWARE_
#define _CRYSTALHARDWARE_

#if ( defined(ARM_PROCESSOR) || defined(SH3_PROCESSOR))
/*The CS8900 has four interrupt request output pins that can be connected
 directly to Processor. Only one interrupt output pin is connected to ARM or SH3.
 CS8900_INTERRUPT_PIN_NUM defines which interrupt pin is used.
 0:  INTRQ0
 1:  INTRQ1
 2:  INTRQ2
 3:  INTRQ3
*/
#define CS8900_INTERRUPT_REQUEST_PIN_NUM     0

/*For SH3: CS8900_IOPORT_MEM_ADDR is the physical memory address of CS8900 IO port.
  For ARM and Strong ARM:  CS8900_IOPORT_MEM_ADDR is the un-buffered & un-cashed 
  virtual address (range 0xA0000000-0xBFFFFFFF).  Its buffered & cashed virtual address
  (ragne 0x80000000-0x9FFFFFFF) should be defined in OEMAddressTable.
   Note: Must be defined according to the target board.*/
#define CS8900_IOPORT_MEM_ADDR     0xC0000000L

#define CRYSTAL_STARTING_PORT   CS8900_IOPORT_MEM_ADDR
#define CRYSTAL_MAX_PORT_ADDRESS   CS8900_IOPORT_MEM_ADDR+1

#else
#define CRYSTAL_STARTING_PORT            0x200
#define CRYSTAL_MAX_PORT_ADDRESS         0x370
#endif
#define CRYSTAL_NEXT_PORT_OFFSET         0x10

//
//  Crystal Port addresses for I/O Space Model.
//
#define  CRYSTAL_RECEIVE_FRAME_PORT             ((USHORT)(0x0000))
#define  CRYSTAL_TRANSMIT_FRAME_PORT            ((USHORT)(0x0000))
#define  CRYSTAL_TRANSMIT_COMMAND_PORT          ((USHORT)(0x0004))
#define  CRYSTAL_TRANSMIT_LENGTH_PORT           ((USHORT)(0x0006))
#define  CRYSTAL_ISQ_PORT                       ((USHORT)(0x0008))
#define  CRYSTAL_ADDRESS_PORT                   ((USHORT)(0x000A))
#define  CRYSTAL_DATA_PORT                      ((USHORT)(0x000C))

#define  CRYSTAL_IO_SIZE                        ((USHORT)(0x0010))   // 16
#define  CRYSTAL_MEMORY_SIZE                    ((USHORT)(0x1000))   // 4K
#define  CRYSTAL_ROM_SIZE                       ((USHORT)(0x4000))   // 16K



//#define CS8921                       0

#define  CS89XX_ID                     0x630e
#define  CS8900_PROD_ID_LOW            0x0
#define  CS8920_PROD_ID_LOW            0x4000
//@105 add mongoose support
#define  CS89xx_PROD_ID_LOW            0x6000  //@105
#define  PRODUCT_ID_MASK               0xE000
#define  REVISION_ID_MASK              0x1f00  //@253
//
// Include processor-specific definitions needed by the CS8921.
// Macros for CRYSTAL_READ_PORT, CRYSTAL_WRITE_PORT etc.

//#include <csdet.h>

#define  CRYSTAL_CHIPEISA_ID                   ((USHORT)(0x0000))    // offset 0-> Corp -ID
#define  CRYSTAL_PRODUCT_ID                    ((USHORT)(0x0002))    // offset 02h
#define  CRYSTAL_ISA_IO_BASE_ADDRESS           ((USHORT)(0x0020))    // offset 20h
#define  CRYSTAL_ISA_INTERRUPT_NUMBER          ((USHORT)(0x0022))    // offset 22h
#define  CRYSTAL_ISA_DMA_CHANNEL               ((USHORT)(0x0024))    // offset 24h
#define  CRYSTAL_ISA_DMA_START_OF_FRAME_OFFSET ((USHORT)(0x0026))    // offset 26h
#define  CRYSTAL_ISA_DMA_FRAME_COUNT           ((USHORT)(0x0028))    // offset 28h
#define  CRYSTAL_ISA_DMA_BYTE_COUNT            ((USHORT)(0x002A))    // offset 2Ah
#define  CRYSTAL_ISA_MEMORY_BASE_ADDRESS       ((USHORT)(0x002C))    // offset 2Ch
#define  CRYSTAL_BOOT_PROM_BASE_ADDRESS        ((USHORT)(0x0030))    // offset 30h
#define  CRYSTAL_BOOT_PROM_ADDRESS_MASK        ((USHORT)(0x0034))    // offset 34h
#define  CRYSTAL_EEPROM_COMMAND_REGISTER       ((USHORT)(0x0040))    // offset 40h
#define  CRYSTAL_EEPROM_DATA_WORD              ((USHORT)(0x0042))    // offset 42h
#define  CRYSTAL_FRAME_BYTE_COUNT              ((USHORT)(0x0050))    // offset 50h  // @258a
#define  CRYSTAL_RX_CONFIG_REGISTER            ((USHORT)(0x0102))    // offset 102h
#define  CRYSTAL_RX_CONTROL_REGISTER           ((USHORT)(0x0104))    // offset 104h
#define  CRYSTAL_TX_CONFIG_REGISTER            ((USHORT)(0x0106))    // offset 106h
#define  CRYSTAL_TX_COMMAND_REGISTER           ((USHORT)(0x0108))    // offset 108h
#define  CRYSTAL_BUFFER_CONFIG_REGISTER        ((USHORT)(0x010A))    // offset 10Ah
#define  CRYSTAL_LINE_CONTROL_REGISTER         ((USHORT)(0x0112))    // offset 112h
#define  CRYSTAL_SELF_CONTROL_REGISTER         ((USHORT)(0x0114))    // offset 114h
#define  CRYSTAL_BUS_CONTROL_REGISTER          ((USHORT)(0x0116))    // offset 116h
#define  CRYSTAL_TEST_CONTROL_REGISTER         ((USHORT)(0x0118))    // offset 118h
#define  CRYSTAL_AUTO_NEG_CONTROL_REGISTER     ((USHORT)(0x011C))     // offset 11Ch
#define  CRYSTAL_INTERRUPT_STATUS_QUEUE        ((USHORT)(0x0120))    // offset 120h
#define  CRYSTAL_RX_EVENT_REGISTER             ((USHORT)(0x0124))    // offset 124h
#define  CRYSTAL_TX_EVENT_REGISTER             ((USHORT)(0x0128))    // offset 128h
#define  CRYSTAL_BUF_EVENT_REGISTER            ((USHORT)(0x012C))    // offset 12Ch
#define  CRYSTAL_RX_MISS_COUNT                 ((USHORT)(0x0130))    // offset 130h
#define  CRYSTAL_TX_COL_COUNT                  ((USHORT)(0x0132))    // offset 132h
#define  CRYSTAL_LINE_STATUS_REGISTER          ((USHORT)(0x0134))    // offset 134h
#define  CRYSTAL_SELF_STATUS_REGISTER          ((USHORT)(0x0136))    // offset 136h
#define  CRYSTAL_BUS_STATUS_REGISTER           ((USHORT)(0x0138))    // offset 138h
#define  CRYSTAL_TDR_REGISTER                  ((USHORT)(0x013C))    // offset 13Ch
#define  CRYSTAL_AUTO_NEG_STATUS_REGISTER      ((USHORT)(0x013E))    // offset 13Eh
#define  CRYSTAL_TX_COMMAND                    ((USHORT)(0x0144))    // offset 144h
#define  CRYSTAL_TX_LENGTH                     ((USHORT)(0x0146))    // offset 146h
#define  CRYSTAL_LOGICAL_ADDRESS_FILTER        ((USHORT)(0x0150))    // offset 150h
#define  CRYSTAL_INDIVIDUAL_ADDRESS            ((USHORT)(0x0158))    // offset 158h
#define  CRYSTAL_RECEIVE_STATUS                ((USHORT)(0x0400))    // offset 400h
#define  CRYSTAL_RECEIVE_LENGTH                ((USHORT)(0x0402))    // offset 402h
#define  CRYSTAL_RECEIVE_FRAME_PTR             ((USHORT)(0x0404))    // offset 404h
#define  CRYSTAL_TRANSMIT_FRAME_PTR            ((USHORT)(0x0A00))    // offset A00h


//
//     Following are the PacketPage Offsets to Plug and Play registers.
//
#define    CRYSTAL_PNP_REG_ACTIVATE            ((USHORT)(0x0330))    // Packet Page 0x330.
#define    CRYSTAL_PNP_REG_IO_RANGE_CHECK      ((USHORT)(0x0331))    // Packet Page 0x331.
#define    CRYSTAL_PNP_REG_MBAH0               ((USHORT)(0x0340))    // Packet Page 0x340.
#define    CRYSTAL_PNP_REG_MBAL0               ((USHORT)(0x0341))    // Packet Page 0x341.
#define    CRYSTAL_PNP_REG_MCNTL0              ((USHORT)(0x0342))    // Packet Page 0x342.
#define    CRYSTAL_PNP_REG_MRLH0               ((USHORT)(0x0343))    // Packet Page 0x343.
#define    CRYSTAL_PNP_REG_MRLL0               ((USHORT)(0x0344))    // Packet Page 0x344.
#define    CRYSTAL_PNP_REG_MBAH1               ((USHORT)(0x0348))    // Packet Page 0x348.
#define    CRYSTAL_PNP_REG_MBAL1               ((USHORT)(0x0349))    // Packet Page 0x349.
#define    CRYSTAL_PNP_REG_MCNTL1              ((USHORT)(0x034a))    // Packet Page 0x34a.
#define    CRYSTAL_PNP_REG_IO_BAH0             ((USHORT)(0x0360))    // Packet Page 0x360.
#define    CRYSTAL_PNP_REG_IO_BAL0             ((USHORT)(0x0361))    // Packet Page 0x361.
#define    CRYSTAL_PNP_REG_IRQ_S0              ((USHORT)(0x0370))    // Packet Page 0x370.
#define    CRYSTAL_PNP_REG_IRQ_TS0             ((USHORT)(0x0371))    // Packet Page 0x371.
#define    CRYSTAL_PNP_REG_DMASX               ((USHORT)(0x0374))    // Packet Page 0x374.
#define    CRYSTAL_PNP_TEST_REGISTER           ((USHORT)(0x03F0))    // Packet Page 0x3F0.
#define    CRYSTAL_PNP_REG_IO_DEF_VAL1         ((USHORT)(0x03F1))    // Packet Page 0x3F1.
//
//  End  of Packet Page Offset Equates
//


//
//     Following are the address of Plug and Play registers.
//
#define    PNP_REG_ACTIVATE                    ((USHORT)(0x030))    // Plug and play 0x30.
#define    PNP_REG_IO_RANGE_CHECK              ((USHORT)(0x031))    // Plug and play 0x31.
#define    PNP_REG_MBAH0                       ((USHORT)(0x040))    // Plug and play 0x40.
#define    PNP_REG_MBAL0                       ((USHORT)(0x041))    // Plug and play 0x41.
#define    PNP_REG_MCNTL0                      ((USHORT)(0x042))    // Plug and play 0x42.
#define    PNP_REG_MRLH0                       ((USHORT)(0x043))    // Plug and play 0x43.
#define    PNP_REG_MRLL0                       ((USHORT)(0x044))    // Plug and play 0x44.
#define    PNP_REG_MBAH1                       ((USHORT)(0x048))    // Plug and play 0x48.
#define    PNP_REG_MBAL1                       ((USHORT)(0x049))    // Plug and play 0x49.
#define    PNP_REG_MCNTL1                      ((USHORT)(0x04a))    // Plug and play 0x4a.
#define    PNP_REG_IO_BAH0                     ((USHORT)(0x060))    // Plug and play 0x60.
#define    PNP_REG_IO_BAL0                     ((USHORT)(0x061))    // Plug and play 0x61.
#define    PNP_REG_IRQ_S0                      ((USHORT)(0x070))    // Plug and play 0x70.
#define    PNP_REG_IRQ_TS0                     ((USHORT)(0x071))    // Plug and play 0x71.
#define    PNP_REG_DMASX                       ((USHORT)(0x074))    // Plug and play 0x74.
#define    PNP_TEST_REGISTER                   ((USHORT)(0x0F0))    // Plug and play 0xF0.
#define    PNP_REG_IO_DEF_VAL1                 ((USHORT)(0x0F1))    // Plug and play 0xF1.


//
//   CRYSTAL ISA PACKET PAGE STRUCTURE FOR MEMORY MAPPED I/O.
//
//
//     Following is the structure for the Plug and Play registers.
//
typedef struct _CRYSTAL_PNP_REGISTERS {
UCHAR    RegActivate;                // Packet page 0x330; Plug and play 0x30.
UCHAR    RegIoRangeCheck;            // Packet page 0x331; Plug and play 0x31.
UCHAR    Reserved0[0x40-0x32];
UCHAR    RegMbah0;                  // Packet page 0x340; Plug and play 0x40.
UCHAR    RegMbal0;                  // Packet page 0x341; Plug and play 0x41.
UCHAR    RegMcntl0;                 // Packet page 0x342; Plug and play 0x42.
UCHAR    RegMrlh0;                  // Packet page 0x343; Plug and play 0x43.
UCHAR    RegMrll0;                  // Packet page 0x344; Plug and play 0x44.
UCHAR    Reserved1[0x48-0x45];
UCHAR    RegMbah1;                  // Packet page 0x348; Plug and play 0x48.
UCHAR    RegMbal1;                  // Packet page 0x349; Plug and play 0x49.
UCHAR    RegMcntl1;                 // Packet page 0x34a; Plug and play 0x4a.
UCHAR    Reserved2[0x60-0x4b];
UCHAR    RegIObah0;                 // Packet page 0x360; Plug and play 0x60.
UCHAR    RegIObal0;                 // Packet page 0x361; Plug and play 0x61.
UCHAR    Reserved3[0x70-0x62];
UCHAR    RegIrqs0;                  // Packet page 0x370; Plug and play 0x70.
UCHAR    RegIrqts0;                 // Packet page 0x371; Plug and play 0x71.
UCHAR    Reserved4[0x74-0x72];
UCHAR    RegDmasx;                  // Packet page 0x374; Plug and play 0x74.
UCHAR    Reserved5[0xF0-0x75];
UCHAR    TestRegister;              // Packet page 0x3F0; Plug and play 0xF0.
UCHAR    RegIODefVal1;              // Packet page 0x3F1; Plug and play 0xF1.
UCHAR    Reserved6[0x100-0xF2];
}CRYSTAL_PNP_REGISTERS,*PCRYSTAL_PNP_REGISTERS;



typedef struct _CRYSTAL_PACKET_PAGE {
ULONG    CrystalChipEisaId;                        // offset 0-> Corp -ID
UCHAR    Reserved[16];
USHORT   CrystalIsaIoBaseAddress;                  // offset 20h
USHORT   CrystalIsaInterruptNumber;                // offset 22h
USHORT   CrystalIsaDmaChannel;                     // offset 24h
USHORT   CrystalIsaDmaStartOfFrameOffset;          // offset 26h
USHORT   CrystalIsaDmaFrameCount;                  // offset 28h
USHORT   CrystalIsaDmaByteCount;                   // offset 2Ah
ULONG    CrystalIsaMemoryBaseAddress;              // offset 2Ch
ULONG    CrystalBootPromBaseAddress;               // offset 30h
ULONG    CrystalBootPromAddressMask;               // offset 34h
UCHAR    Reserved1[8];                             // Reserved
USHORT   CrystalEepromDataWord;                    // offset 40h
USHORT   CrystalEepromOpCode;                      // offset 42h

UCHAR    Reserved2[0x102-0x44];                     // Filler

USHORT   CrystalRxConfigRegister;                  // offset 102h
USHORT   CrystalRxControlRegister;                 // offset 104h
USHORT   CrystalTxConfigRegister;                  // offset 106h
USHORT   CrystalTxCommandRegister;                 // offset 108h
USHORT   CrystalBufferConfigRegister;              // offset 10Ah

UCHAR    Reserved3[6];

USHORT   CrystalLineControlRegister;               // offset 112h
USHORT   CrystalSelfControlRegister;               // offset 114h
USHORT   CrystalBusControlRegister;                // offset 116h
USHORT   CrystalTestControlRegister;               // offset 118h
USHORT   CrystalInterruptStatusQueue;              // offset 120h
UCHAR    Reserved5[2];
USHORT   CrystalRxEventRegister;                   // offset 124h
UCHAR    Reserved6[2];
USHORT   CrystalTxEventRegister;                   // offset 128h
UCHAR    Reserved7[2];
USHORT   CrystalBufEventRegister;                  // offset 12Ch
UCHAR    Reserved8[2];
USHORT   CrystalRxMissCount;                       // offset 130h
USHORT   CrystalTxColCount;                        // offset 132h
USHORT   CrystalLineStatusRegister;                // offset 134h
USHORT   CrystalSelfStatusRegister;                // offset 136h
USHORT   CrystalBusStatusRegister;                 // offset 138h
UCHAR    Reserved9[2];
USHORT   CrystalTdrRegister;                       // offset 13Ch
UCHAR    Reserved10[2];
UCHAR    Reserved11[2];
UCHAR    Reserved12[2];
USHORT   CrystalTransmitCommand;                   // offset 144h
USHORT   CrystalTransmitLength;                    // offset 146h
UCHAR    Reserved13[8];
USHORT   CrystalLogicalAddressFilter[4];           // offset 150h
UCHAR    CrystalIndividualAddress[8];              // offset 158h
UCHAR    Reserved14[672];
USHORT   CrystalReceiveStatus;                     // offset 400h
USHORT   CrystalReceiveLength;                     // offset 402h
UCHAR    CrystalReceiveFramePtr[0x0A00-0x0404];    // offset 404h
UCHAR    CrystalTransmitFramePtr;                  // offset A00h
} CRYSTAL_PACKET_PAGE,*PCRYSTAL_PACKET_PAGE;
//
//  End  of Packet Page Structure.
//

//AutoNeg Control Register in cs8920

#define RE_NOW                           0x0040
#define ALLOW_FDX                        0x0080
#define AUTO_NEG_ENABLE                  0x0100
#define NLP_ENABLE                       0x0200
#define FORCE_FDX                        0x8000

// @kml 6/29/99
//#define CRYSTAL_AUTONEG_DEFAULT_VALUE                  NLP_ENABLE;
//#define CRYSTAL_AUTONEG_UNDEFINED                                          0xffff

//AutoNeg Status Register in cs8920

#define AUTO_NEG_BUSY                    0x0080
#define FLP_LINK                         0x0100
#define FLP_LINK_GOOD                    0x0800
#define LINK_FAULT                       0x1000
#define HDX_ACTIVE                       0x4000
#define FDX_ACTIVE                       0x8000

//  Defines Control/Config register quintuplet numbers
//
#define  RX_BUF_CFG                             ((USHORT)(0x0003))
#define  RX_CONTROL                             ((USHORT)(0x0005))
#define  TX_CFG                                 ((USHORT)(0x0007))
#define  TX_COMMAND                             ((USHORT)(0x0009))
#define  BUF_CFG                                ((USHORT)(0x000B))
#define  LINE_CONTROL                           ((USHORT)(0x0013))
#define  SELF_CONTROL                           ((USHORT)(0x0015))
#define  BUS_CONTROL                            ((USHORT)(0x0017))
#define  TEST_CONTROL                           ((USHORT)(0x0019))

//
// Defines Status/Count registers quintuplet numbers
//
#define  RX_EVENT                               ((USHORT)(0x0004))
#define  TX_EVENT                               ((USHORT)(0x0008))
#define  BUF_EVENT                              ((USHORT)(0x000C))
#define  RX_MISS_COUNT                           ((USHORT)(0x0010))
#define  TX_COL_COUNT                           ((USHORT)(0x0012))
#define  LINE_STATUS                            ((USHORT)(0x0014))
#define  SELF_STATUS                            ((USHORT)(0x0016))
#define  BUS_STATUS                             ((USHORT)(0x0018))
#define  TDR                                    ((USHORT)(0x001C))
//
// Receive  Configuration and Interrupt Mask bit definition
// Read/write

#define  CRYSTAL_RCR_SKIP_1                        ((USHORT)(0x0040))
#define  CRYSTAL_RCR_RX_STREAM_ENABLE              ((USHORT)(0x0080))
#define  CRYSTAL_RCR_RX_OK_ENABLE                  ((USHORT)(0x0100))
#define  CRYSTAL_RCR_DMA_ONLY                      ((USHORT)(0x0200))
#define  CRYSTAL_RCR_AUTO_RX_DMA                   ((USHORT)(0x0400))
#define  CRYSTAL_RCR_BUFFER_CRC                    ((USHORT)(0x0800))
#define  CRYSTAL_RCR_RX_CRC_ERROR_ENABLE           ((USHORT)(0x1000))
#define  CRYSTAL_RCR_RX_RUNT_ENABLE                ((USHORT)(0x2000))
#define  CRYSTAL_RCR_RX_EXTRA_DATA_ENABLE          ((USHORT)(0x4000))
#define  CRYSTAL_DEFAULT_RX_CONFIG_VALUE           ((USHORT)\
                                              (CRYSTAL_RCR_RX_CRC_ERROR_ENABLE|\
                                              CRYSTAL_RCR_RX_OK_ENABLE|\
                                              CRYSTAL_RCR_RX_RUNT_ENABLE|\
                                              CRYSTAL_RCR_RX_EXTRA_DATA_ENABLE|\
                                              CRYSTAL_RCR_BUFFER_CRC))
//
// Receive Control bit definition
// Read/write
//
#define  CRYSTAL_RCR_RX_IA_HASH_ACCEPT              ((USHORT)(0x0040))
#define  CRYSTAL_RCR_RX_PROM_ACCEPT                 ((USHORT)(0x0080))
#define  CRYSTAL_RCR_RX_OK_ACCEPT                   ((USHORT)(0x0100))
#define  CRYSTAL_RCR_RX_MULTICAST_ACCEPT            ((USHORT)(0x0200))
#define  CRYSTAL_RCR_RX_IA_ACCEPT                   ((USHORT)(0x0400))
#define  CRYSTAL_RCR_RX_BROADCAST_ACCEPT            ((USHORT)(0x0800))
#define  CRYSTAL_RCR_RX_BAD_CRC_ACCEPT              ((USHORT)(0x1000))
#define  CRYSTAL_RCR_RX_RUNT_ACCEPT                 ((USHORT)(0x2000))
#define  CRYSTAL_RCR_RX_EXTRA_DATA_ACCEPT           ((USHORT)(0x4000))
#define  CRYSTAL_RCR_DEFAULT_VALUE                  ((USHORT)(CRYSTAL_RCR_RX_OK_ACCEPT))
// #define  CRYSTAL_RCR_DEFAULT_VALUE ((USHORT)(CRYSTAL_RCR_RX_OK_ACCEPT | \
//                                              CRYSTAL_RCR_RX_BAD_CRC_ACCEPT | \
//                                              CRYSTAL_RCR_RX_RUNT_ACCEPT | \
//                                              CRYSTAL_RCR_RX_EXTRA_DATA_ACCEPT))

//
// Transmit Configuration Interrupt Mask bit definition
// Read/write
//
#define  CRYSTAL_TCR_TX_LOST_CRS_ENABLE                  ((USHORT)(0x0040))
#define  CRYSTAL_TCR_TX_SQE_ERROR_ENABLE                 ((USHORT)(0x0080))
#define  CRYSTAL_TCR_TX_OK_ENABLE                        ((USHORT)(0x0100))
#define  CRYSTAL_TCR_TX_LATE_COLLISION_ENABLE            ((USHORT)(0x0200))
#define  CRYSTAL_TCR_TX_JABBER_ENABLE                    ((USHORT)(0x0400))
#define  CRYSTAL_TCR_TX_ANY_COL_ENABLE                   ((USHORT)(0x0800))
#define  CRYSTAL_TCR_TX_16_COL_ENABLE                    ((USHORT)(0x8000))


#define  CRYSTAL_TCR_DEFAULT_VALUE       ((USHORT)\
                                         CRYSTAL_TCR_TX_LOST_CRS_ENABLE|\
                                         CRYSTAL_TCR_TX_OK_ENABLE|\
                                         CRYSTAL_TCR_TX_LATE_COLLISION_ENABLE|\
                                         CRYSTAL_TCR_TX_JABBER_ENABLE|\
                                         CRYSTAL_TCR_TX_16_COL_ENABLE)


// Transmit Command bit definition
//  Read-only
//
#define  CRYSTAL_TCR_TX_START_5_BYTES                ((USHORT)(0x0000))
#define  CRYSTAL_TCR_TX_START_381_BYTES              ((USHORT)(0x0040))
#define  CRYSTAL_TCR_TX_START_1021_BYTES             ((USHORT)(0x0080))
#define  CRYSTAL_TCR_TX_START_ALL_BYTES              ((USHORT)(0x00C0))
#define  CRYSTAL_TCR_TX_FORCE                        ((USHORT)(0x0100))
#define  CRYSTAL_TCR_TX_ONE_COLLISION                ((USHORT)(0x0200))
#define  CRYSTAL_TCR_TX_TWO_PART_DEFF_DISABLE        ((USHORT)(0x0400))
#define  CRYSTAL_TCR_TX_NO_CRC                       ((USHORT)(0x1000))
#define  CRYSTAL_TCR_TX_PAD_DISABLE                  ((USHORT)(0x2000))

//
// Buffer Configuration Interrupt Mask bit definition
// Read/write
//
#define  CRYSTAL_BCR_GENERATE_SW_INTERRUPT           ((USHORT)(0x0040))
#define  CRYSTAL_BCR_RX_DMA_ENABLE                   ((USHORT)(0x0080))
#define  CRYSTAL_BCR_READY_FOR_TX_ENABLE             ((USHORT)(0x0100))
#define  CRYSTAL_BCR_TX_UNDERRUN_ENABLE              ((USHORT)(0x0200))
#define  CRYSTAL_BCR_RX_MISS_ENABLE                  ((USHORT)(0x0400))
#define  CRYSTAL_BCR_RX_128_BYTE_ENABLE              ((USHORT)(0x0800))
#define  CRYSTAL_BCR_TX_COL_COUNT_OVRFLOW_ENABLE     ((USHORT)(0x1000))
#define  CRYSTAL_BCR_RX_MISS_COUNT_OVRFLOW_ENABLE    ((USHORT)(0x2000))
#define  CRYSTAL_BCR_RX_DEST_MATCH_ENABLE            ((USHORT)(0x8000))

//@drsc 3.21  add CS8900 support
#define  CRYSTAL_BCR_DEFAULT_VALUE   ((USHORT)\
                                    CRYSTAL_BCR_TX_UNDERRUN_ENABLE|\
                                    CRYSTAL_BCR_TX_COL_COUNT_OVRFLOW_ENABLE|\
                                    CRYSTAL_BCR_RX_MISS_COUNT_OVRFLOW_ENABLE|\
                                    CRYSTAL_BCR_READY_FOR_TX_ENABLE)

#define CRYSTAL_BCR_ENABLE_EARLY_INTERRUPTS ((USHORT) \
                                   (CRYSTAL_BCR_RX_DEST_MATCH_ENABLE | \
                                    CRYSTAL_BCR_RX_128_BYTE_ENABLE))


//
// Line Control bit definition
// Read/write
//
#define  CRYSTAL_LCR_SERIAL_RX_ON               ((USHORT)(0x0040))
#define  CRYSTAL_LCR_SERIAL_TX_ON               ((USHORT)(0x0080))
#define  CRYSTAL_LCR_AUI_ONLY                   ((USHORT)(0x0100))
#define  CRYSTAL_LCR_AUTO_AUI_10BASET           ((USHORT)(0x0200))
#define  CRYSTAL_LCR_NWAY_ENABLE                ((USHORT)(0x0400))
#define  CRYSTAL_LCR_MODIFIED_BACKOFF           ((USHORT)(0x0800))
#define  CRYSTAL_LCR_AUTO_CORRECT_POLARITY      ((USHORT)(0x1000))
#define  CRYSTAL_LCR_LOW_RX_SQUELCH             ((USHORT)(0x4000))
#define  CRYSTAL_LCR_NWAY_PULSES                ((USHORT)(0x8000))
//@203
#define  CRYSTAL_LCR_WAKE_ENABLE                ((USHORT)(0x8000))


#define  CRYSTAL_LCR_DEFAULT_VALUE    ((USHORT)(0))

//
// Software Self Control bit definition
// Read/write
//
#define  CRYSTAL_SCR_POWER_ON_RESET             ((USHORT)(0x0040))
#define  CRYSTAL_SCR_SW_SUSPEND                 ((USHORT)(0x0100))
#define  CRYSTAL_SCR_HW_SLEEP_ENABLE            ((USHORT)(0x0200))
#define  CRYSTAL_SCR_HW_STANDBY_ENABLE          ((USHORT)(0x0400))
#define  CRYSTAL_SCR_HCO_0_ENABLE               ((USHORT)(0x1000))
#define  CRYSTAL_SCR_HCO_1_ENABLE               ((USHORT)(0x2000))
#define  CRYSTAL_SCR_HCO_0                      ((USHORT)(0x4000))
#define  CRYSTAL_SCR_HCO_1                      ((USHORT)(0x8000))

//
// ISA Bus Control bit definition
// Read/write
//
#define  CRYSTAL_BCR_RESET_RX_DMA               ((USHORT)(0x0040))
#define  CRYSTAL_BCR_USE_SA                     ((USHORT)(0x0200))
#define  CRYSTAL_BCR_MEMORY_ON                  ((USHORT)(0x0400))
#define  CRYSTAL_BCR_DMA_BURST                  ((USHORT)(0x0800))
#define  CRYSTAL_BCR_IO_CHANNEL_READY_ON        ((USHORT)(0x1000))
#define  CRYSTAL_BCR_RX_DMA_SIZE_64K            ((USHORT)(0x2000))
#define  CRYSTAL_BCR_INTERRUPT_ENABLE           ((USHORT)(0x8000))

#define  CRYSTAL_BUS_DEFAULT_VALUE                    CRYSTAL_BCR_INTERRUPT_ENABLE
//
// Test Control bit definition
// Read/write
//
#define  CRYSTAL_TCR_LINK_OFF                   ((USHORT)(0x0080))
#define  CRYSTAL_TCR_ENDEC_LOOPBACK             ((USHORT)(0x0200))
#define  CRYSTAL_TCR_AUI_LOOPBACK               ((USHORT)(0x0400))
#define  CRYSTAL_TCR_BACKOFF_OFF                ((USHORT)(0x0800))
#define  CRYSTAL_TCR_FULL_DUPLEX_ON             ((USHORT)(0x4000))
#define  CRYSTAL_TCR_FAST_TEST                  ((USHORT)(0x8000))

//
// Receive Event Bit definition
// Read-only
//
#define  CRYSTAL_RER_IA_HASHED                  ((USHORT)(0x0040))
#define  CRYSTAL_RER_DRIBBLE                    ((USHORT)(0x0080))
#define  CRYSTAL_RER_PACKET_RECEIVED_OK         ((USHORT)(0x0100))
#define  CRYSTAL_RER_HASHED_RECEIVED            ((USHORT)(0x0200))
#define  CRYSTAL_RER_INDIVIDUAL_RECEIVED        ((USHORT)(0x0400))
#define  CRYSTAL_RER_BROADCAST_RECEIVED         ((USHORT)(0x0800))
#define  CRYSTAL_RER_CRC_ERROR                  ((USHORT)(0x1000))
#define  CRYSTAL_RER_RUNT                       ((USHORT)(0x2000))
#define  CRYSTAL_RER_EXTRA_DATA                 ((USHORT)(0x4000))
#define  CRYSTAL_RER_HASH_INDEX_MASK            ((USHORT)(0xFC00))

//
// Transmit Event Bit definition
// Read-only
//
#define  CRYSTAL_TER_LOST_CRS                   ((USHORT)(0x0040))
#define  CRYSTAL_TER_SQE_ERROR                  ((USHORT)(0x0080))
#define  CRYSTAL_TER_PACKET_TRANSMITTED_OK      ((USHORT)(0x0100))
#define  CRYSTAL_TER_OUT_OF_WINDOW              ((USHORT)(0x0200))
#define  CRYSTAL_TER_JABBER                     ((USHORT)(0x0400))
#define  CRYSTAL_TER_EXCESSIVE_COLLISIONS       ((USHORT)(0x8000))
#define  CRYSTAL_TER_COLLISIONS_MASK            ((USHORT)(0x7800))
#define  CRYSTAL_TER_COLLISIONS_SHIFT           ((USHORT)(0x000B))

//
// Buffer Event Bit definition
// Read-only
//
#define  CRYSTAL_BER_SW_INTERRUPT               ((USHORT)(0x0040))
#define  CRYSTAL_BER_RX_DMA                     ((USHORT)(0x0080))
#define  CRYSTAL_BER_READY_FOR_TRANSMIT         ((USHORT)(0x0100))
#define  CRYSTAL_BER_TX_UNDERRUN                ((USHORT)(0x0200))
#define  CRYSTAL_BER_RX_MISS                    ((USHORT)(0x0400))
#define  CRYSTAL_BER_RX_128_BYTE                ((USHORT)(0x0800))
#define  CRYSTAL_BER_TX_COL_OVERRFLOW           ((USHORT)(0x1000))
#define  CRYSTAL_BER_RX_MISS_OVERFLOW           ((USHORT)(0x2000))
#define  CRYSTAL_BER_RX_DESTINATION_MATCH       ((USHORT)(0x8000))

//
// Ethernet Line Status bit definition
// Read-only
//
#define  CRYSTAL_LSR_LINK_OK                    ((USHORT)(0x0080))
#define  CRYSTAL_LSR_AUI_ON                     ((USHORT)(0x0100))
#define  CRYSTAL_LSR_TENBASET_ON                ((USHORT)(0x0200))
#define  CRYSTAL_LSR_NWAY_FDX                   ((USHORT)(0x0400))
#define  CRYSTAL_LSR_NWAY_ACTIVE                ((USHORT)(0x0800))
#define  CRYSTAL_LSR_POLARITY_OK                ((USHORT)(0x1000))
#define  CRYSTAL_LSR_CRS_OK                     ((USHORT)(0x4000))


//
// Chip Software Status bit definition
// Read-only
//
#define  CRYSTAL_SSR_ACTIVE_33V                 ((USHORT)(0x0040))
#define  CRYSTAL_SSR_PNP_DISABLE                ((USHORT)(0x0040))
#define  CRYSTAL_SSR_INIT_DONE                  ((USHORT)(0x0080))
#define  CRYSTAL_SSR_SI_BUSY                    ((USHORT)(0x0100))
#define  CRYSTAL_SSR_EEPROM_PRESENT             ((USHORT)(0x0200))
#define  CRYSTAL_SSR_EEPROM_OK                  ((USHORT)(0x0400))
#define  CRYSTAL_SSR_EL_PRESENT                 ((USHORT)(0x0800))
#define  CRYSTAL_SSR_EE_SIZE_64                 ((USHORT)(0x1000))

//
// ISA Bus Status bit definition
// Read-only
//
#define  CRYSTAL_BSR_TX_BID_ERROR               ((USHORT)(0x0080))
#define  CRYSTAL_BSR_READY_FOR_TRANSMIT_NOW     ((USHORT)(0x0100))

//
// The following block defines the ISQ event types
//
#define  CRYSTAL_ISQ_RECEIVE_EVENT              ((USHORT)(0x0004))
#define  CRYSTAL_ISQ_TRANSMIT_EVENT             ((USHORT)(0x0008))
#define  CRYSTAL_ISQ_BUFFER_EVENT               ((USHORT)(0x000c))
#define  CRYSTAL_ISQ_RECEIVE_MISS_OVERFLOW_EVENT ((USHORT)(0x0010))
#define  CRYSTAL_ISQ_TX_COL_OVERFLOW_EVENT      ((USHORT)(0x0012))

#define   CRYSTAL_ISQ_EVENT_MASK                  ((USHORT)(0x003F))

#define   CRYSTAL_REG_NUMBER_MASK                 ((USHORT)(0x003F))
#define   CRYSTAL_REG_NUMBER_TX_CMD               ((USHORT)(0x0009))

//
//   Mask value for Address Auto-Increment.
//
#define  CRYSTAL_ENABLE_AUTO_INCREMENT          ((USHORT)(0x8000))

#define  CRYSTAL_MAX_MULTICAST_ENTRIES           64
#define  CRYSTAL_ADAPTER_TYPE_ISA                0
#define  CS89XX_ISA_ID_LOW                       0x630e
#define  CS89XX_ISA_ID_HI                        0


//
// Dmaed Frame Structure
//
typedef struct _CRYSTAL_DMA_FRAME {

USHORT RxFrameStatus;
USHORT RxFrameSize;

}CRYSTAL_DMA_FRAME,*PCRYSTAL_DMA_FRAME;



#define CRYSTAL_DMA_16K                           16*1024
#define CRYSTAL_DMA_64K                           64*1024
#define CRYSTAL_BOUNDARY_128K                     128*1024
#define CRYSTAL_DMA_ALIGN_VALUE                   0x010000
#define CRYSTAL_BOUNDARY_16M                      (1024*1024*16)
#define CRYSTAL_DMA_ALLIGN_MASK                   0x0FFFF

#define CRYSTAL_FRAME_OFFSET_DMA_MASK             CRYSTAL_DMA_16K-1
#define CRYSTAL_DMA_FRAME_COUNT_MASK              0x0FFF


#define DMA_HIGHEST_ACCEPTABLE_MEMORY_LOW    0x1000000
#define DMA_HIGHEST_ACCEPTABLE_MEMORY_HI     (0x00)

//------------------------------------------------------------------------------+
//  Dma Details                                                                 |
//------------------------------------------------------------------------------+
#define DMA_16MASK_REG                   0xD4
#define DMA_16MODE_REG                   0xD6
#define CIRCULAR_MODE                    0x14
#define DMA_CLEAR_FLIPFLOP               0xD8
#define DMA_CHANNEL_FIELD                0x03
#define SET_DMA_MASK                     0x04

#define CRYSTAL_SCAN_SIGNATURE           0x3000
#define CRYSTAL_SCAN_MASK                0xF000
#define BAD_EEPROM                       0xFFFF
#define MAXLOOP                          0x8888

#define EEPROM_READ_REGISTER             ((USHORT)(0x0200))

#define EE_ADDRESS_OEM_IA_W1             ((USHORT)(0x001C))          //48-bits  FFFFEEEEDDDD
#define EE_ADDRESS_OEM_IA_W2             ((USHORT)(0x001D))
#define EE_ADDRESS_OEM_IA_W3             ((USHORT)(0x001E))
#define EE_ADDRESS_FLAGS                 ((USHORT)(0x001F))
#define EE_ADDRESS_MEM_BASE              ((USHORT)(0x0020))          // MMM0   MemBase   12-bits
                                                                     //MMM000 23-12 in 24-bit
                                                                     //ISA address space
#define EE_ADDRESS_BOOT_BASE             ((USHORT)(0x0021))          //BBB0   BootBase  12-bits
                                                                     //BBB000 23-12 in 24-bit
                                                                     //ISA address space
#define EE_ADDRESS_BOOT_MASK             ((USHORT)(0x0022))          //FFF0   BootMask  12-bits
                                                                     // FFF000 23-12 in 24-bit
                                                                     //ISA address space
#define EE_ADDRESS_CTL                    ((USHORT)(0x0023))         //0N0B   NwayCTL and Bus CTL
#define EE_ADDRESS_VRHC                   ((USHORT)(0x0024))         //Version  4-bits V 2-Rattler
                                                                     // 1-Sparrow
#define EE_ADDRESS_SOFT                   ((USHORT)(0x0025))         //SOFT   Software  16-bits of
                                                                     //non-volatile software info

#define EE_SERIAL_NUMBER_HIGH             ((USHORT)(0x0032))         //Serial High
#define EE_SERIAL_NUMBER_LOW              ((USHORT)(0x0033))         //Serial Low

#define EE_ADDRESS_BOARD                  ((USHORT)(0x0026))         //Board specific info
#define EE_ADDRESS_PROD_ID                ((USHORT)(0x0026))         // Product ID
#define EE_ADDRESS_DATE                   ((USHORT)(0x0027))         // Mfg date
#define EE_ADDRESS_MFG_IA_W1              ((USHORT)(0x0028))         //FFFF   Mfg IA
#define EE_ADDRESS_MFG_IA_W2              ((USHORT)(0x0029))         //48-bits   FFFFEEEEDDDD
#define EE_ADDRESS_MFG_IA_W3              ((USHORT)(0x002A))
#define EE_ADDRESS_EISA_ID_W1             ((USHORT)(0x002B))         // 32-bits   E3E2E1E0
#define EE_ADDRESS_EISA_ID_W2             ((USHORT)(0x002C))
#define EE_ADDRESS_RESERVED_W1            ((USHORT)(0x002D))
#define EE_ADDRESS_RESERVED_W2            ((USHORT)(0x002E))         // Reserved, checksummed



//Flags in EEPROM for our use

#define EE_MEM_FLAG                       ((USHORT)(0x8000))
#define EE_BOOT_PROM_FLAG                 ((USHORT)(0x4000))
#define EE_DMA_DISABLE                    ((USHORT)(0x30  ))
#define EE_IRQ_FLAG                       ((USHORT)(0x1000))
#define EE_DMA_ADJUST                     ((USHORT)(0x4   ))
#define EE_DMA_MASK                       ((USHORT)(0x0070))         //To extract the dma channel number
#define EE_DMA_ONLY                       ((USHORT)(0x0800))         //EEPROM  RX Cfg Bit for DMA  only
#define EE_AUTO_DMA                       ((USHORT)(0x0400))         //EEPROM  RX Cfg Bit for Auto DMA
#define EE_DMA_BURST_ENBL                 ((USHORT)(0x1000))
#define EE_BUS_CTL_MASK                   ((USHORT)(0x000F))         // Configuration for bus CTL
#define EE_LINE_CTL_MASK                  ((USHORT)(0x0F00))         // Configuration for bus CTL
#define EE_INTERRUPT_MASK                 ((USHORT)(0x000F))
#define EE_MEMORY_MASK                    ((USHORT)(0xFFF0))
#define EE_IOCHRDY_ENBL                   ((USHORT)(0x100 ))
#define EE_USE_SA                         ((USHORT)(0x80  ))
#define EE_STREAM_TRANSFER                ((USHORT)(0x2000))
#define EE_MEM_BASE_ADJUST                 8

#define AUTO_NEG_MASK                     ((USHORT)(0x8380))
#define EE_MEDIA_MASK                     ((USHORT)(0x0060))
#define EE_LOAD_WITHOUT_CABLE             ((USHORT)(0x0040))
#define EE_MEDIA_SHIFT                    5
#define EE_AUTODETECT                     0
#define EE_10BASET                        1
#define EE_AUI                            2
#define EE_BNC                            3
#define EE_LA_DECODE_CKT                  4
#define EE_HW_STANDBY                     5
#define EE_RX_DMA_SIZE                    ((USHORT)(0x200 ))
#define EE_CKT_MASK                       ((USHORT)(0x07  ))
#define EE_10BASET_CKT                    1
#define EE_AUI_CKT                        2
#define EE_BNC_CKT                        4


#define EE_FORCE_FDX                      ((USHORT)(0x8000))
#define EE_NLP_ENABLE                     ((USHORT)(0x0200))
#define EE_AUTONEG_ENABLE                 ((USHORT)(0x0100))
#define EE_ALLOW_FDX                      ((USHORT)(0x0080))
#define EE_WAKEUP_CAPEABLE                ((USHORT)(0x0400))
#define EE_WAKEUP_CONFIGURED              ((USHORT)(0x0200))
#define EE_WAKEUP_ENABLED                 ((USHORT)(0x0100))
#define EE_DCDC_POLARITY                  ((USHORT)(0x0080))

#endif     _CRYSTALHARDWARE_


