//---------------------------------------------------------------------------
//
//  Copyright (C) 1996-1997. Unpublished Work of Crystal Semiconductor Corp.
//  All Rights Reserved.
//
//  THIS WORK IS AN UNPUBLISHED WORK AND CONTAINS CONFIDENTIAL,
//  PROPRIETARY AND TRADE SECRET INFORMATION OF CRYSTAL SEMICONDUCTOR.
//  ACCESS TO THIS WORK IS RESTRICTED TO (I) CRYSTAL SEMICONDUCTOR EMPLOYEES
//  WHO HAVE A NEED TO KNOW TO PERFORM TASKS WITHIN THE SCOPE OF THEIR
//  ASSIGNMENTS  AND (II) ENTITIES OTHER THAN CRYSTAL SEMICONDUCTOR WHO
//  HAVE ENTERED INTO  APPROPRIATE LICENSE AGREEMENTS.  NO PART OF THIS
//  WORK MAY BE USED, PRACTICED, PERFORMED, COPIED, DISTRIBUTED, REVISED,
//  MODIFIED, TRANSLATED, ABRIDGED, CONDENSED, EXPANDED, COLLECTED,
//  COMPILED,LINKED,RECAST, TRANSFORMED, ADAPTED IN ANY FORM OR BY ANY
//  MEANS,MANUAL, MECHANICAL, CHEMICAL, ELECTRICAL, ELECTRONIC, OPTICAL,
//  BIOLOGICAL, OR OTHERWISE WITHOUT THE PRIOR WRITTEN PERMISSION AND
//  CONSENT OF CRYSTAL SEMICONDUCTOR . ANY USE OR EXPLOITATION OF THIS WORK
//  WITHOUT THE PRIOR WRITTEN CONSENT OF CRYSTAL SEMICONDUCTOR  COULD
//  SUBJECT THE PERPETRATOR TO CRIMINAL AND CIVIL LIABILITY.
//
//---------------------------------------------------------------------------

#include "ends4isa.h"


extern BYTE        NDISVerMajor;
extern BYTE        NDISVerMinor;

extern
NDIS_STATUS
CrystalQueryInformation(
    IN NDIS_HANDLE MiniportAdapterContext,
    IN NDIS_OID Oid,
    IN PVOID InformationBuffer,
    IN ULONG InformationBufferLength,
    OUT PULONG BytesWritten,
    OUT PULONG BytesNeeded
    )

/*++

Routine Description:

    CrystalQueryInformation handles a query operation for a
    single OID.

Arguments:

    MiniportAdapterContext - Context registered with the wrapper, really
        a pointer to the VP context.

    Oid - The OID of the query.

    InformationBuffer - Holds the result of the query.

    InformationBufferLength - The length of InformationBuffer.

    BytesWritten - If the call is successful, returns the number
        of bytes written to InformationBuffer.

    BytesNeeded - If there is not enough room in InformationBuffer
        to satisfy the OID, returns the amount of storage needed.

Return Value:

    NDIS_STATUS_SUCCESS
    NDIS_STATUS_PENDING
    NDIS_STATUS_INVALID_LENGTH
    NDIS_STATUS_INVALID_OID

--*/

{
   PVOID       SourceBuffer;
   ULONG       SourceBufferLength;
   ULONG       GenericUlong;
   USHORT      GenericUshort;
   UCHAR       VendorId[4];

   UCHAR IsaDescriptor[] = VENDOR_PRODUCT_NAME_STR;

   NDIS_OID CrystalGlobalSupportedOids[] = {
      OID_GEN_SUPPORTED_LIST,
      OID_GEN_HARDWARE_STATUS,
      OID_GEN_MEDIA_SUPPORTED,
      OID_GEN_MEDIA_IN_USE,
      OID_GEN_MAXIMUM_LOOKAHEAD,
      OID_GEN_MAXIMUM_FRAME_SIZE,
      OID_GEN_LINK_SPEED,
      OID_GEN_TRANSMIT_BUFFER_SPACE,
      OID_GEN_RECEIVE_BUFFER_SPACE,
      OID_GEN_TRANSMIT_BLOCK_SIZE,
      OID_GEN_RECEIVE_BLOCK_SIZE,
      OID_GEN_VENDOR_ID,
      OID_GEN_VENDOR_DESCRIPTION,
      OID_GEN_VENDOR_DRIVER_VERSION,
      OID_GEN_CURRENT_PACKET_FILTER,
      OID_GEN_CURRENT_LOOKAHEAD,
      OID_GEN_DRIVER_VERSION,
      OID_GEN_MAXIMUM_TOTAL_SIZE,
      OID_GEN_PROTOCOL_OPTIONS,
      OID_GEN_MAC_OPTIONS,
      OID_GEN_MEDIA_CONNECT_STATUS,     // NEW
      OID_GEN_MAXIMUM_SEND_PACKETS,     // NEW
      OID_GEN_XMIT_OK,
      OID_GEN_RCV_OK,
      OID_GEN_XMIT_ERROR,
      OID_GEN_RCV_ERROR,
      OID_GEN_RCV_NO_BUFFER,
//    OID_GEN_DIRECTED_BYTES_XMIT,
//    OID_GEN_DIRECTED_FRAMES_XMIT,
//    OID_GEN_MULTICAST_BYTES_XMIT,
//    OID_GEN_MULTICAST_FRAMES_XMIT,
//    OID_GEN_BROADCAST_BYTES_XMIT,
//    OID_GEN_BROADCAST_FRAMES_XMIT,
//    OID_GEN_DIRECTED_BYTES_RCV,
//    OID_GEN_DIRECTED_FRAMES_RCV,
//    OID_GEN_MULTICAST_BYTES_RCV,
//    OID_GEN_MULTICAST_FRAMES_RCV,
//    OID_GEN_BROADCAST_BYTES_RCV,
//    OID_GEN_BROADCAST_FRAMES_RCV,
      OID_GEN_RCV_CRC_ERROR,
      OID_GEN_TRANSMIT_QUEUE_LENGTH,
      OID_802_3_PERMANENT_ADDRESS,
      OID_802_3_CURRENT_ADDRESS,
      OID_802_3_MULTICAST_LIST,
      OID_802_3_MAXIMUM_LIST_SIZE,
      OID_802_3_MAC_OPTIONS,            // NEW
      OID_802_3_RCV_ERROR_ALIGNMENT,
      OID_802_3_XMIT_ONE_COLLISION,
      OID_802_3_XMIT_MORE_COLLISIONS,
//    OID_802_3_XMIT_DEFERRED,
      OID_802_3_XMIT_MAX_COLLISIONS,
      OID_802_3_RCV_OVERRUN,
      OID_802_3_XMIT_UNDERRUN,
//    OID_802_3_XMIT_HEARTBEAT_FAILURE,
      OID_802_3_XMIT_TIMES_CRS_LOST,
//    OID_802_3_XMIT_LATE_COLLISIONS,
   };

    VPM_SetupMiniContext;

    //
    // Initialize these once, since this is the majority
    // of cases.
    //
    SourceBuffer       = &GenericUlong;
    SourceBufferLength = sizeof(ULONG);

    switch (Oid) {
    case OID_GEN_SUPPORTED_LIST:
         SourceBuffer =  CrystalGlobalSupportedOids;
         SourceBufferLength = sizeof(CrystalGlobalSupportedOids);
         break;
    case OID_GEN_HARDWARE_STATUS:
         GenericUlong = pvMini_Context->CurrentState;
         break;
    case OID_GEN_MEDIA_SUPPORTED:
    case OID_GEN_MEDIA_IN_USE:
         GenericUlong = NdisMedium802_3;
         break;
    case OID_GEN_MAXIMUM_LOOKAHEAD:
         GenericUlong = VP_MAX_FRAMESIZE - VP_HEADERSIZE;
         break;
    case OID_GEN_MAXIMUM_FRAME_SIZE:
         GenericUlong = VP_MAX_FRAMESIZE - VP_HEADERSIZE; // leave off Header
         break;
    case OID_GEN_LINK_SPEED:
         GenericUlong = 10000 * pChip->Config.MediaSpeed;    // 10 Mbps in 100 bps units
         break;
    case OID_GEN_TRANSMIT_BUFFER_SPACE:
         GenericUlong = pChip->Config.MaxTxCount * VP_MAX_FRAMESIZE;
         break;
    case OID_GEN_RECEIVE_BUFFER_SPACE:
         GenericUlong = VP_MAX_FRAMESIZE;
         break;
    case OID_GEN_TRANSMIT_BLOCK_SIZE:
         GenericUlong = VP_MAX_FRAMESIZE;
         break;
    case OID_GEN_RECEIVE_BLOCK_SIZE:
         GenericUlong = VP_MAX_FRAMESIZE;
         break;
    case OID_GEN_VENDOR_ID:                           // Should be moved to chip config
         NdisMoveMemory(VendorId, pvMini_Context->PermanentNetworkAddress, 3L);
         VendorId[3] = 0x0;
         SourceBuffer = VendorId;
         SourceBufferLength = sizeof(VendorId);
         break;
    case OID_GEN_VENDOR_DESCRIPTION:
         SourceBuffer = (PVOID)IsaDescriptor;         // Should be moved to chip config
         SourceBufferLength = sizeof(IsaDescriptor);  // Should be moved to chip config
         break;
    case OID_GEN_VENDOR_DRIVER_VERSION:
         GenericUlong = (CRYSTAL_MAJOR_VERSION << 16) + CRYSTAL_MINOR_VERSION;
         break;
    case OID_GEN_CURRENT_PACKET_FILTER:
         GenericUlong = pvMini_Context->PacketFilter;
         break;
    case OID_GEN_CURRENT_LOOKAHEAD:
         GenericUlong = pvMini_Context->ProtocolLookahead;
         break;
    case OID_GEN_DRIVER_VERSION:
         GenericUshort = (NDISVerMajor << 8) + NDISVerMinor;
         SourceBuffer = &GenericUshort;
         SourceBufferLength = sizeof(USHORT);
         break;
    case OID_GEN_MAXIMUM_TOTAL_SIZE:
         GenericUlong = VP_MAX_FRAMESIZE;
         break;
//    case OID_GEN_PROTOCOL_OPTIONS:       // Set Only
    case OID_GEN_MAC_OPTIONS:
         GenericUlong = (ULONG)(
//                         NDIS_MAC_OPTION_FULL_DUPLEX |
                           NDIS_MAC_OPTION_TRANSFERS_NOT_PEND   |
#ifdef V8920
                           NDIS_MAC_OPTION_COPY_LOOKAHEAD_DATA  |
#endif
                           NDIS_MAC_OPTION_RECEIVE_SERIALIZED |
                           NDIS_MAC_OPTION_NO_LOOPBACK
                           );
         break;
    case OID_GEN_MEDIA_CONNECT_STATUS:     // NEW
         GenericUlong = pvMini_Context->CableConnected;
         break;
    case OID_GEN_MAXIMUM_SEND_PACKETS:     // NEW
         GenericUlong = pChip->Config.MaxTxCount;
         break;
    case OID_GEN_XMIT_OK:
         GenericUlong = pvMini_Context->XmitOKs;
         break;
    case OID_GEN_RCV_OK:
         GenericUlong = pvMini_Context->RcvOKs;
         break;
    case OID_GEN_XMIT_ERROR:
         GenericUlong = pvMini_Context->XmitErrors;
         break;
    case OID_GEN_RCV_ERROR:
         GenericUlong = pvMini_Context->RcvErrors;
         break;
    case OID_GEN_RCV_NO_BUFFER:
         GenericUlong = pvMini_Context->RcvNoBuffers;
         break;
//  case OID_GEN_DIRECTED_BYTES_XMIT:
//  case OID_GEN_DIRECTED_FRAMES_XMIT:
//  case OID_GEN_MULTICAST_BYTES_XMIT:
//  case OID_GEN_MULTICAST_FRAMES_XMIT:
//  case OID_GEN_BROADCAST_BYTES_XMIT:
//  case OID_GEN_BROADCAST_FRAMES_XMIT:
//  case OID_GEN_DIRECTED_BYTES_RCV:
//  case OID_GEN_DIRECTED_FRAMES_RCV:
//  case OID_GEN_MULTICAST_BYTES_RCV:
//  case OID_GEN_MULTICAST_FRAMES_RCV:
//  case OID_GEN_BROADCAST_BYTES_RCV:
//  case OID_GEN_BROADCAST_FRAMES_RCV:
//       *BytesWritten = 0;                  // TBD!!!!
//       return NDIS_STATUS_RESOURCES;
//       break;
    case OID_GEN_RCV_CRC_ERROR:
         GenericUlong = pvMini_Context->RcvCRCErrors;
         break;
    case OID_GEN_TRANSMIT_QUEUE_LENGTH:
        // GenericUlong = pvMini_Context->XmitQueueDepth;
         GenericUlong = 0L;
         break;
    case OID_802_3_PERMANENT_ADDRESS:
         SourceBuffer = pvMini_Context->PermanentNetworkAddress;
         SourceBufferLength = ETH_LENGTH_OF_ADDRESS;
         break;
    case OID_802_3_CURRENT_ADDRESS:
         SourceBuffer = (PVOID)&pChip->Config.EthernetAddr;
         SourceBufferLength = ETH_LENGTH_OF_ADDRESS;
         break;
    case OID_802_3_MULTICAST_LIST:
         SourceBuffer = pvMini_Context->McastList;
         SourceBufferLength = pvMini_Context->McastListSize * ETH_LENGTH_OF_ADDRESS;
         break;
    case OID_802_3_MAXIMUM_LIST_SIZE:
         GenericUlong = CRYSTAL_MCAST_LIST_SIZE;
         break;
    case OID_802_3_MAC_OPTIONS:            // NEW
         GenericUlong = 0;
         break;
    case OID_802_3_RCV_ERROR_ALIGNMENT:
         GenericUlong = pvMini_Context->RcvErrorAlignments;
         break;
    case OID_802_3_XMIT_ONE_COLLISION:
         GenericUlong = pvMini_Context->XmitOneCollisions;
         break;
    case OID_802_3_XMIT_MORE_COLLISIONS:
         GenericUlong = pvMini_Context->XmitMoreCollisions;
         break;
    case OID_802_3_XMIT_MAX_COLLISIONS:
         GenericUlong = pvMini_Context->XmitMaxCollisions;
         break;
    case OID_802_3_XMIT_LATE_COLLISIONS:
         GenericUlong = pvMini_Context->XmitLateCollisions;
         break;
    case OID_802_3_XMIT_UNDERRUN:
         GenericUlong = pvMini_Context->XmitUnderrun;
         break;
    case OID_802_3_XMIT_TIMES_CRS_LOST:
         GenericUlong = pvMini_Context->XmitLostCRS;
         break;
    case OID_802_3_RCV_OVERRUN:
         GenericUlong = pvMini_Context->RcvOverrun;
         break;
//  case OID_802_3_XMIT_DEFERRED:
//  case OID_802_3_XMIT_HEARTBEAT_FAILURE:
//       *BytesWritten = 0;
//       return NDIS_STATUS_RESOURCES;
//       break;
    default:
         *BytesWritten = 0;
         return NDIS_STATUS_INVALID_OID;
    } /* endswitch */

    if (SourceBufferLength > InformationBufferLength) {

       NdisMoveMemory(InformationBuffer, SourceBuffer, InformationBufferLength);
       *BytesWritten = InformationBufferLength;
       *BytesNeeded = SourceBufferLength;
       return NDIS_STATUS_INVALID_LENGTH;

    }

    NdisMoveMemory(InformationBuffer, SourceBuffer, SourceBufferLength);
    *BytesWritten = SourceBufferLength;

    return NDIS_STATUS_SUCCESS;
}

extern
NDIS_STATUS
CrystalSetInformation(
    IN NDIS_HANDLE MiniportAdapterContext,
    IN NDIS_OID Oid,
    IN PVOID InformationBuffer,
    IN ULONG InformationBufferLength,
    OUT PULONG BytesRead,
    OUT PULONG BytesNeeded
    )

/*++

Routine Description:

    CrystalSetInformation handles a set operation for a
    single OID.

Arguments:

    MiniportAdapterContext - Context registered with the wrapper, really
        a pointer to the VP context.

    Oid - The OID of the set.

    InformationBuffer - Holds the data to be set.

    InformationBufferLength - The length of InformationBuffer.

    BytesRead - If the call is successful, returns the number
        of bytes read from InformationBuffer.

    BytesNeeded - If there is not enough data in InformationBuffer
        to satisfy the OID, returns the amount of storage needed.

Return Value:

    NDIS_STATUS_SUCCESS
    NDIS_STATUS_PENDING
    NDIS_STATUS_INVALID_LENGTH
    NDIS_STATUS_INVALID_OID

--*/

{
    NDIS_STATUS Status = NDIS_STATUS_SUCCESS;
    ULONG PacketFilter;
    ULONG OldPacketFilter;
    WORD  LookAhead;
    WORD  LookAheadIndex;

    VPM_SetupMiniContext;

    //
    // Now check for the most common OIDs
    //
    switch (Oid) {

       case OID_802_3_MULTICAST_LIST:
          /* Make Sure Length of Data looks okay */
          if (InformationBufferLength % ETH_LENGTH_OF_ADDRESS != 0) {
             Status = NDIS_STATUS_INVALID_DATA;
          } else {
             /* Make sure Multicast buffer has not been exceeded */
             if (InformationBufferLength <= sizeof(pvMini_Context->McastList)) {
                /* Copy Multicast addresses and inform VCHIP */
                NdisMoveMemory(pvMini_Context->McastList, InformationBuffer, InformationBufferLength);
                *BytesRead = InformationBufferLength;

                pvMini_Context->McastListSize = InformationBufferLength / ETH_LENGTH_OF_ADDRESS;

                // Do Flush
                VchipMulticastDeleteAll( pChip );

                // Add each one
                for (LookAheadIndex=0;
                     LookAheadIndex < pvMini_Context->McastListSize;
                     LookAheadIndex++ )
                {
                   VchipMulticastAdd( pChip, (PEA)&pvMini_Context->McastList[LookAheadIndex] );
                } /* endfor */

             } else {
                *BytesRead = 0;
                Status = NDIS_STATUS_MULTICAST_FULL;
             } /* endif */
          } /* endif */
          return Status;
          break;

       case OID_GEN_CURRENT_PACKET_FILTER:

          if (InformationBufferLength != 4) {
             *BytesNeeded = 4;
             return NDIS_STATUS_INVALID_LENGTH;
          }
          //
          // Now call the filter package to set the packet filter.
          //
          NdisMoveMemory((PVOID)&PacketFilter, InformationBuffer, (ULONG) sizeof(ULONG));

          //
          // Verify bits
          //
          if (PacketFilter & (NDIS_PACKET_TYPE_SOURCE_ROUTING |
                             NDIS_PACKET_TYPE_SMT |
                             NDIS_PACKET_TYPE_MAC_FRAME |
                             NDIS_PACKET_TYPE_FUNCTIONAL |
                             NDIS_PACKET_TYPE_ALL_FUNCTIONAL |
                             NDIS_PACKET_TYPE_GROUP |
                             NDIS_PACKET_TYPE_ALL_MULTICAST | // Fails Cert test
                             NDIS_PACKET_TYPE_ALL_LOCAL // No Loopback!
                            )) {

             *BytesRead = 4;
             *BytesNeeded = 0;

             return NDIS_STATUS_NOT_SUPPORTED;
          }
          OldPacketFilter = pvMini_Context->PacketFilter;
          pvMini_Context->PacketFilter = PacketFilter;
          pChip->Config.Filtering = 0;
          if (PacketFilter & NDIS_PACKET_TYPE_DIRECTED) {
             pChip->Config.Filtering |= FILTER_INDIVIDUAL_ACCEPT;
          } /* endif */
          if (PacketFilter & NDIS_PACKET_TYPE_BROADCAST) {
             pChip->Config.Filtering |= FILTER_BROADCAST_ACCEPT;
          } /* endif */
          if (PacketFilter & (NDIS_PACKET_TYPE_MULTICAST |
                              NDIS_PACKET_TYPE_ALL_MULTICAST)) {
             pChip->Config.Filtering |= FILTER_MULTICAST_ACCEPT;
             // Do Flush
             VchipMulticastDeleteAll( pChip );
             if (PacketFilter & NDIS_PACKET_TYPE_ALL_MULTICAST) {
                VchipMulticastAddAll( pChip );
             } else {
                // Add each one
                for (LookAheadIndex=0;
                     LookAheadIndex < pvMini_Context->McastListSize;
                     LookAheadIndex++ )
                {
                   VchipMulticastAdd( pChip, (PEA)&pvMini_Context->McastList[LookAheadIndex] );
                } /* endfor */
             }
          } /* endif */
          if (PacketFilter & NDIS_PACKET_TYPE_PROMISCUOUS) {
             pChip->Config.Filtering |= FILTER_PROMISCUOUS_ACCEPT;
          } /* endif */
          VchipChangeFiltering( pChip );

          break;

       case OID_GEN_CURRENT_LOOKAHEAD:


          LookAhead = *((WORD *)InformationBuffer);
          if (LookAhead > (VP_MAX_FRAMESIZE - VP_HEADERSIZE)) {
             return NDIS_STATUS_INVALID_LENGTH;
          }
          pvMini_Context->ProtocolLookahead = LookAhead;

          *BytesRead = InformationBufferLength;

          break;

       case OID_GEN_PROTOCOL_OPTIONS:
          *BytesRead = InformationBufferLength;
          break;

       default:

          *BytesRead = 0;                           //@251
          *BytesNeeded = 0;                         //@251
          return NDIS_STATUS_INVALID_OID;
          break;
    }

    return NDIS_STATUS_SUCCESS;
}

