/* hash.c */

#include <stdio.h>
#include <string.h>
#include "vtypes.h"


#define CRC_PRIME      0xFFFFFFFF;
#define CRC_POLYNOMIAL 0x04C11DB6;


/*******************************************************************************
*
* HexByte
*
* This routine converts a sequence of hex characters to the 8-bit value
* that they represent.  There may be zero, one or two hex characters and
* they may be optionally terminated with a colon or a zero byte.
* The address of the first hex character is passed in the pChar parameter
* and the address just beyond the last hex character is returned.
* The 8-bit variable pointed to by the pByte parameter is updated with
* the converted 8-bit value.  If an error occurred then NULL is returned.
*
*/

char *HexByte( char *pChar, BYTE *pByte )
{
   int x;

   /* Inititalize the byte value to zero */
   *pByte = 0;

   /* Process two hex characters */
   for ( x=0; x<2; x++,pChar++ )
   {
      /* Stop early if find a colon or end of string */
      if ( *pChar==':' || *pChar==0 ) break;

      /* Convert the hex character to a value */
      if ( *pChar >= '0' && *pChar <= '9' )
         *pByte = (*pByte * 16) + *pChar - '0';
      else if ( *pChar >= 'a' && *pChar <= 'f' )
         *pByte = (*pByte * 16) + *pChar - 'a' + 10;
      else if ( *pChar >= 'A' && *pChar <= 'F' )
         *pByte = (*pByte * 16) + *pChar - 'A' + 10;
      else
      {
         printf("\nIllegal character '%c' in Ethernet address\n",
               *pChar );
         return NULL;  /* Illegal character */
      }
   }

   /* Skip past terminating colon */
   if ( *pChar == ':' ) pChar++;

   return pChar;
}


/*******************************************************************************
*
* HexWord
*
* This routine converts a sequence of hex characters to the 16-bit value
* that they represent.  The address of the first hex character is passed
* in the pChar parameter and the address just beyond the last hex
* character is returned.  The 16-bit variable pointed to by the pWord
* parameter is updated with the converted 16-bit value.  If an error
* occurred then NULL is returned.
*
*/

char *HexWord( char *pChar, WORD *pWord )
{
   union
   {
      WORD word;
      BYTE byte[2];
   } Value;

   /* Get the value of the first hex byte */
   pChar = HexByte( pChar, &Value.byte[0] );
   if ( pChar!=NULL && *pChar==0 )
      printf("\nEthernet address must be 12 characters long\n");
   if ( pChar==NULL || *pChar==0 ) return NULL;

   /* Get the value of the second hex byte */
   pChar = HexByte( pChar, &Value.byte[1] );
   if ( pChar==NULL ) return NULL;

   /* Save value of the hex word */
   *pWord = Value.word;

   return pChar;
}


/******************************************************************************
*
* CalculateHashIndex()
*
******************************************************************************/

BYTE CalculateHashIndex( BYTE far *pMulticastAddr )
{
   DWORD CRC;
   BYTE  HashIndex;
   BYTE  AddrByte;
   DWORD HighBit;
   int   Byte;
   int   Bit;

   /* Prime the CRC */
   CRC = CRC_PRIME;

   /* For each of the six bytes of the multicast address */
   for ( Byte=0; Byte<6; Byte++ )
   {
      AddrByte = *pMulticastAddr++;

      /* For each bit of the byte */
      for ( Bit=8; Bit>0; Bit-- )
      {
         HighBit = CRC >> 31;
         CRC <<= 1;

         if ( HighBit ^ (AddrByte & 1) )
         {
            CRC ^= CRC_POLYNOMIAL;
            CRC |= 1;
         }

         AddrByte >>= 1;
      }
   }

   /* Take the least significant six bits of the CRC and copy them */
   /* to the HashIndex in reverse order.                           */
   for( Bit=0,HashIndex=0; Bit<6; Bit++ )
   {
      HashIndex <<= 1;
      HashIndex |= (BYTE)(CRC & 1);
      CRC >>= 1;
   }

   return HashIndex;
}


void main( int argc, char *argv[] )
{
   EA    EthernetAddr;
   char *pChar;
   BYTE *pByte;
   BYTE  HashIndex;
   int   x;

   printf("\n");

   if ( argc == 1 )
   {
      printf("usage: hash <Ethernet address>\n\n");
      return;
   }

   /* pChar points to Ethernet address string on command line */
   pChar = argv[1];

   /* Convert and save the Ethernet address string */
   pChar = HexWord( pChar, &EthernetAddr.Part[0] );
   if ( pChar == NULL ) return;
   pChar = HexWord( pChar, &EthernetAddr.Part[1] );
   if ( pChar == NULL ) return;
   pChar = HexWord( pChar, &EthernetAddr.Part[2] );
   if ( pChar == NULL ) return;

   HashIndex = CalculateHashIndex( (BYTE *)&EthernetAddr );

   pByte = (BYTE *)&EthernetAddr;
   printf("The hash index for Ethernet address ");
   for ( x=0; x<5; x++ ) printf("%02X:", *pByte++ );
   printf("%02X is %d.\n", *pByte, HashIndex );
}


