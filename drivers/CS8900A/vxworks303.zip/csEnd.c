/* csEnd.c - Crystal Semiconductor CS8900 network interface driver          */
/*                                                                          */
/* Copyright 2000 Crystal Semiconductor Corp.                               */
/*                                                                          */
/*               Last release: v3.03a                                       */
/* Mod level for last release: 03a                                          */

/*
modification history
--------------------

v3.03a,10/02/00, kml -Merged for PCx86 and ARM.

   June 20000        -Modified for ARM 940 by Conexant Systems, Inc.                     

  v3.02a,24Sep99, kml  -Set offset 2 to the receiving buffer pointer when copying received frames from chip
                      so that the IP header stars from the 17th bytes for 32-bits-Alignment.
                     -Change receiving buffer size from 32 to 64.
                     -Correction: If the memory address parameter is zero, the CS8900 operates in the
                      mode specified by EEPROM or the Config Flag parameter.

v3.01a,07May99, kml    ported to the Enhanced Network Driver (END) model 
                       to support the MUX interface. 


01g.25nov97.jla  Added defs to help a page fault with hard resets.
                 HARD_RESET does hard chip resets
                 SOFT_RESET does a softer, kinder sort of reset
                 The routine csResetChip does one or the other based
                 on the define set in if_cs.h

01q,11apr97,rks  Implementd "early tx" support.  Required mods to csLoad
                 (initialization), csInitChip (early tx int enable),
                 csTxNextFrame, and csBufferEvent.

01p,09apr97,rks  Replaced common TX code in csStartOutput and csTransmitEvent
                 with a new routine csTxNextFrame().
                 Added conditional compile for a Tx Queue depth and max TX
                 Queue depth counter if CS_DEBUG_ENABLE defined.

01o,07apr97,rks  Changed queue routines (enqueue and deueue) to make the data
                 update prior to pointer update.  Removed the int lock/unlock
                 around the queue accesses in csEventHandler (no longer needed
                 with the new queue routines).
                 Moved the m_freem call to after the intUnlock in csStartOutput.

01n,01apr97,rks  Implemented a local queue for TX frames.  On csStartOuput call,
                 the interface's queue is drained.  Frames are then taken from
                 the local queue in csStartOutput and at ISR level for transmit
                 to ensure the interface's queue is manipulated only by routines
                 at the same context (csStartOuput and ether_output).

01m,30mar97,rks  Modified the csIntHandler.  Removed the chip int disables and
                 replaced with CLI/STI pairs only around queue manipulations.
                 Also, now use a "NetJobDepth" counter instead of an active flag
                 to determine if another csIntHandler needs to be queued.
                 Moved the netJobAdd logic to the bottom of the ISR and removed
                 it from all the ISR sub-routines.

01l,27mar97,rks  Bracketed mbuff routines in csProcessReceive with splnet/splx.

01k,28feb97,rks  Added circular queue manipulation routines to handle TX mbufs
                 to be freed and RX frames to be handled at the task level.
                 Created generic event handler (csEventHandler) to processe RX
                 frame processing and TX mbuff freeing at the task level.
                 Added a counter to ensure never more than 2 instances of the
                 event handler are queued for tNetTask processing.

01j,27feb97,rks  Added support for the collision counter. Moved support for Rx
                 miss counter to ISR (saves a function call).

01h,25feb97,rks  Modifications for MIPS suppport (prevent word reads from odd
                 addresses in csCopyTXFrame.  Debug macro to replace csError
                 routine. (Greg Rasche)

01g,07jan97,rks  Modified csLoad to remove parameter for specifying
                 Ethernet address.

01f,16dec96,rks  Divided the driver into two files, this file for
                 system-indendent routines and "sysEnet.c" containing
                 target-specific routines and macros for "IO mode" operations.
                 Added BYTE_SWAP macro for all non-constant io values
                 to the CS8900.  Replace pcX86-specific io routine
                 calls with SYS_IN/OUT macros.

01e,12dec96,rks  Moved the pTxFrameChain variable to the CS_END_DEVICE structure.
                 Moved the int disable in csStartOutput to immediately
                 before the Rdy4TxNow poll.  Mutex'd the call to
                 IF_DEQUEUE in csStartOutput with splnet/splx.

01d,05dec96,rks  Removed the processing of every RX miss and implemented
                 support for RX miss statistics using the RX miss counter
                 with RX Miss Counter Overflow interrupts instead.

01c,25nov96,rks  Added version number to statistics reported by csShow(),
                 Added support for TX on Rdy4Tx interrupts, Created
                 routine csFreeTxFrame() to move call of m_freem()
                 to task level Added statistic reported by csShow for
                 Rdy4Tx events

01b,16nov96,rks  Removed support for collision counter (AnyColliE) to
                 improve system perf.

01a,12jul96,q_s  Written.

*/



/*
DESCRIPTION
This module implements the Crystal Semiconductor CS8900 Ethernet network
interface driver.

This driver's structure is designed to facilitate porting to any architecture
supported by VxWorks.  The routines in this file are system independent.  A
library of system-dependent routines in the file "csSysEnd.c" must be provided
for the target system.  This driver supports only one CS8900 device per system
board.


SYSTEM DEPENDENT SUPPORT ROUTINES
This driver requires five system-dependent support routines.  These five
routines are defined in sysEnet.c.

* sysEnetGetConfig( CS_END_DEVICE *pCS )
This routine takes configuration parameters not specifed to csEndLoad(), if
any, from non-volatile storage (e.g. an attached EEPROM) and puts them in
the CS_END_DEVICE structure.

* sysEnetAddrGet( CS_END_DEVICE *pCS, unsigned char *pAddr )
This routine obtains the Ethernet MAC address from non-volatile storage or
from the "csEnetAddr" array in csSysEnd.c dependent on the
CS8900_ENET_ADDR_FROM_BOARD flag defined in csSysEnd.c and saves the
Ethernet address to the CS_END_DEVICE structure.

* sysEnetHWInit( CS_END_DEVICE *pCS )
This routine uses global variables in the CS_END_DEVICE structure to configure
the adapter for the board-specific IO circuitry and supported media types.

* sysEnetIntEnable( CS_END_DEVICE *pCS )
This routine enables the interrupt used by the CS8900 at the system level.

* sysEnetIntDisable( CS_END_DEVICE *pCS )
This routine disables the interrupt used by the CS8900 at the system level.  


INCLUDE FILES: csEnd.h, csSysEnd.c
*/



/* INCLUDES */

#include "vxWorks.h"
#include "sysLib.h"
#include "intLib.h"
#include "logLib.h"
#include "netLib.h"
#include "etherLib.h"
#include "stdio.h"
#include "iv.h"
#include "ioctl.h"
#include "taskLib.h"
#include "net/if_subr.h"
#include "etherMultiLib.h"
#include "end.h"
#include "endLib.h"
#include "lstLib.h"

#include "csEnd.h"



/*********************** debug macro *******************************/

 /* this flag is used to turn DEBUG on or off */
#define CS_DEBUG_ENABLE

#ifdef  CS_DEBUG_ENABLE

#define LOGMSG logMsg

#undef LOCAL 
#define LOCAL

typedef struct {
  UINT32 arg1;
  UINT32 arg2;
  UINT32 arg3;
  UINT32 arg4;
} CS_HISTORY_TYPE;

#define CS_HISTORY_SIZE    100
CS_HISTORY_TYPE csHistory[ CS_HISTORY_SIZE ];
UINT32          csHistoryIndex;

/* function prototypes */
STATUS csHistoryInit( void );
STATUS csHistoryShow( void );
STATUS csHistoryAdd( UINT32 arg1, UINT32 arg2, UINT32 arg3, UINT32 arg4 );


#else
#define LOGMSG
#endif

#include "csSysEnd.c" /* lib of BSP specific routines used by CS8900 driver */


/* DEFINES */

#define CS_DRIVER_VER "3.03a" /* Driver revsion number */
#define CS_NAME       "cs"    /* the device name used to locate the END driver*/
#define CS_NAME_LEN    3      /* the length of the CS_NAME + 1 */

/* Configuration items */
#define END_BUFSIZE      (SIZEOF_ETHERHEADER+ETHERMTU+6)/* 4-byte alignment*/
#define END_SPEED        10000000


/* A shortcut for getting the hardware address from the MIB II stuff. */
#define END_HADDR(pEnd)        \
                ((pEnd)->mib2Tbl.ifPhysAddress.phyAddress)

#define END_HADDR_LEN(pEnd) \
                ((pEnd)->mib2Tbl.ifPhysAddress.addrLength)

/*********************** end debug macro *******************************/
 


/* FORWARD DECLARATIONS */

/* This is the only externally visible interface. */
END_OBJ*         csEndLoad (char* initString);

void csShow(void); /* may be called from WindSh */


/*********** END required routines ****************/
LOCAL STATUS        csStart(END_OBJ  * pV);
LOCAL STATUS        csStop(END_OBJ  * pV);
LOCAL STATUS        csUnload(END_OBJ  * pV);
LOCAL int           csIoctl( END_OBJ  * pV, int Command, caddr_t data );
LOCAL STATUS        csSend (END_OBJ  * pV, M_BLK_ID pMBufChain);                          
LOCAL STATUS        csMCastAdd (END_OBJ  * pV, char* pAddress);
LOCAL STATUS        csMCastDel (END_OBJ  * pV, char* pAddress);
LOCAL STATUS        csMCastGet (END_OBJ  * pV, MULTI_TABLE* pTable);
LOCAL STATUS        csPollSend (END_OBJ  * pV, M_BLK_ID pMblk);
LOCAL STATUS        csPollRcv (END_OBJ  * pV, M_BLK_ID pMblk);
LOCAL STATUS        csPollStart (END_OBJ  * pV);
LOCAL STATUS        csPollStop (END_OBJ  * pV);



LOCAL CS_END_DEVICE *csParse( char *initString);
LOCAL STATUS        csInitRxBuff( CS_END_DEVICE *pCS );
LOCAL STATUS        csVerifyChip( CS_END_DEVICE *pCS );

LOCAL STATUS        csInit( CS_END_DEVICE *pCS);
LOCAL void          csInitChip( CS_END_DEVICE *pCS );
LOCAL void          csReset( CS_END_DEVICE *pCS);
LOCAL void          csConfig( CS_END_DEVICE *pCS);
LOCAL STATUS        csResetChip( CS_END_DEVICE *pCS );

LOCAL void csStartOutput( CS_END_DEVICE *pCS, M_BLK_ID pMbuf);
LOCAL void csCopyTxFrame( CS_END_DEVICE *pCS, M_BLK_ID pMbufChain );

LOCAL void csIntr( CS_END_DEVICE *pCS);
LOCAL void csEventHandler( CS_END_DEVICE *pCS );
LOCAL void csBufferEvent( CS_END_DEVICE *pCS, USHORT BuffEvent );
LOCAL void csTransmitEvent( CS_END_DEVICE *pCS, USHORT TxEvent );
LOCAL void csTxNextFrame( CS_END_DEVICE *pCS );
LOCAL void csReceiveEvent( CS_END_DEVICE *pCS, USHORT RxEvent );
LOCAL int  csCopyRxFrame( CS_END_DEVICE *pCS,char *pRxBuff );
LOCAL void csProcessReceive( CS_END_DEVICE *pCS, M_BLK_ID pRxBuff );

LOCAL USHORT csReadPacketPage( CS_END_DEVICE *pCS, USHORT Offset );
LOCAL void   csWritePacketPage( CS_END_DEVICE *pCS, USHORT Offset, USHORT Value );

LOCAL void   csInitQueue( CIR_QUEUE *Q );
LOCAL void   *csDequeue( CIR_QUEUE *Q );
LOCAL STATUS csEnqueue( CIR_QUEUE *Q, void *pBuff );
LOCAL BOOL   csQueueEmpty( CIR_QUEUE *Q );
LOCAL UCHAR  calculateHashIndex(UCHAR *pMulticastAddr);
LOCAL void   updateCrc( USHORT bit );
LOCAL void   csAddrFilterSet(CS_END_DEVICE *pCS);
LOCAL void   csPurgeQs(CS_END_DEVICE *pCS);


extern void *        cacheDmaMalloc (size_t bytes);
extern int endMultiLstCnt( END_OBJ* pEnd);


/* used to calculate multicast hash index */
int CRC_Poly[] = {1,1,1,0,  1,1,0,1,
                  1,0,1,1,  1,0,0,0,
                  1,0,0,0,  0,0,1,1,
                  0,0,1,0,  0,0,0,0 };
int    CRC[33];

/*
 * Declare our function table.  This is static across all driver
 * instances.
 */

LOCAL NET_FUNCS endFuncTable =
    {
    (FUNCPTR) csStart,     /* Function to start the device. */
    (FUNCPTR) csStop,      /* Function to stop the device. */
    (FUNCPTR) csUnload,    /* Unloading function for the driver. */
    (FUNCPTR) csIoctl,     /* Ioctl function for the driver. */
    (FUNCPTR) csSend,      /* Send function for the driver. */
    (FUNCPTR) csMCastAdd,                /* Multicast address add function for the */
                                    /* driver. */
    (FUNCPTR) csMCastDel,                /* Multicast address delete function for */
                                    /* the driver. */
    (FUNCPTR) csMCastGet,                /* Multicast table retrieve function for */
                                    /* the driver. */
    (FUNCPTR) csPollSend,                /* Polling send function for the driver. */
    (FUNCPTR) csPollRcv,                /* Polling receive function for the driver. */
     endEtherAddressForm,        /* Put address info into a packet.  */
     endEtherPacketDataGet,      /* Get a pointer to packet data. */
     endEtherPacketAddrGet       /* Get packet addresses. */
    };



/* ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ *
 * OS Entry-point Routines                                                 *
 * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ */

/*******************************************************************************
*
* csEndLoad - initialize the driver and device
*
* This routine initializes the driver and the device to the operational state.
* All of the device specific parameters are passed in the initString.
*
* The string contains the target specific parameters like this:
*
* "Unit:IOAddr:IntLevel:MemAddr:MediaType:ConfigFlags"
*
* RETURNS: An END object pointer or NULL on error.
*/

END_OBJ* csEndLoad (
    char* initString                /* String to be parsed by the driver. */
    )
{
FAST CS_END_DEVICE *pCS;
STATUS status1, status2;

    if (initString == NULL)
        return (NULL);

        /*OS wants to get the END Ethernet device name if a null string is passed.*/
    if (initString[0] == NULL)
    {
        bcopy((char *)CS_NAME, initString, CS_NAME_LEN);
        LOGMSG("csEndLoad(): Returning CS8900 Device Name string...\n", 0, 0, 0,0, 0,0);
        return ((END_OBJ *)OK);
    }

   /* parse the init string, filling in the device structure */
   pCS=csParse (initString);
   if (pCS == NULL)
   {
      LOGMSG("csEndLoad(): Parser Error in initString.\n", 0, 0, 0 ,0, 0 ,0);
      return NULL;
   }

   /* Start out in IO mode */
   pCS->InMemoryMode = FALSE;

   /* Init TX in progress flag */
   pCS->TxInProgress = FALSE;

   /* Init the TX start command */
   pCS->TxStartCMD = CS_INITIAL_START_CMD;
   
   /* Set counters to zero */
   pCS->TxUnderruns      = 0;
   pCS->TotalTxUnderruns = 0;

   pCS->Collisions       = 0;
   pCS->MaxTxDepth       = 0;
   pCS->Rdy4TxInts       = 0;
   pCS->NetJobDepth      = 0;

#ifdef CS_DEBUG_ENABLE
   pCS->TxQueueDepth    = 0;
   pCS->MaxTxQueueDepth = 0;
#endif

   /* Initialize local queues */
   pCS->pTxBuffFreeList = &TxBuffFreeList;
   pCS->pRxBuffProcessList = &RxBuffProcessList;
   pCS->pTxQueue = &TxQueue;
   csInitQueue( pCS->pTxBuffFreeList );
   csInitQueue( pCS->pRxBuffProcessList );
   csInitQueue( pCS->pTxQueue );
   
   /* Allocate the receive frame buffers */
   if ( csInitRxBuff(pCS) == ERROR )
   {
      LOGMSG("csEndLoad: CS_END_DEVICE %d Can not allocate receive buffers\n", 
              pCS->unit,0,0,0,0,0 );
      return NULL;
   }

   /* Verify that it is the correct chip */
   if ( csVerifyChip(pCS) == ERROR )
   {
      LOGMSG("csEndLoad: CS_END_DEVICE %d, csVerifyChip failed\n", 
              pCS->unit,0,0,0,0,0 );
      return NULL;
   }

   /* Get any CS8900 parameters not specifed in network interface table */
   if ( sysEnetGetConfig(pCS) == ERROR )
   {
      LOGMSG("csEndLoad: CS_END_DEVICE %d, sysEnetGetConfig failed\n", 
              pCS->unit,0,0,0,0,0 );
      return NULL;
   }

   /* Get Ethernet addr in BSP-specific manner*/
   if ( sysEnetAddrGet(pCS,pCS->enetAddr) == ERROR )
   {
      LOGMSG("csEndLoad: CS_END_DEVICE %d, sysEnetAddrGet failed\n", 
         pCS->unit,0,0,0,0,0 );
      return NULL;
   }


   /* initialize the END and MIB2 parts of the structure 
    * The M2 element must come from m2Lib.h 
    * This template is set up for a DIX type ethernet device.
    */

   status1 = END_OBJ_INIT (&pCS->end, (DEV_OBJ *)pCS, (char *)CS_NAME,
                           pCS->unit, &endFuncTable,
                           "MUX-based Cirrus Logic CS8900 Ethernet Driver.");
   status2 = END_MIB_INIT (&pCS->end, M2_ifType_ethernet_csmacd,
                           &pCS->enetAddr[0], 6,
                           SIZEOF_ETHERHEADER+ETHERMTU, END_SPEED);
   if ((status1 == ERROR) || (status2 == ERROR))
   {
      LOGMSG("csEndLoad: CS_END_DEVICE %d,  END_OBJ_INIT or END_MIB_INIT failed\n", 
         pCS->unit,0,0,0,0,0 );
      return( NULL );
   }
      

   /* Reset the chip */
   if ( csResetChip(pCS) == ERROR )
   {
      LOGMSG("csEndLoad: CS_END_DEVICE %d, Can not reset chip\n", 
         pCS->unit,0,0,0,0,0 );
      return NULL;
   }

    
    /* set the flags to indicate readiness */ 
    END_OBJ_READY (&pCS->end, IFF_NOTRAILERS | IFF_BROADCAST | IFF_MULTICAST );

    /* Set promiscuous mode if user asked for. */
    if ( pCS->ConfigFlags & CFGFLG_PROMISC_MODE )
    {
       END_FLAGS_SET(&pCS->end, IFF_PROMISC);
    }

    LOGMSG("csEndLoad: CS_END_DEVICE %d, csEndLoad has finished successfully!\n", 
            pCS->unit,0,0,0,0,0 );

    return (&pCS->end);
}


/*******************************************************************************
*
* csParse - parse the init string
*
* Parse the input string.  Fill in values in the driver control structure.
*
* The initialization string format is:
*  "Unit:IOAdr:IntLevel:MemAddr:MediaType:ConfigFlags"
*
* .bS
* unit                Device unit number, a small integer, Decimal.
* IOAdr                IO address, Hexadecimal.
* intLevel        Interrupt level, Decimal. 
* memAddr        Memory Address, Hexadecimal.
* mediaType Media Type, Decimal.
* cofigFlag COnfiguration flags. See definition of flags in csEnd.h, Hexadecimal. 
*
* .bE
*
* RETURNS: NULL for invalid arguments or Pointer to CS_END_DEVICE for the device.
*/

CS_END_DEVICE *csParse (
    char *initString                /* information string */
    )
{
char*        tok;
char*        pHolder = NULL;
int          unit;
unsigned long  tmp_long;
unsigned short tmp_short;
CS_END_DEVICE *pCS;

   /* Parse the initString */
   /* Unit number. */
   tok = strtok_r (initString, ":", &pHolder);
   if (tok == NULL)
      return NULL;

   unit = atoi(tok);
   if ( unit >= CS_MAX_NUM_UNITS )
   {
      LOGMSG("csEndLoad: Invalid unit number (%d)\n", unit,0,0,0,0,0 );
      return NULL;
   }
   pCS = &cs_end[unit];
   pCS->unit =unit;

   /* Save the passed-in parameters */

   tok = strtok_r (NULL, ":", &pHolder);
   if (tok == NULL)
   {
      return NULL;
   }
   tmp_long = strtoul (tok, NULL, 16);
   pCS->IOAddr= tmp_long;

   tok = strtok_r (NULL, ":", &pHolder);
   if (tok == NULL) return NULL;
   tmp_short = (USHORT )strtoul(tok, NULL, 16);
   pCS->IntLevel= tmp_short;

#if CPU_FAMILY != ARM
    pCS->IntVector = sysVectorIRQ0 + pCS->IntLevel;
#endif

   tok = strtok_r (NULL, ":", &pHolder);
   if (tok == NULL) return NULL;
   tmp_long = strtoul (tok, NULL, 16);
   pCS->pPacketPage= (unsigned short *)tmp_long;

   tok = strtok_r (NULL, ":", &pHolder);
   if (tok == NULL) return NULL;
   tmp_short = (USHORT )atoi(tok);
   pCS->MediaType = tmp_short;

   tok = strtok_r (NULL, ":", &pHolder);
   if (tok == NULL) return NULL;
   tmp_long = (USHORT)strtoul (tok, NULL, 16);
   pCS->ConfigFlags = tmp_long;

   LOGMSG("csParser(): IOAddr=0X%X, IntLevel=%d, IntVect=0X%X, 
           MemBase=0X%X, MediaType=%d, ConfigFlag=0X%X\n", 
           pCS->IOAddr,pCS->IntLevel,pCS->IntVector,(unsigned int)pCS->pPacketPage,
           pCS->MediaType, pCS->ConfigFlags );
 
   return pCS;
}

/*******************************************************************************
*
* csInitRxBuff -
*
* This routine initializes the network interface driver's collection of
* receive buffers.  The receive buffers are allocated from system memory
* and linked together in a linked list of free receive buffers.
*
* RETURNS: OK or ERROR.
*/

LOCAL STATUS csInitRxBuff( CS_END_DEVICE *pCS )
{
  M_CL_CONFIG endMclBlkConfig=         /* network mbuf configuration table */
       
 /* no. mBlks  no. clBlks memArea memSize
    ---------  ---------- ------- ------- */
  { 0,           0,         NULL,         0 };
    


  CL_DESC endClDescTbl []= {        /* network cluster pool configuration table */    
/*  clusterSize                    num                    memArea        memSize
    ------------  ----------------        -------        ------- */
    {END_BUFSIZE, CS_NUM_RX_BUFFERS, NULL,            0}
  }; 

  int endClDescTblNumEnt;


   /* Allocate Memory for Clusters used by RX buffers */
    
   if ((pCS->end.pNetPool = malloc(sizeof(NET_POOL))) == NULL)
        return (ERROR);

    endMclBlkConfig.mBlkNum = 2*CS_NUM_RX_BUFFERS;
    endMclBlkConfig.clBlkNum = CS_NUM_RX_BUFFERS;
   
  
    /* Calculate the total memory for all the M-Blks and CL-Blks. */

    endMclBlkConfig.memSize = (endMclBlkConfig.mBlkNum * (MSIZE + sizeof (long))) +
                          (endMclBlkConfig.clBlkNum * (CL_BLK_SZ + sizeof(long)));

    if ((endMclBlkConfig.memArea = (char *) memalign (sizeof(long),
                             endMclBlkConfig.memSize)) == NULL)
    {
       LOGMSG("csInitRxBuff: Unit=%d Memory unavailable. memalign() Failed!\n", 
                        pCS->unit, 0, 0, 0, 0, 0);
       return (ERROR);
    }
    
    /* Calculate the memory size of all the clusters. */

    endClDescTbl[0].memSize = (endClDescTbl[0].clNum * (END_BUFSIZE + 8))
                              + sizeof(int);

    /* Allocate the memory for the clusters from cache safe memory. */

   endClDescTbl[0].memArea =(char *) cacheDmaMalloc(endClDescTbl[0].memSize);
    

   if ((int)endClDescTbl[0].memArea == NULL)
   {
      LOGMSG("csInitRxBuff: Unit=%d System memory unavailable\n", 
              pCS->unit, 0, 0, 0, 0, 0);
      return (ERROR);
   }
    

   endClDescTblNumEnt = (NELEMENTS(endClDescTbl));
 
   /* Initialize the memory pool. */

   if (netPoolInit(pCS->end.pNetPool, &endMclBlkConfig,
                    &endClDescTbl[0], endClDescTblNumEnt, NULL) == ERROR)
   {
        LOGMSG("csInitRxBuff: Unit=%d Could not init buffering\n",
                pCS->unit, 0, 0, 0, 0, 0);
        return (ERROR);
   }

   /* Store the cluster pool id as others need it later. */
   pCS->pClPoolId = netClPoolIdGet(pCS->end.pNetPool, (int)END_BUFSIZE, (BOOL)FALSE);
   if (pCS->pClPoolId == NULL)
   {
        LOGMSG("csInitRxBuff: Unit=%d Could not memory cluster ID\n",
                pCS->unit, 0, 0, 0, 0, 0);
        return (ERROR);
   }
   
   return OK;
}


/*******************************************************************************
*
* csVerifyChip -
*
* This routine verifies that the Ethernet chip is present and correct.
*
*/

LOCAL STATUS csVerifyChip( CS_END_DEVICE *pCS )
{
USHORT wrVal, rdVal;
USHORT errorCount = 0;
USHORT x=0xFFFF;

   /* Verify that we can read from the chip */
   x = csReadPacketPage( pCS, PKTPG_EISA_NUM );
   if ( x == 0xFFFF )
   {
      LOGMSG("csVerifyChip: CS_END_DEVICE %d, can't read from chip (I/O address correct?)\n",
              pCS->unit, 0,0,0,0,0 );
      return ERROR;
   }

   /* Verify that the chip is a Crystal Semiconductor chip */
   if ( x != EISA_NUM_CRYSTAL )
   {
      LOGMSG("csVerifyChip: CS_END_DEVICE %d, Chip is not a Crystal Semiconductor chip\n",
              pCS->unit, 0,0,0,0,0 );
      return ERROR;
   }

   /* Verify that the chip is a CS8900 */
   x = csReadPacketPage(pCS,PKTPG_PRODUCT_ID);
   x &= PROD_ID_MASK;
   if ( x != PROD_ID_CS8900)
   {
      LOGMSG("csVerifyChip: CS_END_DEVICE %d, Chip is not a CS8900p\n",
              pCS->unit, 0,0,0,0,0 );
      return ERROR;
   }

    /* walk a one in the memory of the enet controller */
    for( wrVal = 0x0001; wrVal != 0; wrVal <<= 1 )
    {
 
      for( x=0x150; x<= 0x15d; x+=2 )
      {
        /* write out value - don't swap bytes */
        csWritePacketPage( pCS, x, wrVal );
   
        /* read back value - don't swap bytes */
        rdVal = csReadPacketPage( pCS, x );
  
        if( wrVal != rdVal )
        {
          if( errorCount <=10 )
          {
            LOGMSG("csVerifyChip:  ERROR reg %04X, wrVal %04X, rdVal %04X\n",
                    x, (unsigned int) BYTE_SWAP(wrVal),
                    (unsigned int) BYTE_SWAP(rdVal),0,0,0 );
          }
          errorCount++;
        }
      }
    } /* end walking one test */

    /* write incrementing value test */
    for( x=0x150, wrVal=0x0101; x<= 0x15d; x+=2, wrVal+=0x0101 )
    {
      /* write out value - don't worry about swapping bytes */
      csWritePacketPage( pCS, x, wrVal );
    } 

    /* read incrementing value test */
    for( x=0x150, wrVal=0x0101; x<= 0x15d; x+=2, wrVal+=0x0101 )
    {
       /* read back value - don't worry about swapping bytes */
       rdVal = csReadPacketPage( pCS, x );
 
       if( wrVal != rdVal )
       {
          LOGMSG("\ncsVerifyChip:  ERROR reg %04X, wrVal %04X, rdVal %04X\n",
                  x, (unsigned int) BYTE_SWAP(wrVal), 
                  (unsigned int) BYTE_SWAP(rdVal),0,0,0 );
          errorCount++;
       }
    } /* end walking one test */

    if( errorCount != 0 )
    {
        LOGMSG("csVerifyChip: ERROR SRAM test failed, errorCount %d\n", 
                errorCount,0,0,0,0,0 );
        return( ERROR );
    }

    return OK;
}


/*******************************************************************************
*
* csStart - start the device
*
* This function calls BSP functions to connect interrupts and start the
* device running in interrupt mode.
*
* RETURNS: OK or ERROR
*
*/

LOCAL STATUS csStart(END_OBJ *pV )
{
CS_END_DEVICE *pCS;

/* @Conexant ARM 940 specific code 
extern CS_END_DEVICE *EndObject;
*/
   pCS=(CS_END_DEVICE *)pV;


/* @Conexant ARM 940 specific code 
   EndObject = pCS;
*/
  
   
/* For @Conexant ARM 940 User: 
Mark out the following code.*/ 
   /* Setup the interrupt handler and the IDT table entry */
   if ( intConnect(INUM_TO_IVEC(pCS->IntVector),csIntr, (int)pCS) == ERROR )
   {
      LOGMSG("csStart: CS_END_DEVICE %d, Can not connect intertupt\n", 
         pCS->unit,0,0,0,0,0 );
      return NULL;
   }



   LOGMSG("csStart: unit=%d, Initializing interface\n",
           pCS->unit, 0,0,0,0,0 );

   /* Initialize the chip */
   csInitChip( pCS );

   /* Enable CS8900 interrupts at the system level */
   if ( sysEnetIntEnable(pCS) == ERROR )
   {
      LOGMSG("csStart: CS_END_DEVICE %d, sysEnetIntEnable failed\n", 
              pCS->unit,0,0,0,0,0 );
      return( NULL );
   }


   /* Mark the interface as up and running */
   END_FLAGS_SET (&pCS->end, IFF_UP | IFF_RUNNING);

   return OK;
}

/*******************************************************************************
*
* csStop - stop the device
*
* This function calls BSP functions to disconnect interrupts and stop
* the device from operating in interrupt mode.
*
* RETURNS: OK or ERROR.
*/
LOCAL STATUS csStop(END_OBJ *pV)
{
CS_END_DEVICE *pCS;

   pCS=(CS_END_DEVICE *)pV;

   /* disable CS8900 interrupts at the system level */
   if ( sysEnetIntDisable(pCS) == ERROR )
   {
      LOGMSG("csStop: CS_END_DEVICE %d, sysEnetIntDisable failed\n", 
              pCS->unit,0,0,0,0,0 );
      return( NULL );
   }

   /* set the flags to indicate NIC status */ 
   /* Mark the interface as down */
   END_FLAGS_CLR (&pCS->end, IFF_UP | IFF_RUNNING);

   /* Stop the chip */
   if ( csResetChip(pCS) == ERROR )
   {
      LOGMSG("csStop: CS_END_DEVICE %d, Can not reset the chip\n",
              pCS->unit, 0,0,0,0,0 );
      return ERROR;
   }


   LOGMSG("csStop(): unit=%d, The CS8900 device has been stopped.\n", 
            pCS->unit,0,0,0,0,0 );


   return OK;
}


/******************************************************************************
*
* csUnload - unload a driver from the system
*
* This function first brings down the device, and then frees any
* stuff that was allocated by the driver in the load function.
*
* RETURNS: OK or ERROR.
*/

LOCAL STATUS csUnload ( END_OBJ *pV        /* device to be unloaded */
    )
{
CS_END_DEVICE *pCS;

   pCS=(CS_END_DEVICE *)pV;

   END_OBJECT_UNLOAD (&pCS->end);
   LOGMSG("csUnLoad(): unit=%d, CS8900 driver is unloaded!\n", 
           pCS->unit,0,0,0,0,0 );
   return (OK);
}

/*******************************************************************************
*
* csIoctl -
*
* This routine is a major entry point and is called by the protocol stack to
* modify characteristics of this network interface driver.  
*/
LOCAL int csIoctl(     
    END_OBJ *pV,        /* device receiving command */
    int cmd,                        /* ioctl command code */
    caddr_t data                /* command argument */
    )
{
int status = 0;
long value;
CS_END_DEVICE *pCS;

   pCS=(CS_END_DEVICE *)pV;

   switch( cmd )
   {
      case EIOCSADDR:
         if (data == NULL)
            return (EINVAL);
         bcopy ((char *)data, (char *)END_HADDR(&pCS->end), 
                END_HADDR_LEN(&pCS->end));
         bcopy( (char *)data, (char *)pCS->enetAddr, 6);
         csConfig(pCS);
         break;
      case EIOCGADDR:
         if (data == NULL) return (EINVAL);
         bcopy ((char *)END_HADDR(&pCS->end), (char *)data,
                END_HADDR_LEN(&pCS->end));
         break;
      case EIOCSFLAGS: /* set Promiscuous Mode */
         value = (long)data;
         if (value < 0)
         {
            value = -(--value);
            END_FLAGS_CLR (&pCS->end, value);
         }
         else
         {
            END_FLAGS_SET (&pCS->end, value);
         }
         csConfig (pCS);
         break;
      case EIOCGFLAGS:
         *(int *)data = END_FLAGS_GET(&pCS->end);
         break;
      case EIOCMULTIADD:
         status = csMCastAdd ((void*)pCS, (char *) data);
         break;
      case EIOCMULTIDEL:
         status = csMCastDel ((void*)pCS, (char *) data);
         break;
      case EIOCMULTIGET:
         status = csMCastGet ((void*)pCS, (MULTI_TABLE *) data);
         break;
      case EIOCPOLLSTART:
         csPollStart ((void*)pCS);
         break;
      case EIOCPOLLSTOP:
         csPollStop ((void*)pCS);
         break;
      case EIOCGMIB2:
         if (data == NULL) return (EINVAL);
         bcopy((char *)&pCS->end.mib2Tbl, (char *)data,
               sizeof(pCS->end.mib2Tbl));
         break;
      case EIOCGFBUF:
         if (data == NULL)
         return (EINVAL);
         *(int *)data = CS_MIN_FBUF;
         break;
      default:
         status = EINVAL;
   }


   return (status);
}


/*******************************************************************************
*
* csSend - the driver send routine
*
* This routine takes a M_BLK_ID sends off the data in the M_BLK_ID.
* The buffer must already have the addressing information properly installed
* in it.  This is done by a higher layer.    
*
* RETURNS: OK or ERROR.
*/

LOCAL STATUS csSend ( END_OBJ  *pV,        /* device ptr */
                      M_BLK_ID pMBuff   /* data to send */
)
{    
   int         oldLevel=0;
CS_END_DEVICE *pCS;

   pCS=(CS_END_DEVICE *)pV;
   /*
    * Obtain exclusive access to transmitter.  This is necessary because
    * we might have more than one stack transmitting at once.
    */

    if (!(pCS->ConfigFlags & CFGFLG_POLL_MODE))
        END_TX_SEM_TAKE (&pCS->end, WAIT_FOREVER);

    /* This is the normal case where all the data is in one M_BLK_ID */
    /* Set pointers in local structures to point to data. */
    /* place a transmit request */

    if (!(pCS->ConfigFlags & CFGFLG_POLL_MODE))
    {
	  /*  disable interrupts*/
      oldLevel=INT_LOCK();
    }
    
    /* initiate device transmit */
    csStartOutput(pCS, pMBuff);

    if (!(pCS->ConfigFlags & CFGFLG_POLL_MODE))
    {
 	  /*  enable interrupts*/
      INT_UNLOCK(oldLevel);
    }
    
    /* Advance our management index */

    if (!(pCS->ConfigFlags & CFGFLG_POLL_MODE))
        END_TX_SEM_GIVE (&pCS->end);

    return (OK);
}


/* ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ *
 * Interrupt-handler Routines                                              *
 * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ */


/*******************************************************************************
*
* csIntr -
*
* This routine in the interrupt service routine.  This routine is called by
* VxWorks wrapper code whenever the CS8900 chip generates and interrupt.  The 
* wrapper code issues an EOI command.
*
* This routine processes the events on the Interrupt Status Queue.  The events
* are read one at a time from the ISQ and the appropriate event handlers are
* called.  The ISQ is read until it is empty.  Reading a zero from the ISQ will
* deassert the interrupt request line.
*
* RETURNS: Nothing
*
*/

LOCAL void csIntr(CS_END_DEVICE *pCS)
{
   USHORT Event;

   /* Ignore any interrupts that happen while the chip is being reset */
   if( pCS->Resetting )
      return;

   /* Set locale flag */
   pCS->InISR = TRUE;
   /* Read an event from the Interrupt Status Queue */
   if( pCS->InMemoryMode )
      Event = csReadPacketPage( pCS, PKTPG_ISQ );
   else
      Event = SYS_ENET_IN_WORD( (pCS->IOAddr)+PORT_ISQ );

   /* Process all the events in the Interrupt Status Queue */
   while( Event != 0 )
   {
      /* Dispatch to an event handler based on the register number */
      switch ( Event & REG_NUM_MASK )
      {
         case REG_NUM_RX_EVENT:
            csReceiveEvent( pCS, Event );
            break;

         case REG_NUM_TX_EVENT:
            csTransmitEvent( pCS, Event );
            break;

         case REG_NUM_BUF_EVENT:
            csBufferEvent( pCS, Event );
            break;

         case REG_NUM_RX_MISS: 
            /* Read the Rx Miss count (clears the counter). */
            /* Miss count is in the 10 MSBs */
            /*pCS->ArpCom.ac_if.if_ierrors += ( (BYTE_SWAP(Event)) >> 6); */
            END_ERR_ADD (&pCS->end, MIB2_IN_ERRS,( (BYTE_SWAP(Event)) >> 6) );

            LOGMSG("csRxMissEvent: CS_END_DEVICE %d,, %d added to RX miss counter\n",
            pCS->unit, ( (BYTE_SWAP(Event)) >> 6),0,0,0,0 );
            break;

         case REG_NUM_TX_COL:  
            /* Read the collision counter (clears the counter). */           
            /* Collision count is in the 10 MSBs */
            pCS->Collisions += ( (BYTE_SWAP(Event)) >> 6);
        
            LOGMSG("csTxColEvent: CS_END_DEVICE %d, %d added to collision counter\n",
            pCS->unit, ( (BYTE_SWAP(Event)) >> 6),0,0,0,0 );
            break;
  
         default: 
            LOGMSG("csIntr: CS_END_DEVICE %d, Unknown interrupt event: %04X\n",
               pCS->unit, (BYTE_SWAP(Event)),0,0,0,0 );
            break;
      }

      /* Read another event from the Interrupt Status Queue */
      if ( pCS->InMemoryMode )
         Event = csReadPacketPage( pCS, PKTPG_ISQ );
      else
         Event = SYS_ENET_IN_WORD( (pCS->IOAddr)+PORT_ISQ );
   }
   
   /* Ensure task-level event handler is running */
   if( pCS->NetJobDepth < 2 )
   {
      pCS->NetJobDepth++;
      netJobAdd( (FUNCPTR)csEventHandler, (int)pCS, 0, 0, 0, 0 ); 
   }

   /* Clear locale flag */
   pCS->InISR = FALSE;
}


/*******************************************************************************
*
* csBufferEvent -
*
* The routine is called whenever an event occurs regarding the transmit and
* receive buffers within the CS8900 chip.  The only buffer events we 
* currently handle are Rdy4TX interrupts, Tx Underruns, and SW ints.
*
*/

LOCAL void csBufferEvent( CS_END_DEVICE *pCS, USHORT BufEvent )
{
USHORT BusStatus;

   if ( BufEvent & BUF_EVENT_TX_UNDR )
   {

      /* TX underrun occured */
      pCS->TxUnderruns++;

      /* Modify start command if total underruns > threshold value */
      /* by setting TX start command to next increment */
      if( pCS->TxUnderruns == CS_TX_UNDRUN_TRHSHOLD )
      {
          /* Reset the threshold counter */
          pCS->TxUnderruns = 0;
          
          /* Select the next TxStartCommand */ 
          if( pCS->TxStartCMD == TX_CMD_START_5 )
             pCS->TxStartCMD = TX_CMD_START_381;

          else if( pCS->TxStartCMD == TX_CMD_START_381 )
             pCS->TxStartCMD = TX_CMD_START_1021;

          else pCS->TxStartCMD = TX_CMD_START_ALL;
      }
       
      /* Try to TX the frame again */
      if ( pCS->InMemoryMode )
      {
            csWritePacketPage( pCS, PKTPG_TX_CMD, pCS->TxStartCMD );
            csWritePacketPage( pCS, PKTPG_TX_LENGTH, BYTE_SWAP(pCS->TxLength) );
      }
      else  /* In IO mode */
      {
            SYS_ENET_OUT_WORD( (pCS->IOAddr)+PORT_TX_CMD, pCS->TxStartCMD );
            SYS_ENET_OUT_WORD( (pCS->IOAddr)+PORT_TX_LENGTH, 
            BYTE_SWAP(pCS->TxLength));
      }

      /* Read BusStatus register which indicates success of the request */
      BusStatus = csReadPacketPage( pCS, PKTPG_BUS_ST );

      if ( BusStatus & BUS_ST_RDY4TXNOW )
      {
            /* On-chip buffer space available -- start transmission */
             csCopyTxFrame( pCS, pCS->pTxFrameChain );
      }

      LOGMSG("csBufferEvent: CS_END_DEVICE %d, Transmit underrun\n",
         pCS->unit, 0,0,0,0,0 );

      pCS->TotalTxUnderruns++;
   }


   else if ( BufEvent & BUF_EVENT_RDY4TX )
   {
      (pCS->Rdy4TxInts) += 1;

      /* The chip is ready for transmission now */

      /* If a TX is pending, copy the frame to the chip to start transmission */
      if( pCS->pTxFrameChain != NULL )
      {
         csCopyTxFrame( pCS, pCS->pTxFrameChain );
      }
   }


   else if ( BufEvent & BUF_EVENT_SW_INT )
   {
      LOGMSG("csBufferEvent: CS_END_DEVICE %d, Software initiated interrupt\n",
         pCS->unit, 0,0,0,0,0 );
   }
}




/*******************************************************************************
*
* csTransmitEvent -
*
* This routine is called whenever the transmission of a packet has completed
* successfully or unsuccessfully.  If the transmission was not successful,
* then the output error count is incremented.  If there are more packets in the
* transmit queue, then the next packet is started immediately.
*
*/

LOCAL void csTransmitEvent( CS_END_DEVICE *pCS, USHORT TxEvent )
{
   /* WE only get here if the transmit in progress has completed, either 
    * successfully or due to an error condition.  In any event, queue the 
    * mbuf chain for freeing at task level and NULL the frame pointer to mark
    * the TX no longer in progress.
    */

   csEnqueue( pCS->pTxBuffFreeList, pCS->pTxFrameChain );
   pCS->pTxFrameChain = NULL;
   pCS->TxInProgress = FALSE;   

   /* If there were any errors transmitting this frame */
   if ( TxEvent & (TX_EVENT_LOSS_CRS | TX_EVENT_SQE_ERR | TX_EVENT_OUT_WIN |
            TX_EVENT_JABBER | TX_EVENT_16_COLL) )
   {
      /* Increment the output error count */
    /* @kml	 The definition of the MIB-II variable ifOutUcastPkts in Interface
	   group from RFC 1158 is "The total  number of  packets that higher-level 
	   protocols requested be transmitted to a subnetwork-unicast address, 
	   INCLUDE those that were discarded or not sent."*/
      END_ERR_ADD (&pCS->end, MIB2_OUT_ERRS, +1);

      /* If debugging is enabled then log error messages */
#ifdef  CS_DEBUG_ENABLE

         if ( TxEvent & TX_EVENT_LOSS_CRS )
         {
            LOGMSG("csTransmitEvent: CS_END_DEVICE %d, Loss of carrier\n",
               pCS->unit, 0,0,0,0,0 );
         }
         if ( TxEvent & TX_EVENT_SQE_ERR )
         {
            LOGMSG("csTransmitEvent: CS_END_DEVICE %d, SQE error\n",
               pCS->unit, 0,0,0,0,0 );
         }
         if ( TxEvent & TX_EVENT_OUT_WIN )
         {
            LOGMSG("csTransmitEvent: CS_END_DEVICE %d, Out-of-window collision\n",
               pCS->unit, 0,0,0,0,0 );
         }
         if ( TxEvent & TX_EVENT_JABBER )
         {
            LOGMSG("csTransmitEvent: CS_END_DEVICE %d, Jabber\n",
               pCS->unit, 0,0,0,0,0 );
         }
         if ( TxEvent & TX_EVENT_16_COLL )
         {
            LOGMSG("csTransmitEvent: CS_END_DEVICE %d, 16 collisions\n",
               pCS->unit, 0,0,0,0,0 );
         }
#endif

    }

   /* Previous TX complete so start the next TX now if more to transmit */
   csTxNextFrame( pCS );

}




/*******************************************************************************
*
* csReceiveEvent -
*
* This routine is called whenever a packet is received at the chip.  If the
* packet is received with errors, then the input error count is incremented.
* If the packet is received OK, then the data is copied to an internal receive
* buffer and processed at task level (in csEventHandler). 
*
* RETURNS: Nothing
*/

LOCAL void csReceiveEvent( CS_END_DEVICE *pCS, USHORT RxEvent )
{
   M_BLK_ID         pMblk;
   CL_BLK_ID        pClBlk;
   char *pData;
   int DataLen;

 
  /* If the frame was not received OK */
   if ( !(RxEvent & RX_EVENT_RX_OK) )
   {

      /* Increment the input error count */
      /*pIf->if_ierrors++;*/
      END_ERR_ADD (&pCS->end, MIB2_IN_ERRS, +1);

      /* If debugging is enabled then log error messages */
#ifdef  CS_DEBUG_ENABLE

         /* If an error bit is set */
         if ( RxEvent != REG_NUM_RX_EVENT )
         {
            if ( RxEvent & RX_EVENT_RUNT )
            {
              LOGMSG("csReceiveEvent: CS_END_DEVICE %d, Runt\n",
                 pCS->unit, 0,0,0,0,0 );
            }
            if ( RxEvent & RX_EVENT_X_DATA )
            {
              LOGMSG("csReceiveEvent: CS_END_DEVICE %d, Extra data\n",
                 pCS->unit, 0,0,0,0,0 );
            }
            if ( RxEvent & RX_EVENT_CRC_ERR )
            {
               if ( RxEvent & RX_EVENT_DRIBBLE )
               {
                  LOGMSG("csReceiveEvent: CS_END_DEVICE %d, Alignment error\n",
                     pCS->unit, 0,0,0,0,0 );
               }
               else
               {
                  LOGMSG("csReceiveEvent: CS_END_DEVICE %d, CRC Error\n",
                     pCS->unit, 0,0,0,0,0 );
               }
            }
            else if ( RxEvent & RX_EVENT_DRIBBLE )
            {
               LOGMSG("csReceiveEvent: CS_END_DEVICE %d, Dribble bits\n",
                  pCS->unit, 0,0,0,0,0 );
            }
         }
#endif
      

      /* Skip this error frame */
      csReadPacketPage( pCS, PKTPG_RX_LENGTH );
      csWritePacketPage( pCS, PKTPG_RX_CFG,
                         csReadPacketPage(pCS,PKTPG_RX_CFG) | RX_CFG_SKIP );

      return;
   }

   /* Get a receive frame buffer */
     pData = netClusterGet(pCS->end.pNetPool, pCS->pClPoolId);

    /* Grab a cluster block to marry to the cluster we received. */

    pClBlk = netClBlkGet (pCS->end.pNetPool, M_DONTWAIT);

           
    /*
     * OK we've got a spare, let's get an M_BLK_ID and marry it to the
     * one in the ring.
     */

    pMblk = mBlkGet (pCS->end.pNetPool, M_DONTWAIT, MT_DATA);
 
   if ( pData == NULL || pClBlk == NULL || pMblk == NULL)  /* If no buffer available */
   {
           if (pData) {
        netClFree (pCS->end.pNetPool, pData);
       }

                if (pClBlk) {
        netClBlkFree (pCS->end.pNetPool, pClBlk); 
        }

        if ( pMblk ) {
        netMblkFree (pCS->end.pNetPool, pMblk);
                }

      /* Increment the input error count */
      /*pIf->if_ierrors++;*/
      END_ERR_ADD (&pCS->end, MIB2_IN_ERRS, +1);
 
      LOGMSG("csReceiveEvent(): unit=%d, No receive buffer available!\n",
         pCS->unit, 0,0,0,0,0 );


      /* Must read the length of all received frames */
      csReadPacketPage( pCS, PKTPG_RX_LENGTH );

      /* Skip the received frame */
      csWritePacketPage( pCS, PKTPG_RX_CFG,
            csReadPacketPage(pCS,PKTPG_RX_CFG) | RX_CFG_SKIP );
      return;
   }


   /* Copy the received frame from the chip to the buffer */
   /* Set offset 2 to the receiving buffer pointer so that the IP heater starts the
      17th bytes for 32-bits alignment*/
   DataLen=csCopyRxFrame( pCS, pData+2);

    /* Join the cluster to the MBlock */

    netClBlkJoin (pClBlk, pData, DataLen, NULL, 0, 0, 0);
    netMblkClJoin (pMblk, pClBlk);

   /* Set offset 2 to the receiving buffer pointer so that the IP heater starts the
      17th bytes for 32-bits alignment*/
    /*pMblk->mBlkHdr.mData += pDrvCtrl->offset;*/
    pMblk->mBlkHdr.mData += 2;
    pMblk->mBlkHdr.mLen = DataLen;
    pMblk->mBlkHdr.mFlags |= M_PKTHDR;
    pMblk->mBlkPktHdr.len = DataLen;

   /* Queue a pointer to the buffer to be processed at task level */
   csEnqueue( pCS->pRxBuffProcessList, pMblk );
}



/*******************************************************************************
* csEventHandler -
*
* This routine runs at the task level to processes RX frames and frees TX'd 
* mbuf chains queued at the ISR level.  Up to two instances of this
* routine may be queued to tNetTask to prevent a race condition between final
* checking of a queue here and an enqueue at the ISR level.  A netJob
* "counter" is decremented each time this routine starts.
*
* RETURNS: Nothing.
*
*/

LOCAL void csEventHandler( CS_END_DEVICE *pCS )
{
   void  *pBuff;

   if( pCS->NetJobDepth > 0 ) 
       pCS->NetJobDepth--;
      
   while( !csQueueEmpty( pCS->pRxBuffProcessList ) )
   {
      /* Process an RX frame */  
      pBuff = csDequeue( pCS->pRxBuffProcessList );
      csProcessReceive( pCS, pBuff ); 
   }

   while( !csQueueEmpty( pCS->pTxBuffFreeList ) )
   {
      /* Free up the TX'd mbuf chains */
      pBuff = csDequeue( pCS->pTxBuffFreeList );    
      netMblkClChainFree (pBuff);
   }
}






/* ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ *
 * Transmit-releated Routines                                              *
 * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ */



/*******************************************************************************
*
* csStartOutput -
*
* This routine is called to start the transmission of the packet at the head
* of the transmit queue.  This routine is called by the ether_output() routine
* when a new packet is added to the transmit queue. 
*
* RETURNS: Nothing
*
*/

LOCAL void csStartOutput( CS_END_DEVICE *pCS,  M_BLK_ID pMBuf)
{
   BOOL  QError;

   END_TX_SEM_TAKE(&pCS->end, WAIT_FOREVER);
   QError = csEnqueue( pCS->pTxQueue, pMBuf );
   END_TX_SEM_GIVE(&pCS->end);
     
   if ( QError )
   {
      /* TxQueue is full -- dump the frame and exit loop */             
      netMblkClChainFree (pMBuf);
      /* Update output stats */
      END_ERR_ADD (&pCS->end, MIB2_OUT_ERRS, +1);
      LOGMSG("csStartOutput: CS_END_DEVICE %d, Transmit queue overflow\n",
              pCS->unit, 0,0,0,0,0 );
   }

#ifdef CS_DEBUG_ENABLE
   pCS->TxQueueDepth++;
   if ( pCS->TxQueueDepth > pCS->MaxTxQueueDepth )
             pCS->MaxTxQueueDepth = pCS->TxQueueDepth;
#endif

   /* Update output stats */
   END_ERR_ADD (&pCS->end, MIB2_OUT_UCAST, +1);

   /* Transmit another frame if a TX is not currently in progress */
   if ( !pCS->TxInProgress ) 
   {
      csTxNextFrame( pCS );
   }
}



/*******************************************************************************
* csTxNextFrame -
*
* This routine start the TX of the next frame in the local TX send queue.
* If an error occurs, the output error count is incremented and the mbuf chain
* is freed, either by immediately calling mfree_m() if we are at task level, 
* or queueing the mbuf chain for release at the task level if we are currently
* at the ISR level.
*
* RETURNS: Nothing
*
*/

LOCAL void csTxNextFrame ( CS_END_DEVICE *pCS )
{
USHORT BusStatus;
M_BLK_ID  pMbuf;

   /* Transmit the next frame in the local TxQueue */
   while( !csQueueEmpty( pCS->pTxQueue ) )
   {
#ifdef CS_DEBUG_ENABLE
      pCS->TxQueueDepth--;
#endif

      pCS->pTxFrameChain = csDequeue( pCS->pTxQueue );
         
      /* Find the total length of the data to transmit */
      pCS->TxLength = 0;
      for ( pMbuf = pCS->pTxFrameChain; pMbuf!=NULL; pMbuf=pMbuf->mBlkHdr.mNext )
      {
         pCS->TxLength += pMbuf->mBlkHdr.mLen;
      }

      /* Bid for space on the chip and start the TX if bid successful */
      if ( pCS->InMemoryMode )
      {
             csWritePacketPage( pCS, PKTPG_TX_CMD, pCS->TxStartCMD );
             csWritePacketPage( pCS, PKTPG_TX_LENGTH, BYTE_SWAP(pCS->TxLength) );
      }
      else  /* In IO mode */
      {
             SYS_ENET_OUT_WORD( (pCS->IOAddr)+PORT_TX_CMD, pCS->TxStartCMD );
             SYS_ENET_OUT_WORD( (pCS->IOAddr)+PORT_TX_LENGTH, 
                                 BYTE_SWAP(pCS->TxLength));
      }

      /* Read BusStatus register which indicates success of the request */
      BusStatus = csReadPacketPage( pCS, PKTPG_BUS_ST );

      if ( BusStatus & BUS_ST_RDY4TXNOW )
      {
         /* The chip is ready for transmission now */
         /* Copy the frame to the chip to start transmission */
         csCopyTxFrame( pCS, pCS->pTxFrameChain );

         /* Mark TX as in progress */
         pCS->TxInProgress = TRUE;
         /* Transmission now in progress */
         break;
      }
      else /* Not ready for TX */
      {

         /* If there was an error in the transmit bid */
         if ( BusStatus & BUS_ST_TX_BID_ERR )
         {
            /* Set TX not in progress */
            pMbuf = pCS->pTxFrameChain;
            pCS->pTxFrameChain = NULL;
            pCS->TxInProgress = FALSE;

            if ( !pCS->InISR )
            {
               /* Free the bad mbuf chain */      
               netMblkClChainFree (pMbuf);
            }
            else
            {
               /* queue the mbuf chain to be freed at task level */
               csEnqueue( pCS->pTxBuffFreeList, pMbuf );
            }

            /* Update output stats */
            END_ERR_ADD (&pCS->end, MIB2_OUT_ERRS, +1);
            /*   END_ERR_ADD (&pCS->end, MIB2_OUT_UCAST, -1);*/
            /* @kml         The definition of the MIB-II variable ifOutUcastPkts in Interface
               group from RFC 1158 is "The total  number of  packets that higher-level 
               protocols requested be transmitted to a subnetwork-unicast address, 
               INCLUDE those that were discarded or not sent."*/
            LOGMSG("csStartOutput: CS_END_DEVICE %d, Transmit bid error (too big)\n",
                       pCS->unit, 0,0,0,0,0 );

            /* Loop up to transmit the next chain */

         }
         else /* Not Rdy4Tx and Not Bid Error */
         {


            /* Start the TX on Rdy4Tx interrupt */
            /* TX buff space not available now. */

            /* Mark TX as in progress */
            pCS->TxInProgress = TRUE;

            /* Exit loop */
            break;
         }
      }
   }
}



/*******************************************************************************
*
* csCopyTxFrame -
*
* This routine copies the packet from a chain of mbufs to the chip.  When all
* the data has been copied, then the chip automatically begins transmitting
* the data.
*
* The reason why this "simple" copy routine is so long and complicated is
* because all reads and writes to the chip must be done as 16-bit words.
* If an mbuf has an odd number of bytes, then the last byte must be saved
* and combined with the first byte of the next mbuf.  Also, some processors,
* such as the MIPS do not allow word writes to non-word aligned addresses.
*
*/

LOCAL void csCopyTxFrame( CS_END_DEVICE *pCS, M_BLK_ID pMbufChain )
{
   M_BLK_ID pMbuf;
   FAST USHORT *pFrame;
   FAST USHORT *pBuff;
   FAST USHORT *pBuffLimit;
   IOADDR TxDataPort;
   UCHAR  *pStart;
   USHORT  Length;
   BOOL HaveExtraByte;
   union
   {
      UCHAR  byte[2];
      USHORT word;
   } Straddle;


   /* Initialize frame pointer and data port address */
   pFrame = pCS->pPacketPage;
   pFrame += (PKTPG_TX_FRAME/2);
   TxDataPort = pCS->IOAddr + PORT_RXTX_DATA;

   HaveExtraByte = FALSE;  /* Start out with no extra byte */

   /* Process the chain of mbufs */
   for ( pMbuf=pMbufChain; pMbuf!=NULL; pMbuf=pMbuf->mBlkHdr.mNext )
   {
      /* Setup starting pointer and length */
      pStart = pMbuf->mBlkHdr.mData;
      Length = pMbuf->mBlkHdr.mLen;

#if (CPU_FAMILY == MIPS || CPU_FAMILY == ARM )
      /* if the mbuf payload starts on an odd address boundary */
      if( (UINT32)pStart & 0x01 )
      {
         /* If there is an extra byte left over from the previous mbuf */
         if ( HaveExtraByte )
         {
            /* Add the first byte from this mbuf to make a word */
            Straddle.byte[1] = *pStart;
 
            /* Write the word which straddles the mbufs to the chip */
            if ( pCS->InMemoryMode )
            {
#if CPU_FAMILY == ARM 
               SYS_ENET_OUT_WORD(pFrame++, Straddle.word);
#else
               *pFrame++ = Straddle.word;
#endif
            }
            else
               SYS_ENET_OUT_WORD( TxDataPort, Straddle.word );
 
            /* Adjust starting pointer and length */
            pStart++;
            Length--;

            HaveExtraByte = FALSE;
         }
         else
         {
            while( Length>=2 )
            {
               /* fetch 16 bits, 8 bits at a time */
               Straddle.byte[0] = *(UCHAR *)pStart++;
               Straddle.byte[1] = *(UCHAR *)pStart++;
    
               /* Write the word which straddles the mbufs to the chip */
               if ( pCS->InMemoryMode )
               {
#if CPU_FAMILY == ARM 
               SYS_ENET_OUT_WORD(pFrame++, Straddle.word);
#else
               *pFrame++ = Straddle.word;
#endif
              }
               else
                  SYS_ENET_OUT_WORD( TxDataPort, Straddle.word );
    
               Length -= 2;
            }
         }
      }

#endif
      /* If there is an extra byte left over from the previous mbuf */
      if ( HaveExtraByte )
      {
         /* Add the first byte from this mbuf to make a word */
         Straddle.byte[1] = *pStart;

         /* Write the word which straddles the mbufs to the chip */
         if ( pCS->InMemoryMode )
         {
#if CPU_FAMILY == ARM 
               SYS_ENET_OUT_WORD(pFrame++, Straddle.word);
#else
               *pFrame++ = Straddle.word;
#endif
         }
         else
            SYS_ENET_OUT_WORD( TxDataPort, Straddle.word );
   
         /* Adjust starting pointer and length */
         pStart++;
         Length--;

#if (CPU_FAMILY == MIPS || CPU_FAMILY == ARM)
         while( Length>=2 )
         {
            /* fetch 16 bits, 8 bits at a time */
            Straddle.byte[0] = *(UCHAR *)pStart++;
            Straddle.byte[1] = *(UCHAR *)pStart++;
 
            /* Write the word which straddles the mbufs to the chip */
            if ( pCS->InMemoryMode )
            {
#if CPU_FAMILY == ARM 
               SYS_ENET_OUT_WORD(pFrame++, Straddle.word);
#else
               *pFrame++ = Straddle.word;
#endif
            }
            else
               SYS_ENET_OUT_WORD( TxDataPort, Straddle.word );

            Length -= 2;
         }
#endif
      }

      /* Point pBuff to the correct starting point */
      pBuff = (USHORT *)pStart;

      /* If there are odd bytes remaining in the mbuf */
      if ( Length & 1 )
      {
         HaveExtraByte = TRUE;

         /* Point pBuffLimit to the extra byte */
         pBuffLimit = (USHORT *)(pStart+Length-1);
      }
      else  /* There is an even number of bytes remaining */
      {
         HaveExtraByte = FALSE;

         /* Point pBuffLimit to just beyond the last word */
         pBuffLimit = (USHORT *)(pStart+Length);
      }

      /* Copy the words in the mbuf to the chip */
      if ( pCS->InMemoryMode )
      {
         while ( pBuff < pBuffLimit ) 
         {
#if CPU_FAMILY == ARM 
               SYS_ENET_OUT_WORD(pFrame++, *pBuff++);
#else
                         *pFrame++ = *pBuff++;
#endif
         }
      }
      else
      {
         while ( pBuff < pBuffLimit ) 
               SYS_ENET_OUT_WORD(TxDataPort, *pBuff++);
      }

      /* If there is an extra byte left over in this mbuf */
      if ( HaveExtraByte )
      {
         /* Save the extra byte for later */
         Straddle.byte[0] = *(UCHAR *)pBuff;
      }

   } /* end Process the chain of mbufs */

   /* If there is an extra byte left over from the last mbuf */
   if ( HaveExtraByte )
   {
      /* Add a zero byte to make a word */
      Straddle.byte[1] = 0;

      /* Write the last word to the chip */
      if ( pCS->InMemoryMode )
      {
#if CPU_FAMILY == ARM 
               SYS_ENET_OUT_WORD(pFrame++, Straddle.word);
#else
               *pFrame++ = Straddle.word;
#endif
      }
      else
         SYS_ENET_OUT_WORD( TxDataPort, Straddle.word );
   }
}






/* ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ *
 * Receive-related Routines                                                *
 * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ */


/*******************************************************************************
*
* csCopyRxFrame -
*
* This routine copies a received frame from the chip to a receive buffer.
*
*/

LOCAL int csCopyRxFrame( CS_END_DEVICE *pCS, char *pRxBuff )
{
   FAST USHORT *pFrame;
   FAST USHORT *pBuff;
   FAST USHORT *pBuffLimit;
   FAST int RxDataPort;
   USHORT RxLength, RxStatus;
   int test_int;

   /* Initialize the frame pointer and data port address */
   pFrame =  pCS->pPacketPage;
   pFrame += (PKTPG_RX_LENGTH/2);
   RxDataPort = pCS->IOAddr + PORT_RXTX_DATA;

   /* Get the length of the received frame */
   if ( pCS->InMemoryMode )
   {
#if CPU_FAMILY == ARM
      RxLength = SYS_ENET_IN_WORD(pFrame++);
#else
      RxLength = *pFrame++;
#endif
      RxLength = BYTE_SWAP( RxLength );
   }
   else  /* In IO mode */
   {
      RxStatus = SYS_ENET_IN_WORD( RxDataPort );  /* Discard RxStatus */
      RxLength = SYS_ENET_IN_WORD( RxDataPort );
      RxLength = BYTE_SWAP( RxLength );
   }


   /* Setup pointers to the buffer for copying */
   pBuff = (USHORT *)pRxBuff;
   test_int = (int) pBuff;
   if ((test_int % 2) != 0)
   {
      LOGMSG("receive buffer not on half word boundary: %x\n", (int)pBuff,0,0,0,0,0);
   }
   pBuffLimit  = pBuff;
   pBuffLimit += ((RxLength+1)/2);

   /* Copy the frame from the chip to the buffer */
   if ( pCS->InMemoryMode )
   {
      while ( pBuff < pBuffLimit ) 
#if CPU_FAMILY == ARM
         *pBuff++ = SYS_ENET_IN_WORD(pFrame++);
#else
         *pBuff++ = *pFrame++;
#endif
   }
   else
   {
      while ( pBuff < pBuffLimit ) 
         *pBuff++ = SYS_ENET_IN_WORD( RxDataPort );
   }

   return (RxLength);
}


/*******************************************************************************
*
* csProcessReceive -
*
* This routine processes a received packet.  The received packet was copied to
* a receive buffer at interrupt time and this routine processses the receive
* buffer at task time via netTask().
*
* The packet is copied to an mbuf chain.  The mbuf chain is then
* passed up to the protocol stack.
*
*/
LOCAL void csProcessReceive( CS_END_DEVICE *pCS, M_BLK_ID pMBuff )
{

   /* Spl = splnet( );*/
   
        /* Update the MIB2 Static */
    END_ERR_ADD (&pCS->end, MIB2_IN_UCAST, +1);

   /* Pass the mbuf chain up to the protocol stack */
    /* Call the upper layer's receive routine. */
    END_RCV_RTN_CALL(&pCS->end, pMBuff);
   /* splx( Spl ); */
}



/* ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ *
 * Misc. Routines                                                          *
 * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ */



/*******************************************************************************
* csInitQueue -
*
* Initializes an array-implemented circular queue.
*
* RETURNS: Nothing.
*
*/
LOCAL void csInitQueue( CIR_QUEUE *Q )
{
   Q->Head = Q->Tail = 0;
}



/*******************************************************************************
* csQueueEmpty -
*
* Checks the queue's status.
*
* RETURNS: TRUE if queue is empty, FALSE if queue is not empty.
*
*/

LOCAL BOOL csQueueEmpty( CIR_QUEUE *Q )
{
   if( Q->Head == Q->Tail )
      return TRUE;  /* Queue is empty */
   else
      return FALSE;
}




/*******************************************************************************
* csDequeue -
*
* This routine removes a pointer to a value from the end off an 
* array-implemented circular queue.  Assumes the queue is not empty.
*
* RETURNS: Pointer to the dequeued value.
*
*/
LOCAL void *csDequeue( CIR_QUEUE *Q )
{
   FAST void  *Element;

   Element = Q->Queue[Q->Head];
   Q->Head = (Q->Head == CS_QUEUE_SIZE) ? 0 : (Q->Head + 1);
   return Element;

}



/*******************************************************************************
* csEnqueue -
*
* This routine adds a pointer to a value to the front of an array-implmented
* circular queue.
*
* RETURNS: OK, or ERROR if the enqueue would cause a queue overflow.
*
*/
LOCAL STATUS csEnqueue( CIR_QUEUE *Q, void *pBuff )
{
   /* If queue is full return ERROR */
   if ( Q->Tail == ((Q->Head == 0) ? CS_QUEUE_SIZE : (Q->Head -1)) )
   {
      LOGMSG("csEnqueue: CS_END_DEVICE %d, Queue Overflow\n",
         0,0,0,0,0,0 );
      return ERROR;    /* Queue overflow */
   }

   /* Else, add data to the queue and return OK */
   Q->Queue[Q->Tail] = pBuff;
   Q->Tail = (Q->Tail == CS_QUEUE_SIZE) ? 0 : (Q->Tail + 1);

   return OK;
}



/*******************************************************************************
*
* csInitChip -
*
* This routine uses the instance global variables in the CS_END_DEVICE structure to
* initialize the CS8900.
*
*/

LOCAL void csInitChip( CS_END_DEVICE *pCS )
{
   PIA    pIA;
   USHORT RxCtl;
   int i;

   /* Configure the adapter for board-specific IO and media type support */
   sysEnetHWInit( pCS );

   /* Initialize the config and control registers */
   csWritePacketPage( pCS, PKTPG_RX_CFG, RX_CFG_ALL_IE );
   csWritePacketPage( pCS, PKTPG_RX_CTL,
         (RX_CTL_RX_OK_A|RX_CTL_IND_A|RX_CTL_BCAST_A|RX_CTL_MCAST_A));
   csWritePacketPage( pCS, PKTPG_TX_CFG, TX_CFG_ALL_IE );
   csWritePacketPage( pCS, PKTPG_BUF_CFG, BUF_CFG_ALL_IE ); 

   /* Put Ethernet address into the Individual Address register */
   pIA = (PIA)pCS->enetAddr;
   csWritePacketPage( pCS, PKTPG_IND_ADDR,   pIA->word[0] );
   csWritePacketPage( pCS, PKTPG_IND_ADDR+2, pIA->word[1] );
   csWritePacketPage( pCS, PKTPG_IND_ADDR+4, pIA->word[2] );

   /* Set the interrupt level in the chip */
   if ( pCS->IntLevel == 5 )
      csWritePacketPage( pCS, PKTPG_INT_NUM, BYTE_SWAP(3) );
   else
      csWritePacketPage( pCS, PKTPG_INT_NUM, BYTE_SWAP( (pCS->IntLevel)-10 ) );

   /* @kml If need to enable the promiscuous mode */
   if ( pCS->ConfigFlags & CFGFLG_PROMISC_MODE ) {
          RxCtl=csReadPacketPage(pCS,PKTPG_RX_CTL);
      RxCtl |= RX_CTL_PROM_A;
      csWritePacketPage( pCS, PKTPG_RX_CTL, RxCtl );
   } else {
    /* @kml Set up the multicast filter */
    for (i=0; i<4; i++) {
     csWritePacketPage(pCS,PKTPG_LOGIC_ADDRESS_FILTER+i*2, pCS->MulticastTable[i]);
        }
   }


   /* Enable reception and transmission of frames */
   csWritePacketPage( pCS, PKTPG_LINE_CTL,
   csReadPacketPage(pCS,PKTPG_LINE_CTL) | LINE_CTL_RX_ON | LINE_CTL_TX_ON );

   if ( pCS->ConfigFlags & CFGFLG_POLL_MODE ) {
    /*If Poll mode, disable interrupt at the chip */
       csWritePacketPage( pCS, PKTPG_BUS_CTL,
           csReadPacketPage(pCS,PKTPG_BUS_CTL) & ~BUS_CTL_INT_ENBL );
   } else {
     /*If Interrupt mode, Enable interrupt at the chip */
     csWritePacketPage( pCS, PKTPG_BUS_CTL,
                   csReadPacketPage(pCS,PKTPG_BUS_CTL) | BUS_CTL_INT_ENBL );
   }
}



/*******************************************************************************
*
* csResetChip -
*
* This routine resets the CS8900 chip.
*
*/

LOCAL STATUS csResetChip( CS_END_DEVICE *pCS )
{
   int y;
   int x;
   UCHAR dummyVal;

/* @kml Avoid "unused variables" warning when compiling */
   x=0;
   dummyVal=0;

#ifdef HARD_RESET
   /* Disable interrupts at the CPU so reset command is atomic */
   y = INT_LOCK();

   /* We are now resetting the chip */
   /* A spurious interrupt is generated by the chip when it is reset. */
   /* This variable informs the interrupt handler to ignore this interrupt. */
   pCS->Resetting = TRUE;

   /* Issue a reset command to the chip */
   csWritePacketPage( pCS, PKTPG_SELF_CTL, SELF_CTL_RESET );

   /* Re-enable interrupts at the CPU */
   INT_UNLOCK( y );

   /* If transmission was in progress, it is not now */
   pCS->TxInProgress = FALSE;
   pCS->pTxFrameChain = NULL;

   /* The chip is always in IO mode after a reset */
   pCS->InMemoryMode = FALSE;

   /* Initialize locale flag */
   pCS->InISR = FALSE;

   /* Delay for 125 micro-seconds (one eighth of a second) */
   taskDelay( sysClkRateGet()/8 );

   /* Transition SBHE to switch chip from 8-bit to 16-bit */
   dummyVal = SYS_ENET_IN_BYTE( (pCS->IOAddr)+PORT_PKTPG_PTR );
   dummyVal = SYS_ENET_IN_BYTE( (pCS->IOAddr)+PORT_PKTPG_PTR+1 );
   dummyVal = SYS_ENET_IN_BYTE( (pCS->IOAddr)+PORT_PKTPG_PTR );
   dummyVal = SYS_ENET_IN_BYTE( (pCS->IOAddr)+PORT_PKTPG_PTR+1 );

   /* If EEPROM present, wait up to 125 mSec for EEPROM not busy*/
   y = sysClkRateGet()/8;
   for ( x=0; x<y; x++ )
   {
      if( !(csReadPacketPage(pCS,PKTPG_SELF_ST)&SELF_ST_SI_BUSY) )
         break;
   }
   if ( x == y )
      return ERROR;

   /* Wait up to 125 mSec for initialization is become done */
   for ( x=0; x<y; x++ )
   {
      if ( csReadPacketPage(pCS,PKTPG_SELF_ST)&SELF_ST_INIT_DONE )
         break;
   }
   if ( x == y )
      return ERROR;

   /* Reset is no longer in progress */
   pCS->Resetting = FALSE;

   return OK;
#else
   /* Disable interrupts at the CPU so reset command is atomic */
   y = INT_LOCK();

   pCS->Resetting = TRUE;

   /* Disable RX and TX */
   csWritePacketPage(pCS,PKTPG_LINE_CTL, csReadPacketPage(pCS, PKTPG_LINE_CTL) & ~(LINE_CTL_RX_ON | LINE_CTL_TX_ON));

   /* @kml Disable interrupt at the chip to avoid no detection of 
           interrupts by OS when the chip restarts. */
   csWritePacketPage( pCS, PKTPG_BUS_CTL,
           csReadPacketPage(pCS,PKTPG_BUS_CTL) & ~BUS_CTL_INT_ENBL );

   /* issue some skip commands to clear out any incoming frames */
  csWritePacketPage(pCS,PKTPG_RX_CFG, csReadPacketPage(pCS, PKTPG_RX_CFG) | RX_CFG_SKIP);
  csWritePacketPage(pCS,PKTPG_RX_CFG, csReadPacketPage(pCS, PKTPG_RX_CFG) | RX_CFG_SKIP);
  csWritePacketPage(pCS,PKTPG_RX_CFG, csReadPacketPage(pCS, PKTPG_RX_CFG) | RX_CFG_SKIP);

   /* Re-enable interrupts at the CPU */
   INT_UNLOCK( y );

   /* If transmission was in progress, it is not now */
   pCS->TxInProgress = FALSE;
   pCS->pTxFrameChain = NULL;

   /* The chip is always in IO mode after a reset */
   pCS->InMemoryMode = FALSE;

   /* Initialize locale flag */
   pCS->InISR = FALSE;


   /* Reset is no longer in progress */
   pCS->Resetting = FALSE;

   return OK;

#endif
}

/******************************************************************************
*
* csConfig - reconfigure the interface under us.
*
* Reconfigure the interface setting promiscuous mode, and changing the
* multicast interface list.
*
* RETURNS: N/A.
*/

LOCAL void csConfig (
    CS_END_DEVICE *pCS        /* device to be re-configured */
    )
{

   /* Set promiscuous mode if it's asked for. */
   if (END_FLAGS_GET(&pCS->end) & IFF_PROMISC)
   {
           pCS->ConfigFlags |= CFGFLG_PROMISC_MODE;
           LOGMSG ("csConfig() Setting promiscuous mode on!\n", 0, 0, 0, 0, 0, 0);
   }
   else
   {
      pCS->ConfigFlags &= ~CFGFLG_PROMISC_MODE;
      LOGMSG ("csConfig() Setting promiscuous mode off!\n", 0, 0, 0, 0, 0, 0);
        
      /* Set up address filter for multicasting. */
      if (END_MULTI_LST_CNT(&pCS->end) > 0)
      {
         csAddrFilterSet (pCS);
      }
   }


   /*  shutdown device completely */
   /*  reset all device counters/pointers, etc. */
   csResetChip(pCS);

   csPurgeQs(pCS);

   /*initialise the hardware according to flags */
   csInitChip(pCS);

   return;
}


/*******************************************************************************
*
* csReadPacketPage -
*
* This routine reads a word from the PacketPage at the specified offset.
*
*/

LOCAL USHORT csReadPacketPage( CS_END_DEVICE *pCS, USHORT Offset )
{
unsigned long address;
unsigned short data;
unsigned short *tmp;


   address =  (pCS->IOAddr)+PORT_PKTPG_PTR;
   if ( pCS->InMemoryMode )
   {
      Offset /=2;  /* Adjust for Compiler weirdness(see next function) */
      tmp = pCS->pPacketPage;
      tmp += Offset;
#if CPU_FAMILY == ARM
      data = SYS_ENET_IN_WORD(tmp);
#else
      data = *tmp;
#endif
      return data;
   }
   else  /* In IO mode */
   {
      Offset = BYTE_SWAP( Offset );
      SYS_ENET_OUT_WORD(address, Offset );
      data = SYS_ENET_IN_WORD( (pCS->IOAddr)+PORT_PKTPG_DATA );
      return data;
   }
}


/*******************************************************************************
*
* csWritePacketPage -
*                                                                                                                             *
* This routine writes a value to the PacketPage at the specified offset.
* 
* The offset is byte swapped if needed before writing to the PacketPage
* pointer.  The value is not byte swapped here. It must be byte swapped
* in the call to this function if byte swapping is required (it is not for 
* frame data).
*
*/

LOCAL void csWritePacketPage( CS_END_DEVICE *pCS, USHORT Offset, USHORT Value )
{
unsigned short *tmp;

   if ( pCS->InMemoryMode )
   {
      Offset /=2;  /* adjust for proper byte access
                   // Compiler treats this as an array index instead
                   // of a byte offset  */
      tmp =  pCS->pPacketPage;
      tmp += Offset;
#if CPU_FAMILY == ARM
      SYS_ENET_OUT_WORD(tmp, Value);
#else
	  *tmp=Value;
#endif
   }
   else  /* In IO mode */
   {
      Offset = BYTE_SWAP( Offset );
      SYS_ENET_OUT_WORD( (pCS->IOAddr)+PORT_PKTPG_PTR, Offset );
      SYS_ENET_OUT_WORD( (pCS->IOAddr)+PORT_PKTPG_DATA, Value );
   }
}



/*******************************************************************************
*
* csShow -
*
* This routine displays configuration and statistical information about the
* network interface driver.  This routine is usually invoked from the shell.
*/


void csShow(void)
{
USHORT RxMisses;
USHORT Collisions;
CS_END_DEVICE *pCS;
long flags;
M2_INTERFACETBL *pM2;

/* @Conexant Systems ARM 940 specific code */
/* unsigned short tmp;
*/
   pCS=&cs_end[0];
   /* Read the Rx Miss count. */
   RxMisses = csReadPacketPage( pCS, PKTPG_RX_MISS ); 
   RxMisses = (BYTE_SWAP( RxMisses )) >> 6; /* 6 LSBs are register number */

   /* Add the RX miss count to the input error counter */
   /* pIf->if_ierrors += RxMisses;*/
   END_ERR_ADD (&pCS->end, MIB2_IN_ERRS, RxMisses);

   /* Read the collision count.*/ 
   Collisions = csReadPacketPage( pCS, PKTPG_TX_COL ); 
   Collisions = (BYTE_SWAP( Collisions )) >> 6; /* 6 LSBs are register number*/ 

   /* Add the collision count to the collision counter. */ 
   pCS->Collisions += Collisions;

  
   printf("Show cs%d: ", pCS->unit );
   printf("Crystal Semiconductor CS8900 %s Driver Ver. %s\n",
           CS_BSP_TYPE, CS_DRIVER_VER);
   printf("\n");

   if ( pCS->ConfigFlags & CFGFLG_POLL_MODE )
   {
      printf("Poll Mode, Interrupt disabled.\n");
   }


   printf("I/O Address      : 0x%lX\n", (u_long)pCS->IOAddr );
   printf("Interrupt Level  : %d\n",   pCS->IntLevel );
   printf("Interrupt Vector : %d\n",   pCS->IntVector );

   printf("Access Mode      : ");
   if ( pCS->InMemoryMode )
   {
      printf("Memory Mode\n");
      printf("Memory Address   : 0x%lX\n", (u_long)pCS->pPacketPage );
   }
   else printf("I/O Mode\n");

   printf("TX Start Command : 0x%04X\n",pCS->TxStartCMD );

   printf("Media Type       : ");
   switch ( pCS->MediaType )
   {
      case MEDIA_AUI:
         printf("AUI\n");
         break;
      case MEDIA_10BASE2:
         printf("10Base2\n");
         break;
      case MEDIA_10BASET:
         if ( pCS->ConfigFlags & CFGFLG_FDX )
            printf("10BaseT, FDX\n");
         else
            printf("10BaseT\n");
         break;
      default:
         printf("Unknown\n");
         break;
   }

   printf("Interface Flags  : ");
   flags=END_FLAGS_GET(&pCS->end);
   if ( flags & IFF_UP ) printf("UP"); else printf("DOWN");
   if ( flags & IFF_RUNNING )     printf(", RUNNING");
   if ( flags & IFF_BROADCAST )   printf(", BROADCAST");
   if ( flags & IFF_LOOPBACK )    printf(", LOOPBACK");
   if ( flags & IFF_POINTOPOINT ) printf(", POINTOPOINT");
   if ( flags & IFF_NOTRAILERS )  printf(", NOTRAILERS");
   if ( flags & IFF_NOARP )       printf(", NOARP");
   if ( flags & IFF_PROMISC )     printf(", PROMISC");
   if ( flags & IFF_ALLMULTI )    printf(", ALLMULTI");
   printf("\n");

   pM2=&(pCS->end.mib2Tbl);
   printf("Input Packets    : %u\n", (unsigned int)pM2->ifInUcastPkts );
   printf("Output Packets   : %u\n", (unsigned int)pM2->ifOutUcastPkts );
   printf("Input Errors     : %u\n", (unsigned int)pM2->ifInErrors  );
   printf("Output Errors    : %u\n", (unsigned int)pM2->ifOutErrors  );
   printf("Collisions       : %d\n", pCS->Collisions );
   printf("Tx Underruns     : %d\n", pCS->TotalTxUnderruns );
   printf("Rdy4TX Int Count : %d\n", pCS->Rdy4TxInts );
   printf("Maximum Tx Depth : %d\n", pCS->MaxTxDepth );
   
   /* printf("Current Tx Depth : %d\n", pIf->if_snd.ifq_len );*/
   /* printf("Current Rx Depth : %d\n", pCS->RxDepth ); @kml*/
   /* printf("Maximum Rx Depth : %d\n", pCS->MaxRxDepth );*/
   /*printf("Loan Count       : %d\n", pCS->LoanCount );*/

#ifdef CS_DEBUG_ENABLE
   printf("Current TXQ Depth: %d\n", pCS->TxQueueDepth );
   printf("Max TXQ Depth    : %d\n", pCS->MaxTxQueueDepth );

   /* @Conexant Systems ARM 940 specific code */
/* tmp = SYS_ENET_IN_WORD(0x31400128);
   printf("TX Event Reg     : %4.4x\n", tmp);
   if (tmp == 0x108)
   {
      printf("in isr:    %d\n", pCS->InISR);
      printf("TX active: %d\n", pCS->TxInProgress);
   }
   tmp = SYS_ENET_IN_WORD(0x31400106);
   printf("TX CFG Reg       : %4.4x\n", tmp);
   */
#endif
   
   printf("\n");
}



#ifdef CS_DEBUG_ENABLE

STATUS csHistoryInit( void )
{

  /* initialize history */
  csHistoryIndex = 0;
  bzero( (char *)&csHistory, sizeof(csHistory) );

  return(OK);
}



STATUS csHistoryShow( void )
{
  int i;

  if( csHistoryIndex == 0 )
    return(OK);

  for( i=(csHistoryIndex-1); i>=0; i-- )
  {
    printf("%d %08X %08X %08X %08X\n", 
      i,
      csHistory[i].arg1,
      csHistory[i].arg2,
      csHistory[i].arg3,
      csHistory[i].arg4 );
  }

  return(OK);
}
    
    
STATUS csHistoryAdd( UINT32 arg1, UINT32 arg2, UINT32 arg3, UINT32 arg4 )
{

  if( csHistoryIndex < CS_HISTORY_SIZE )
  {
      csHistory[ csHistoryIndex ].arg1 = arg1;
      csHistory[ csHistoryIndex ].arg2 = arg2;
      csHistory[ csHistoryIndex ].arg3 = arg3;
      csHistory[ csHistoryIndex ].arg4 = arg4;

      csHistoryIndex++;
  }

  return(OK);
}

#endif /* CS_DEBUG_ENABLE */

/*******************************************************************************
*
* csPollRcv - routine to receive a packet in polled mode.
*
* This routine is called by a user to try and get a packet from the
* device.
*
* RETURNS: OK upon success.  EAGAIN is returned when no packet is available.
*/

LOCAL STATUS csPollRcv
    (
    END_OBJ *pV,        /* device to be polled */
    M_BLK_ID pMblk                /* ptr to buffer, provided by the calling upper layer. */
    )
    {
    USHORT stat;
    int len;
    CS_END_DEVICE *pCS;
        pCS=(CS_END_DEVICE *)pV;
         
    while ( 1 )
    {
        /* Read the RX_EVENT register */
        stat=csReadPacketPage(pCS, PKTPG_RX_EVENT);

        /* 7FC0=0111,1111,1100,0000, any bit set in the pattern=>frame received */
        if ( (stat&0x7FC0) == 0)
        {
           /*  If no packet is available return immediately */
           LOGMSG("csPollRcv() No data\n", 0, 0, 0, 0, 0, 0);
           return (EAGAIN);
        }

        /* If the frame was not received OK */
        if ( !(stat & RX_EVENT_RX_OK) )
        {
           /* Increment the input error count */
           /*pIf->if_ierrors++; @kml */
           END_ERR_ADD (&pCS->end, MIB2_IN_ERRS, +1);
 
           /* Skip this error frame */
           csReadPacketPage( pCS, PKTPG_RX_LENGTH );
           csWritePacketPage( pCS, PKTPG_RX_CFG,
           csReadPacketPage(pCS,PKTPG_RX_CFG) | RX_CFG_SKIP );

           /* read next frame */
           continue;
        }
        else
        {
           break;/* receive a good frame*/
        }
    }

    /* Upper layer must provide a valid buffer. */

    if ((pMblk->mBlkHdr.mLen < SIZEOF_ETHERHEADER+ETHERMTU) ||
                 (!(pMblk->mBlkHdr.mFlags & M_EXT)))
    {
        LOGMSG ("csPollRcv() Bad mblk!\n", 0, 0, 0, 0, 0, 6);
            return (EAGAIN);
    }

    /* Copy the received frame from the chip to the buffer */
    /* Set offset 2 to the receiving pointer so that the IP header starts from the 17th byte
      for 32-bits alignment. */
    len=csCopyRxFrame( pCS, pMblk->mBlkHdr.mData+2);

    pMblk->mBlkHdr.mData += 2;
    pMblk->mBlkHdr.mLen = len;
    pMblk->mBlkHdr.mFlags |= M_PKTHDR;
    pMblk->mBlkPktHdr.len = len;

    END_ERR_ADD (&pCS->end, MIB2_IN_UCAST, +1);

    return (OK);
}

/*******************************************************************************
*
* csPollSend - routine to send a packet in polled mode.
*
* This routine is called by a user to try and send a packet on the
* device.
*
* RETURNS: OK upon success.  EAGAIN if device is busy.
*/
LOCAL STATUS csPollSend (
    END_OBJ *pV,        /* device to be polled */
    M_BLK_ID pMblk                /* packet to send */
    )
{
M_BLK_ID pMbuf;        
int State = 0;
USHORT TxCmd;
USHORT BusStatus;
CS_END_DEVICE *pCS;

   pCS=(CS_END_DEVICE *)pV;

   /* test to see if tx is busy */  
   State = INT_LOCK( );
     
   /* Find the total length of the data to transmit */
   pCS->TxLength = 0;
   for ( pMbuf = pMblk; pMbuf!=NULL; pMbuf=pMbuf->mBlkHdr.mNext )
   {
      pCS->TxLength += pMbuf->mBlkHdr.mLen;
   }

   /*pCS->TxLength= pMblk->mBlkPktHdr.len;*/


  if (pCS->TxInProgress)
  {

      /* Previous BidForTX has reserved the buffer on CS8900, clear off it.*/
      TxCmd=pCS->TxStartCMD | TX_CMD_FORCE;

   }
   else
   {
      TxCmd=pCS->TxStartCMD ;
      pCS->TxInProgress=TRUE;
   }


   /* Bid for space on the chip and start the TX if bid successful */
   if ( pCS->InMemoryMode )
   {
      csWritePacketPage( pCS, PKTPG_TX_CMD, TxCmd);
      csWritePacketPage( pCS, PKTPG_TX_LENGTH, BYTE_SWAP(pCS->TxLength) );
   }
   else  /* In IO mode */
   {
      SYS_ENET_OUT_WORD((pCS->IOAddr)+PORT_TX_CMD, TxCmd );
      SYS_ENET_OUT_WORD((pCS->IOAddr)+PORT_TX_LENGTH, BYTE_SWAP(pCS->TxLength));
   }

   /* Read BusStatus register which indicates success of the request */
   BusStatus = csReadPacketPage( pCS, PKTPG_BUS_ST );

   if ( BusStatus & BUS_ST_RDY4TXNOW )
   {
             
       /* The chip is ready for transmission now */
       /* Copy the frame to the chip to start transmission */
       csCopyTxFrame( pCS, pMblk );
       INT_UNLOCK( State );
       pCS->TxInProgress = FALSE;

    }
    else
    { /* Chip is busy */
       INT_UNLOCK( State );
       END_ERR_ADD (&pCS->end, MIB2_OUT_ERRS, +1);
       return ((STATUS) EAGAIN);
    }


    /* Bump the statistic counter. */

    END_ERR_ADD (&pCS->end, MIB2_OUT_UCAST, +1);

    /* Free the data if it was accepted by device */

    netMblkClFree ( pMblk);

    return (OK);
}

/*****************************************************************************
*
* csMCastAdd - add a multicast address for the device
*
* This routine adds a multicast address to whatever the driver
* is already listening for.  It then resets the address filter.
*
* RETURNS: OK or ERROR.
*/

LOCAL STATUS csMCastAdd (
    END_OBJ *pV,        /* device pointer */
    char* pAddress                /* new address to add */
    )
{
int error;
unsigned char *pA;
CS_END_DEVICE *pCS;

   pCS=(CS_END_DEVICE *)pV;


   pA=(unsigned char *)pAddress;
   LOGMSG("csMCastAdd(): Add Ethernet Multicast Address: %02x.%02x.%02x.%02x.%02x.%02x \n",
           *pA,*(pA+1),*(pA+2),*(pA+3),*(pA+4),*(pA+5));

   if ((error = etherMultiAdd (&pCS->end.multiList,pAddress)) == ENETRESET)
        csConfig(pCS);

    return (OK);
}

/*****************************************************************************
*
* csMCastDel - delete a multicast address for the device
*
* This routine removes a multicast address from whatever the driver
* is listening for.  It then resets the address filter.
*
* RETURNS: OK or ERROR.
*/

LOCAL STATUS csMCastDel(
   END_OBJ *pV,        /* device pointer */
    char* pAddress                /* address to be deleted */
    )
{
int error;
unsigned char *pA;
CS_END_DEVICE *pCS;

   pCS=(CS_END_DEVICE *)pV;

   pA=(unsigned char *)pAddress;
   LOGMSG("csMCastDel(): Delete Ethernet Multicast Address: %02x.%02x.%02x.%02x.%02x.%02x \n",
           *pA,*(pA+1),*(pA+2),*(pA+3),*(pA+4),*(pA+5));

    if ((error = etherMultiDel (&pCS->end.multiList,(char *)pAddress)) == ENETRESET)
        csConfig(pCS);

    return (OK);
}

/*****************************************************************************
*
* csMCastGet - get the multicast address list for the device
*
* This routine gets the multicast list of whatever the driver
* is already listening for.
*
* RETURNS: OK or ERROR.
*/

LOCAL STATUS csMCastGet (
   END_OBJ *pV,        /* device pointer */
    MULTI_TABLE* pTable                /* address table to be filled in */
    )
{
CS_END_DEVICE *pCS;

   pCS=(CS_END_DEVICE *)pV;


   LOGMSG("csMCastGet(): Get Ethernet Multicast Addresses \n",0,0,0,0,0,0);

   return (etherMultiGet (&pCS->end.multiList, pTable));
}


/******************************************************************************
*
* csCalculateHashIndex()
*
******************************************************************************/

LOCAL USHORT csCalculateHashIndex( UCHAR *pMulticastAddr )
{
   UCHAR  HashIndex;
   UCHAR  AddrByte;
   int   Byte;
   int   Bit, j;

   /* Prime the CRC */
   for (j = 0; j < 32; j++ ) CRC[j] = 1;

   /* For each of the six bytes of the multicast address */
   for ( Byte=0; Byte<6; Byte++ )
   {
      AddrByte = *pMulticastAddr++;

      /* For each bit of the byte */
      for ( Bit=0; Bit<8; Bit++ )
      {
         updateCrc( (AddrByte >> Bit) & 1 );
      }
   }

   /* Take the least significant six bits of the CRC and copy them */
   /* to the HashIndex in reverse order.                           */
   HashIndex = 0;
   for( Bit=0,HashIndex=0; Bit<6; Bit++ )
   {
      HashIndex = (HashIndex << 1) + CRC[Bit];
   }

   return HashIndex;

} /* end of CalculateHashIndex() */


/***********************************************************************/
LOCAL void updateCrc( USHORT bit )
{
        int j;

   /* >> 1 the crc, use high bit (now CRC[32]) as control bit */
   for (j = 32; j > 0; j--) CRC[j] = CRC[j - 1];
   CRC[0] = 0;

   /* if bit ^ (control bit) = 1, set CRC = CRC ^ polynomial */
   if (bit ^ CRC[32])
   {
           for ( j = 0; j < 32; j++)
      {
         CRC[j] ^= CRC_Poly[j];
      }
   }
}


/******************************************************************************
*
* csAddrFilterSet - set the address filter for multicast addresses
*
* This routine goes through all of the multicast addresses on the list
* of addresses (added with the endAddrAdd() routine) and sets the
* device's filter correctly.
*
* RETURNS: N/A.
*/
LOCAL void csAddrFilterSet(
    CS_END_DEVICE *pCS        /* device to be updated */
    )
{
    ETHER_MULTI* pCurr;
        UCHAR HashIndex;
   
        /* initial to zeros */
    bzero( (char *) (&pCS->MulticastTable[0]), sizeof(pCS->MulticastTable));
    
        /*Get the first Mcast address from Mcast list */
    pCurr = END_MULTI_LST_FIRST (&pCS->end);

    while (pCurr != NULL)
        {
        /*  set up the multicast list */
                HashIndex=csCalculateHashIndex((UCHAR *)(pCurr->addr));
                (pCS->MulticastTable[ HashIndex/16])  |=  1 << (HashIndex%16);       
            pCurr = END_MULTI_LST_NEXT(pCurr);
        }
}

/*******************************************************************************
*
* csPollStart - start polled mode operations
*
* RETURNS: OK or ERROR.
*/

LOCAL STATUS csPollStart(
    END_OBJ *pV        /* device to be polled */
    )
{    
CS_END_DEVICE *pCS;

   pCS=(CS_END_DEVICE *)pV;

   pCS->ConfigFlags |= CFGFLG_POLL_MODE;

   csConfig (pCS);        /* reconfigure device */

   LOGMSG ("csPollStart() Poll Mode Started\n", 0, 0, 0, 0, 0, 0);
   
   return (OK);
}

/*******************************************************************************
*
* csPollStop - stop polled mode operations
*
* This function terminates polled mode operation.  The device returns to
* interrupt mode.
*
* The device interrupts are enabled, the current mode flag is switched
* to indicate interrupt mode and the device is then reconfigured for
* interrupt operation.
*
* RETURNS: OK or ERROR.
*/

LOCAL STATUS csPollStop(
    END_OBJ *pV        /* device to be changed */
    )
{
CS_END_DEVICE *pCS;

   pCS=(CS_END_DEVICE *)pV;

   /* oldLevel = intLock ();*/        /* disable ints during register updates */

   pCS->ConfigFlags &= ~CFGFLG_POLL_MODE;
  
   csConfig (pCS);


   LOGMSG ("csPollStop() Poll Mode Stopped\n",0, 0, 0,0, 0,0);

   return (OK);
}


/*****************************************************************************/
/* csPurgeQs: this routine purges all frames in the RX and TX side. */
/*****************************************************************************/

LOCAL void csPurgeQs(CS_END_DEVICE *pCS)
{
M_BLK_ID pBuff;

   while( !csQueueEmpty( pCS->pTxBuffFreeList ) )
   {
      /* Free up the TX'd mbuf chains */
      pBuff = csDequeue( pCS->pTxBuffFreeList );    
       netMblkClChainFree (pBuff);
   }

   while( !csQueueEmpty( pCS->pTxQueue ) )
   {
      /* Free up the TX'd mbuf chains */
      pBuff = csDequeue( pCS->pTxQueue );    
       netMblkClChainFree (pBuff);
   }

   if ( pCS->pTxFrameChain ) {
         netMblkClChainFree (pCS->pTxFrameChain );
   }

   pCS->TxQueueDepth=0;


      while( !csQueueEmpty( pCS->pRxBuffProcessList ) )
   {
      /* Free up the RX'd mbuf chains */
      pBuff = csDequeue( pCS->pRxBuffProcessList );    
      netMblkClChainFree (pBuff);
   }

}