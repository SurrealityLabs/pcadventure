/* configNet.h - Network configuration header file */

/* Copyright 1984-1997 Wind River Systems, Inc. */

/*
modification history
--------------------
01a,31mar98,cn   written.
*/

#ifndef INCconfigNeth
#define INCconfigNeth

#include "vxWorks.h"
#include "end.h"

/* @CS*/
/* 
#define FEI82557_LOAD_FUNC   fei82557EndLoad*/     /* driver external interface */
/* #define FEI82557_BUFF_LOAN   1   */                /* enable buffer loaning */

/*
 * The initialization string format is:
 *
 * <memBase>:<memSize>:<nCFDs>:<nRFDs>:<userFlags>
 */

/*
#define FEI82557_LOAD_STRING "-1:0x00:0x20:0x20:0x00"

IMPORT END_OBJ* FEI82557_LOAD_FUNC (char*, void*);

END_TBL_ENTRY endDevTbl [] =
{
   { 0, FEI82557_LOAD_FUNC, FEI82557_LOAD_STRING, FEI82557_BUFF_LOAN, NULL, FALSE},
   { 0, END_TBL_END, NULL, 0, NULL, FALSE},
};*/

/* @CS*/
/* Parmeters for loading the CS8900 Ethernet driver 
*
* The initialization string format for LOAD_STRING is:
*  "0xIOAddr:0xIntLevel:0xMemAddr:MediaType:0xConfigFlags"
*  
* where MediaType includes:
*     MEDIA_AUI           1           
*     MEDIA_10BASE2       2           
*     MEDIA_10BASET       3           
*/

#define CS_LOAD_FUNC csEndLoad
#define CS_LOAD_STRING "0x300:0xa:0x0:3:0x0"
IMPORT END_OBJ* CS_LOAD_FUNC(char*, void*);


END_TBL_ENTRY endDevTbl [] =
{
   { 0, CS_LOAD_FUNC, CS_LOAD_STRING, 1, NULL, FALSE},
   { 0, END_TBL_END, NULL, 0, NULL, FALSE},
};


#endif /* INCconfigNeth */

