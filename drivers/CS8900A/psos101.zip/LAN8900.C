/************************************************************************/
/*                                                                      */
/*   MODULE:     lan8900.c                                              */
/*   DATE:       5/7/96                                                 */
/*   PURPOSE:    Crystal Semiconductor CS8900 driver for pSOS/x86       */
/*   PROGRAMMER: Quentin Stephenson                                     */
/*                                                                      */
/*----------------------------------------------------------------------*/
/*                                                                      */
/*               Copyright 1996, Crystal Semiconductor Corp.            */
/*                      ALL RIGHTS RESERVED                             */
/*                                                                      */
/*                                                                      */
/************************************************************************/
/*                                                                      */
/*    Change Log:                                                       */
/*                9/15/99 James Ayres added support for the RDY4TXNow   */
/*                interrupt.  All changes marked with @jla              */
/************************************************************************/

#include "bsp.h"
#include "pna.h"
#include "lan8900.h"


#if (BSP_LAN1 == YES) && (BSP_LANCARD_MODEL == CS8900)


/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
/* Note on naming conventions used in this driver.                     */
/*                                                                     */
/* All routines and global variables in this driver start with a lower */
/* case "cs", which stands for Crystal Semiconductor.  This identifies */
/* these globally existing objects as belonging to this driver.        */
/*                                                                     */
/* All variables which contain an address instead of a value, start    */
/* with a lower case "p", which stands for pointer.  If a global       */
/* variable contains an address then it starts with "cs_p".            */
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */


/* External variables */

extern long PsosIsUp;


/* Prototypes of external routines */

extern unsigned long splhigh();
extern void splx( unsigned long IntState );
extern unsigned short inw( unsigned long Port );
extern unsigned char inb( unsigned long Port );
extern void outw( unsigned long Port, unsigned short Value );
extern void outb( unsigned long Port, unsigned char  Value );
extern void Set_Intr_Req( unsigned long IntNumber, void (* ISR)() );
extern void Enable_Intr_Req( unsigned long IntNumber );
extern void End_of_Intr( unsigned long IntNumber );
extern void Lan_Stub();
extern void Delay( unsigned long usec );


/* Prototypes of internal routines */

unsigned long csInitialize( struct niinit *pInitParms );
unsigned long csVerifyChip();
unsigned long csResetChip();
unsigned long csInitFromEEPROM();
int csReadEEPROM( unsigned short Offset, unsigned short *pValue );
unsigned long csInitFromBSPDefs();
char *csHexWord( char *pChar, unsigned short *pWord );
char *csHexByte( char *pChar, unsigned char *pByte );
unsigned long csInitInterrupt();
unsigned long csSend( PIA pDestAddr, struct nibrdcast *pSendParms );
unsigned short csRequestTransmit();
void csCopyTxFrame();
unsigned long csPoll();
unsigned long csIoctl( struct niioctl *pIoctlParms );
void csProcessISQ();
void csReceiveEvent( unsigned short RxEvent );
void csBufferEvent( unsigned short BufEvent );
void csTransmitEvent();
unsigned short csReadPacketPage( unsigned short Offset );
void csWritePacketPage( unsigned short Offset, unsigned short Value );
unsigned long csEnqueueTxReq( PIA pDestAddr, struct nibrdcast *pSendParms );
void csDequeueTxReq();


/* Global variables */

IA csBroadcastAddr;
IA csHardwareAddr;
unsigned short csIntNumber;
unsigned short *cs_pPacketPage;
int csInMemoryMode;
int csPsosIsInit;
long csNINumber;

long (*cs_pAnnounce_Packet)( unsigned long Type, mblk_t *pMsg,
      unsigned long Length, long NINumber, PIA SourceAddr, PIA DestAddr );
mblk_t *(*cs_p_allocb)( int Size, int Priority );
void (*cs_p_freemsg)( mblk_t *pMsg );

PTXREQ cs_pTxReqQueue;       /* Linked list of outstanding transmit requests */
PTXREQ cs_pTxFreeQueue;      /* Linked list of unused tx request structures */
TXREQ  csTxReq[MAXTXREQ];    /* Array of transmit request structures */

/* The transmit request at the head of the cs_pTxReqQueue is the request */
/* that is currently being transmitted.  If the cs_pTxReqQueue is empty  */
/* then there is not a transmission in progress. */


/*****************************************************************************/
/*  NiLan()                                                                  */
/*                                                                           */
/*  Network Interface Services Entry Point                                   */
/*  pNA calls this entry point to request services from this driver.         */
/*                                                                           */
/*****************************************************************************/

unsigned long NiLan( unsigned long FunctionCode, union nientry *pParms )
{
   /* If pSOS kernel is initialized then start using IENTER and */
   /* IRETURN calls in the interrupt handler stub (in isrstubs.386) */
   if ( csPsosIsInit ) PsosIsUp = TRUE;

   switch ( FunctionCode )
   {
      case NI_INIT:
         return csInitialize( &(pParms->niinit) );
         break;
      case NI_GETPKB:
         return FAILURE;
         break;
      case NI_RETPKB:
         return SUCCESS;
         break;
      case NI_SEND:
         return csSend( (PIA)(pParms->nisend.hwa_ptr),
               (struct nibrdcast *)&(pParms->nisend.buff_addr) );
         break;
      case NI_BROADCAST:
         return csSend( &csBroadcastAddr, &(pParms->nibrdcast) );
         break;
      case NI_POLL:
         return csPoll();
         break;
      case NI_IOCTL:
         return csIoctl( &(pParms->niioctl) );
         break;
      default:
         return FAILURE;
         break;
   }
}


/*****************************************************************************/
/*  csInitialize()                                                           */
/*                                                                           */
/*  This routine initializes the network interface driver.                   */
/*  If the driver is successfully initialized, then the address of the       */
/*  driver's hardware address is returned, else FAILURE is returned.         */
/*                                                                           */
/*****************************************************************************/

unsigned long csInitialize( struct niinit *pInitParms )
{
   int x;

   csInMemoryMode = FALSE;  /* Must start out using IO mode */
   csPsosIsInit = FALSE;    /* Assume pSOS kernel is not initialized */

    /* Verify that it is the correct chip */
    if ( csVerifyChip() == FAILURE )
       return FAILURE;

   /* Reset the chip */
   if ( csResetChip() == FAILURE )
      return FAILURE;

   #if (BSP_CS8900_EEPROM == YES)

     /* Initialize using data in the EEPROM */
     if ( csInitFromEEPROM() == FAILURE )
        return FAILURE;

   #else  /* BSP_CS8900_EEPROM == NO */

      /* Initialize using defines in the BSP.H file */
      if ( csInitFromBSPDefs() == FAILURE )
         return FAILURE;

   #endif  /* BSP_CS8900_EEPROM */

   /* Initialize the config and control registers */
   csWritePacketPage( PKTPG_RX_CFG, RX_CFG_RX_OK_IE );
   csWritePacketPage( PKTPG_RX_CTL, RX_CTL_RX_OK_A|RX_CTL_IND_A|RX_CTL_BCAST_A);
   csWritePacketPage( PKTPG_TX_CFG, TX_CFG_ALL_IE );
	// @jla added to support rdy4tx interrupt
   csWritePacketPage( PKTPG_BUF_CFG, BUF_CFG_RDY4TX_IE ); 

   /* Put hardware address into the Individual Address register */
   csWritePacketPage( PKTPG_IND_ADDR,   csHardwareAddr.word[0] );
   csWritePacketPage( PKTPG_IND_ADDR+2, csHardwareAddr.word[1] );
   csWritePacketPage( PKTPG_IND_ADDR+4, csHardwareAddr.word[2] );

   /* Set broadcast address to all F's */
   for ( x=0; x<BSP_LAN1_HWALEN/2; x++ )
      csBroadcastAddr.word[x] = 0xFFFF;

   /* Initialize the transmit request queue to empty */
   cs_pTxReqQueue = NULL;

   /* Put all the transmit requests on the free queue */
   cs_pTxFreeQueue = csTxReq;
   for ( x=0; x<MAXTXREQ-1; x++ )
      csTxReq[x].pNext = &csTxReq[x+1];
   csTxReq[MAXTXREQ-1].pNext = NULL;

   /* Save the passed-in parameters */
   csNINumber = pInitParms->if_num;
   cs_pAnnounce_Packet = pInitParms->ap_addr;
   cs_p_allocb = pInitParms->funcs->allocb;
   cs_p_freemsg = pInitParms->funcs->freemsg;
xxxxxxxxxxxxxxxxxxxx
   /* Initialize the interrupt */
   if ( csInitInterrupt() == FAILURE )
      return FAILURE;

   return (unsigned long)&csHardwareAddr;  /* Successfull initialization! */
}


/*****************************************************************************/
/*  csVerifyChip()                                                           */
/*                                                                           */
/*  This routine verifies that the Crystal Semiconductor chip is present     */
/*  and that it is a CS8900.                                                 */
/*                                                                           */
/*  IMPORTANT!  This routine will fail if the IO base address programmed     */
/*              in the chip's EEPROM does not match the IO base address      */
/*              specified with BSP_CS8900_IO_BASE in the BSP.H file.         */
/*                                                                           */
/*****************************************************************************/

unsigned long csVerifyChip()
{
   /* See if the PacketPage Pointer port contains the correct signature */
   if ( (inw(PORT_PKTPG_PTR)&SIGNATURE_PKTPG_PTR) != SIGNATURE_PKTPG_PTR )
      return FAILURE;

   /* Verify that the chip is a Crystal Semiconductor chip */
   if ( csReadPacketPage(PKTPG_EISA_NUM) != EISA_NUM_CRYSTAL )
      return FAILURE;

   /* Verify that the chip is a CS8900 */
   if ( (csReadPacketPage(PKTPG_PRODUCT_ID)&PROD_ID_MASK) != PROD_ID_CS8900 )
      return FAILURE;

   return SUCCESS;
}


/*****************************************************************************/
/*  csResetChip()                                                            */
/*                                                                           */
/*  This routine resets the chip and initializes it for 16-bit operation.    */
/*                                                                           */
/*****************************************************************************/

unsigned long csResetChip()
{
   int x;

   /* Issue a reset command to the chip */
   csWritePacketPage( PKTPG_SELF_CTL, SELF_CTL_RESET );

   /* Delay for 125 micro-seconds */
   Delay( 125 );

   /* Transition SBHE to switch chip from 8-bit to 16-bit */
   inb( PORT_PKTPG_PTR   );
   inb( PORT_PKTPG_PTR+1 );
   inb( PORT_PKTPG_PTR   );
   inb( PORT_PKTPG_PTR+1 );

   /* Wait until the EEPROM is not busy */
   for ( x=0; x<MAXLOOP; x++ )
      if ( !(csReadPacketPage(PKTPG_SELF_ST)&SELF_ST_SI_BUSY) )
         break;
   if ( x == MAXLOOP ) return FAILURE;

   /* Wait until initialization is done */
   for ( x=0; x<MAXLOOP; x++ )
      if ( csReadPacketPage(PKTPG_SELF_ST)&SELF_ST_INIT_DONE )
         break;
   if ( x == MAXLOOP ) return FAILURE;

   return SUCCESS;
}


#if (BSP_CS8900_EEPROM == YES)

/*****************************************************************************/
/*  csInitFromEEPROM()                                                       */
/*                                                                           */
/*  This routine initializes the chip using configuration information        */
/*  obtained from the EEPROM attached to the chip.  This routine also reads  */
/*  the interrupt level and hardware address from the EEPROM and saves them  */
/*  in the csHardwareAddr and csIntNumber global variables.                  */
/*                                                                           */
/*****************************************************************************/

unsigned long csInitFromEEPROM()
{
   unsigned short SelfStatus;
   unsigned short ISAConfig;
   unsigned short MemBase;
   unsigned short BusCtl;
   unsigned short AdapterConfig;
   unsigned short SelfCtl;
   unsigned short XmitCtl;

   /* Verify that the EEPROM is present and OK */
   SelfStatus = csReadPacketPage( PKTPG_SELF_ST );
   if ( !((SelfStatus & SELF_ST_EEP_PRES) && (SelfStatus & SELF_ST_EEP_OK)) )
      return FAILURE;

   /* Get ISA configuration from the EEPROM */
   if ( csReadEEPROM(EEPROM_ISA_CFG,&ISAConfig) == FAILURE )
      return FAILURE;

   /* If memory mode is enabled */
   if ( ISAConfig & ISA_CFG_MEM_MODE )
   {
      /* Get memory base address from EEPROM */
      if ( csReadEEPROM(EEPROM_MEM_BASE,&MemBase) == FAILURE )
         return FAILURE;

      MemBase &= MEM_BASE_MASK;  /* Clear unused bits */

      /* If external logic is present for address decoding */
      if ( csReadPacketPage(PKTPG_SELF_ST) & SELF_ST_EL_PRES )
      {
         /* Program the external logic to decode address bits SA20-SA23 */
         csWritePacketPage( PKTPG_EEPROM_CMD, (MemBase>>12) | EEPROM_CMD_ELSEL);
      }

      /* Setup chip for memory mode */
      csWritePacketPage( PKTPG_MEM_BASE,  (MemBase<<8) & 0xFFFF );
      csWritePacketPage( PKTPG_MEM_BASE+2, MemBase>>8 );
      BusCtl = BUS_CTL_MEM_MODE;
      if ( ISAConfig & ISA_CFG_USE_SA )
         BusCtl |= BUS_CTL_USE_SA;
      csWritePacketPage( PKTPG_BUS_CTL, BusCtl );

      /* Setup global variables for memory mode */
      cs_pPacketPage = (unsigned short *)(((unsigned long)MemBase)<<8);
      csInMemoryMode = TRUE;  /* We are in memory mode now! */
   }

   /* If IOCHRDY is enabled then clear the bit in the BusCtl register */
   BusCtl = csReadPacketPage( PKTPG_BUS_CTL );
   if ( ISAConfig & ISA_CFG_IOCHRDY )
      csWritePacketPage( PKTPG_BUS_CTL, BusCtl & ~BUS_CTL_IOCHRDY );
   else
      csWritePacketPage( PKTPG_BUS_CTL, BusCtl | BUS_CTL_IOCHRDY );

   /* Save the interrupt number to be initialized later */
   csIntNumber = ISAConfig & ISA_CFG_IRQ_MASK;
   if ( csIntNumber == 3 )
      csIntNumber = 5;
   else
      csIntNumber += 10;

   /* Get adapter configuration from the EEPROM */
   if ( csReadEEPROM(EEPROM_ADPTR_CFG,&AdapterConfig) == FAILURE )
      return FAILURE;

   /* Set the Line Control register to match the media type */
   if ( (AdapterConfig & ADPTR_CFG_MEDIA) == ADPTR_CFG_10BASET )
      csWritePacketPage( PKTPG_LINE_CTL, LINE_CTL_10BASET );
   else
      csWritePacketPage( PKTPG_LINE_CTL, LINE_CTL_AUI_ONLY );

   /* Set the BSTATUS/HC1 pin to be used as HC1 */
   /* HC1 is used to enable the DC/DC converter */
   SelfCtl = SELF_CTL_HC1E;

   /* If the media type is 10Base2 */
   if ( (AdapterConfig & ADPTR_CFG_MEDIA) == ADPTR_CFG_10BASE2 )
   {
      /* Enable the DC/DC converter */
      /* If the DC/DC converter has a low enable */
      if ( (AdapterConfig & ADPTR_CFG_DCDC_POL) == 0 )
         /* Set the HCB1 bit, which causes the HC1 pin to go low */
         SelfCtl |= SELF_CTL_HCB1;
   }
   else  /* Media type is 10BaseT or AUI */
   {
      /* Disable the DC/DC converter */
      /* If the DC/DC converter has a high enable */
      if ( (AdapterConfig & ADPTR_CFG_DCDC_POL) != 0 )
         /* Set the HCB1 bit, which causes the HC1 pin to go low */
         SelfCtl |= SELF_CTL_HCB1;
   }
   csWritePacketPage( PKTPG_SELF_CTL, SelfCtl );

   /* If media type is 10BaseT */
   if ( (AdapterConfig & ADPTR_CFG_MEDIA) == ADPTR_CFG_10BASET )
   {
      /* Get transmission control from the EEPROM */
      if ( csReadEEPROM(EEPROM_XMIT_CTL,&XmitCtl) == FAILURE )
         return FAILURE;

      /* If full duplex mode then set the FDX bit in TestCtl register */
      if ( XmitCtl & XMIT_CTL_FDX )
         csWritePacketPage( PKTPG_TEST_CTL, TEST_CTL_FDX );
   }

   /* Get Individual Address from the EEPROM */
   if ( csReadEEPROM(EEPROM_IND_ADDR_H,&csHardwareAddr.word[0]) == FAILURE )
      return FAILURE;
   if ( csReadEEPROM(EEPROM_IND_ADDR_M,&csHardwareAddr.word[1]) == FAILURE )
      return FAILURE;
   if ( csReadEEPROM(EEPROM_IND_ADDR_L,&csHardwareAddr.word[2]) == FAILURE )
      return FAILURE;

   return SUCCESS;
}


/*****************************************************************************/
/*  csReadEEPROM()                                                           */
/*                                                                           */
/*  Read the specified offset within the EEPROM.                             */
/*                                                                           */
/*****************************************************************************/

int csReadEEPROM( unsigned short Offset, unsigned short *pValue )
{
   int x;

   /* Ensure that the EEPROM is not busy */
   for ( x=0; x<MAXLOOP; x++ )
      if ( !(csReadPacketPage(PKTPG_SELF_ST)&SELF_ST_SI_BUSY) )
         break;
   if ( x == MAXLOOP ) return FAILURE;

   /* Issue the command to read the offset within the EEPROM */
   csWritePacketPage( PKTPG_EEPROM_CMD, Offset | EEPROM_CMD_READ );

   /* Wait until the command is completed */
   for ( x=0; x<MAXLOOP; x++ )
      if ( !(csReadPacketPage(PKTPG_SELF_ST)&SELF_ST_SI_BUSY) )
         break;
   if ( x == MAXLOOP ) return FAILURE;

   /* Get the EEPROM data from the EEPROM Data register */
   *pValue = csReadPacketPage( PKTPG_EEPROM_DATA );

   return SUCCESS;
}


#else  /* BSP_CS8900_EEPROM == NO */


/*****************************************************************************/
/*  csInitFromBSPDefs()                                                      */
/*                                                                           */
/*  This routine initializes the chip using definitions in the BSP.H file.   */
/*  This routine also converts the hardware address string specified by the  */
/*  BSP_CS8900_IND_ADDR definition and stores it in the csHardwareAddr       */
/*  global variable.  The defined interrupt level is stored in the           */
/*  csIntNumber global variable.                                             */
/*                                                                           */
/*****************************************************************************/

unsigned long csInitFromBSPDefs()
{
   unsigned short BusCtl;
   unsigned short SelfCtl;
   char *pChar;

   #if (BSP_CS8900_MEM_MODE == YES)

      /* If external logic is present for address decoding */
      if ( csReadPacketPage(PKTPG_SELF_ST) & SELF_ST_EL_PRES )
      {
         /* Program the external logic to decode address bits SA20-SA23 */
         csWritePacketPage( PKTPG_EEPROM_CMD,
               (BSP_CS8900_MEM_BASE>>20) | EEPROM_CMD_ELSEL );
      }

      /* Setup chip for memory mode */
      csWritePacketPage( PKTPG_MEM_BASE,   BSP_CS8900_MEM_BASE & 0xFFFF );
      csWritePacketPage( PKTPG_MEM_BASE+2, BSP_CS8900_MEM_BASE>>16 );
      BusCtl = BUS_CTL_MEM_MODE;
      #if (BSP_CS8900_USE_SA == YES)
         BusCtl |= BUS_CTL_USE_SA;
      #endif
      csWritePacketPage( PKTPG_BUS_CTL, BusCtl );

      /* Setup global variables for memory mode */
      cs_pPacketPage = (unsigned short *)BSP_CS8900_MEM_BASE;
      csInMemoryMode = TRUE;  /* We are in memory mode now! */

   #endif  /* BSP_CS8900_MEM_MODE */

   /* If IOCHRDY is enabled then clear the bit in the BusCtl register */
   BusCtl = csReadPacketPage( PKTPG_BUS_CTL );
   #if (BSP_CS8900_IOCHRDY == YES)
      csWritePacketPage( PKTPG_BUS_CTL, BusCtl & ~BUS_CTL_IOCHRDY );
   #else
      csWritePacketPage( PKTPG_BUS_CTL, BusCtl | BUS_CTL_IOCHRDY );
   #endif

   /* Save the interrupt number to be initialized later */
   csIntNumber = BSP_CS8900_IRQ;

   /* Set the Line Control register to match the media type */
   #if (BSP_CS8900_MEDIA_TYPE == TEN_BASE_T )
      csWritePacketPage( PKTPG_LINE_CTL, LINE_CTL_10BASET );
   #else
      csWritePacketPage( PKTPG_LINE_CTL, LINE_CTL_AUI_ONLY );
   #endif

   /* Set the BSTATUS/HC1 pin to be used as HC1 */
   /* HC1 is used to enable the DC/DC converter */
   SelfCtl = SELF_CTL_HC1E;

   /* If the media type is 10Base2 */
   #if (BSP_CS8900_MEDIA_TYPE == TEN_BASE_2 )
      /* Enable the DC/DC converter */
      /* If the DC/DC converter has a low enable */
      #if (BSP_CS8900_DCDC_POL == LOW)
         /* Set the HCB1 bit, which causes the HC1 pin to go low */
         SelfCtl |= SELF_CTL_HCB1;
      #endif
   #else  /* Media type is 10BaseT or AUI */
      /* Disable the DC/DC converter */
      /* If the DC/DC converter has a high enable */
      #if (BSP_CS8900_DCDC_POL == HIGH)
         /* Set the HCB1 bit, which causes the HC1 pin to go low */
         SelfCtl |= SELF_CTL_HCB1;
      #endif
   #endif  /* BSP_CS8900_MEDIA_TYPE */
   csWritePacketPage( PKTPG_SELF_CTL, SelfCtl );

   /* If media type is 10BaseT */
   #if (BSP_CS8900_MEDIA_TYPE == TEN_BASE_T )
      /* If full duplex mode then set the FDX bit in TestCtl register */
      #if (BSP_CS8900_FDX == YES )
         csWritePacketPage( PKTPG_TEST_CTL, TEST_CTL_FDX );
      #endif
   #endif

   /* Convert and save the Individual Address string */
   pChar = BSP_CS8900_IND_ADDR;
   pChar = csHexWord( pChar, &csHardwareAddr.word[0] );
   if ( pChar == NULL ) return FAILURE;
   pChar = csHexWord( pChar, &csHardwareAddr.word[1] );
   if ( pChar == NULL ) return FAILURE;
   pChar = csHexWord( pChar, &csHardwareAddr.word[2] );
   if ( pChar == NULL ) return FAILURE;

   return SUCCESS;
}


/*****************************************************************************/
/*  csHexWord()                                                              */
/*                                                                           */
/*  This routine converts a sequence of hex characters to the 16-bit value   */
/*  that they represent.  The address of the first hex character is passed   */
/*  in the pChar parameter and the address just beyond the last hex          */
/*  character is returned.  The 16-bit variable pointed to by the pWord      */
/*  parameter is updated with the converted 16-bit value.  If an error       */
/*  occurred then NULL is returned.                                          */
/*                                                                           */
/*****************************************************************************/

char *csHexWord( char *pChar, unsigned short *pWord )
{
   union
   {
      unsigned short word;
      unsigned char  byte[2];
   } Value;

   /* Get the value of the first hex byte */
   pChar = csHexByte( pChar, &Value.byte[0] );
   if ( pChar==NULL || *pChar==0 ) return NULL;

   /* Get the value of the second hex byte */
   pChar = csHexByte( pChar, &Value.byte[1] );
   if ( pChar==NULL ) return NULL;

   /* Save value of the hex word */
   *pWord = Value.word;

   return pChar;
}


/*****************************************************************************/
/*  csHexByte()                                                              */
/*                                                                           */
/*  This routine converts a sequence of hex characters to the 8-bit value    */
/*  that they represent.  There may be zero, one or two hex characters and   */
/*  they may be optionally terminated with a colon or a zero byte.           */
/*  The address of the first hex character is passed in the pChar parameter  */
/*  and the address just beyond the last hex character is returned.          */
/*  The 8-bit variable pointed to by the pByte parameter is updated with     */
/*  the converted 8-bit value.  If an error occurred then NULL is returned.  */
/*                                                                           */
/*****************************************************************************/

char *csHexByte( char *pChar, unsigned char *pByte )
{
   int x;

   /* Inititalize the byte value to zero */
   *pByte = 0;

   /* Process two hex characters */
   for ( x=0; x<2; x++,pChar++ )
   {
      /* Stop early if find a colon or end of string */
      if ( *pChar==':' || *pChar==0 ) break;

      /* Convert the hex character to a value */
      if ( *pChar >= '0' && *pChar <= '9' )
         *pByte = (*pByte * 16) + *pChar - '0';
      else if ( *pChar >= 'a' && *pChar <= 'f' )
         *pByte = (*pByte * 16) + *pChar - 'a' + 10;
      else if ( *pChar >= 'A' && *pChar <= 'F' )
         *pByte = (*pByte * 16) + *pChar - 'A' + 10;
      else return NULL;  /* Illegal character */
   }

   /* Skip past terminating colon */
   if ( *pChar == ':' ) pChar++;

   return pChar;
}

#endif  /* BSP_CS8900_EEPROM */


/*****************************************************************************/
/*  csInitInterrupt()                                                        */
/*                                                                           */
/*  This routine initializes the chip, interrupt descriptor table and the    */
/*  programmable interrupt controller for the interrupt level contained in   */
/*  in the csIntNumber global variable.                                      */
/*                                                                           */
/*  If the interrupt level is not valid then FAILURE is returned.            */
/*                                                                           */
/*****************************************************************************/

unsigned long csInitInterrupt()
{
   /* Verify that the interrupt number is vaild */
   if ( !(csIntNumber==5||csIntNumber==10||csIntNumber==11||csIntNumber==12) )
      return FAILURE;

   /* Set the interrupt number in the chip */
   if ( csIntNumber == 5 )
      csWritePacketPage( PKTPG_INT_NUM, 3 );
   else
      csWritePacketPage( PKTPG_INT_NUM, csIntNumber-10 );

   /* Setup the interrupt descriptor table */
   Set_Intr_Req( csIntNumber, Lan_Stub );

   /* Enable the interrupt at the PIC */
   Enable_Intr_Req( csIntNumber );

   /* Enable interrupt at the chip */
   csWritePacketPage( PKTPG_BUS_CTL,
         csReadPacketPage(PKTPG_BUS_CTL) | BUS_CTL_INT_ENBL );

   /* Enable reception and transmission of frames */
   csWritePacketPage( PKTPG_LINE_CTL,
         csReadPacketPage(PKTPG_LINE_CTL) | LINE_CTL_RX_ON | LINE_CTL_TX_ON );

   return SUCCESS;
}


/*****************************************************************************/
/*  csSend()                                                                 */
/*                                                                           */
/*  This routine is called when pNA requests that a new message (packet) be  */
/*  transmitted.  The new transmit request is placed on the transmit request */
/*  queue.  If a transmit request is not currently in progress, then the new */
/*  transmit request is started, else it waits its turn in the queue.        */
/*                                                                           */
/*****************************************************************************/

unsigned long csSend( PIA pDestAddr, struct nibrdcast *pSendParms )
{
   int TxInProgress;
   unsigned short BusStatus;
   unsigned long IntState;

   /* Disable interrupts at the CPU */
   IntState = splhigh();

   /* If the Transmit Request queue is empty then */
   /* there is no transmit in progress */
   if ( cs_pTxReqQueue == NULL )
      TxInProgress = FALSE;
   else
      TxInProgress = TRUE;

   /* Put this transmit request on the Transmit Request queue */
   if ( csEnqueueTxReq(pDestAddr,pSendParms) == FAILURE )
   {
      splx( IntState );
      return ENOBUFS;  /* Transmit request queue is full */
   }

   /* If a transmit request is not currently being transmitted */
   if ( !TxInProgress )
   {
      /* Request that a transmit be started */
      BusStatus = csRequestTransmit();

      /* If there was an error with the transmit bid */
      if ( BusStatus & BUS_ST_TX_BID_ERR )
      {
         /* Free the transmit request message */
         (*cs_p_freemsg)( cs_pTxReqQueue->pMsg );
         /* Remove the transmit request from the transmit request queue */
         csDequeueTxReq();
         splx( IntState );
         return EMSGSIZE;  /* Bad transmit length */
      }
      else if ( BusStatus & BUS_ST_RDY4TXNOW )
      {
         /* The chip is ready for transmission now */
         /* Copy the message to the chip to start the transmit */
         csCopyTxFrame();
         /* Free the transmit request message */
         (*cs_p_freemsg)( cs_pTxReqQueue->pMsg );
      }
   }

   /* Restore the interrupt state at the CPU */
   splx( IntState );

   return SUCCESS;
}


/*****************************************************************************/
/*  csRequestTransmit()                                                      */
/*                                                                           */
/*  This routine requests that a transmit be started by writing a transmit   */
/*  command and a frame length to the chip.  The contents of the BusStatus   */
/*  register is returned which indicates the success of the request.         */
/*                                                                           */
/*****************************************************************************/

unsigned short csRequestTransmit()
{
   /* Request that the transmit be started after all data has been copied */
   if ( csInMemoryMode )
   {
      csWritePacketPage( PKTPG_TX_CMD, TX_CMD_START_ALL );
      csWritePacketPage( PKTPG_TX_LENGTH, cs_pTxReqQueue->Length+HEADER_LENGTH);
   }
   else  /* In IO mode */
   {
      outw( PORT_TX_CMD, TX_CMD_START_ALL );
      outw( PORT_TX_LENGTH, cs_pTxReqQueue->Length+HEADER_LENGTH );
   }

   /* Return the BusStatus register which indicates success of the request */
   return csReadPacketPage( PKTPG_BUS_ST );
}


/*****************************************************************************/
/*  csCopyTxFrame()                                                          */
/*                                                                           */
/*  This routine builds an ethernet header in the chip's transmit frame      */
/*  buffer and then copies the frame data from the list of message blocks    */
/*  to the chip's transmit frame buffer.  When all the data has been copied  */
/*  then the chip automatically starts to transmit the frame.                */
/*                                                                           */
/*  The reason why this "simple" copy routine is so long and complicated is  */
/*  because all reads and writes to the chip must be done as 16-bit words.   */
/*  If a message block has an odd number of bytes, then the last byte must   */
/*  be saved and combined with the first byte of the next message block.     */
/*                                                                           */
/*****************************************************************************/

void csCopyTxFrame()
{
   unsigned short *pFrame;
   unsigned short *pBuff;
   unsigned short *pBuffLimit;
   unsigned char  *pStart;
   mblk_t *pMsg;
   int HaveExtraByte;
   union
   {
      unsigned char  byte[2];
      unsigned short word;
   } Straddle;

   /* Put the header into the frame buffer */
   if ( csInMemoryMode )
   {
      pFrame = cs_pPacketPage + (PKTPG_TX_FRAME/2);
      *pFrame++ = cs_pTxReqQueue->pDestAddr->word[0];
      *pFrame++ = cs_pTxReqQueue->pDestAddr->word[1];
      *pFrame++ = cs_pTxReqQueue->pDestAddr->word[2];
      *pFrame++ = csHardwareAddr.word[0];
      *pFrame++ = csHardwareAddr.word[1];
      *pFrame++ = csHardwareAddr.word[2];
      *pFrame++ = htons( cs_pTxReqQueue->Type );
   }
   else  /* In IO mode */
   {
      outw( PORT_RXTX_DATA, cs_pTxReqQueue->pDestAddr->word[0] );
      outw( PORT_RXTX_DATA, cs_pTxReqQueue->pDestAddr->word[1] );
      outw( PORT_RXTX_DATA, cs_pTxReqQueue->pDestAddr->word[2] );
      outw( PORT_RXTX_DATA, csHardwareAddr.word[0] );
      outw( PORT_RXTX_DATA, csHardwareAddr.word[1] );
      outw( PORT_RXTX_DATA, csHardwareAddr.word[2] );
      outw( PORT_RXTX_DATA, htons(cs_pTxReqQueue->Type) );
   }

   HaveExtraByte = FALSE;  /* Start out with no extra byte */

   /* Process the list of message blocks */
   for ( pMsg=cs_pTxReqQueue->pMsg; pMsg!=NULL; pMsg=pMsg->b_cont )
   {
      /* If there is an extra byte left over from the previous buffer */
      if ( HaveExtraByte )
      {
         /* Add the first byte from this buffer to make a word */
         Straddle.byte[1] = *pMsg->b_rptr;

         /* Save the word which straddles the buffers */
         if ( csInMemoryMode )
            *pFrame++ = Straddle.word;
         else
            outw( PORT_RXTX_DATA, Straddle.word );

         /* Start copying words from the second byte of this buffer */
         pStart = pMsg->b_rptr+1;
      }
      else pStart = pMsg->b_rptr;  /* Start copying from the first byte */

      /* Point pBuff to the correct starting point */
      pBuff = (unsigned short *)pStart;

      /* If there are odd bytes remaining in the buffer */
      if ( (pMsg->b_wptr - pStart) & 1 )
      {
         HaveExtraByte = TRUE;

         /* Point pBuffLimit to the extra byte */
         pBuffLimit = (unsigned short *)(pMsg->b_wptr-1);
      }
      else  /* There is an even number of bytes remaining */
      {
         HaveExtraByte = FALSE;

         /* Point pBuffLimit to just beyond the last word */
         pBuffLimit = (unsigned short *)pMsg->b_wptr;
      }

      /* Copy the words in the buffer to the frame */
      if ( csInMemoryMode )
         while ( pBuff < pBuffLimit ) *pFrame++ = *pBuff++;
      else
         while ( pBuff < pBuffLimit ) outw( PORT_RXTX_DATA, *pBuff++ );

      /* If there is an extra byte left over in this buffer */
      if ( HaveExtraByte )
         /* Save the extra byte for later */
         Straddle.byte[0] = *(unsigned char *)pBuff;
   }

   /* If there is an extra byte left over from the last buffer */
   if ( HaveExtraByte )
   {
      /* Add a zero byte to make a word */
      Straddle.byte[1] = 0;

      /* Save the last word */
      if ( csInMemoryMode )
         *pFrame = Straddle.word;
      else
         outw( PORT_RXTX_DATA, Straddle.word );
   }
}


/*****************************************************************************/
/*  csPoll()                                                                 */
/*                                                                           */
/*  If the driver's poll flag (0x8000) is set in BSP_LAN1_FLAGS, then this   */
/*  routine is called every 100ms by pNA.  This is done so that this driver  */
/*  can be used even if interrupts are not working.  Interrupts will not be  */
/*  working before the hardware startup code is executed.                    */
/*                                                                           */
/*  This routine does everything that the interrupt service routine          */
/*  (lan_isr()) does except issue an EOI.                                    */
/*                                                                           */
/*****************************************************************************/

unsigned long csPoll()
{
   unsigned long IntState;

   /* Disable interrupts at the CPU */
   IntState = splhigh();

   /* Process the Interrupt Status Queue */
   csProcessISQ();

   /* Restore the interrupt state at the CPU */
   splx( IntState );

   return SUCCESS;
}


/*****************************************************************************/
/*  csIoctl()                                                                */
/*                                                                           */
/*  The only ioctl that this driver processes is the one that informs the    */
/*  driver that the pSOS kernel in initialized.  This information is used    */
/*  by the interrupt service routine assembly language stub: Lan_Stub().     */
/*                                                                           */
/*****************************************************************************/

unsigned long csIoctl( struct niioctl *pIoctlParms )
{
   /* If Ioctl is notification that pSOS kernel is initialized */
   if ( pIoctlParms->cmd == SIOCPSOSINIT )
      PsosIsUp = csPsosIsInit = TRUE;

   return SUCCESS;
}


/*****************************************************************************/
/*  lan_isr()                                                                */
/*                                                                           */
/*  Network Interface Interrupt Service Routine                              */
/*                                                                           */
/*  This routine is called from the assembly language interrupt service      */
/*  routine stub (Lan_Stub() in isrstubs.386) whenever the chip generates    */
/*  an interrupt.  This routine calls csProcessISQ() which handles the       */
/*  interrupt event(s).                                                      */
/*                                                                           */
/*****************************************************************************/

void lan_isr()
{
   unsigned long IntState;

   /* Disable interrupts at the CPU */
   IntState = splhigh();

   /* Process the Interrupt Status Queue */
   csProcessISQ();

   /* Issue End-of-Interrupt command to the PIC */
   End_of_Intr( csIntNumber );

   /* Restore the interrupt state at the CPU */
   splx( IntState );
}


/*****************************************************************************/
/*  csProcessISQ()                                                           */
/*                                                                           */
/*  This routine processes the events on the Interrupt Status Queue.  The    */
/*  events are read one at a time from the ISQ and the appropriate event     */
/*  handlers are called.  The ISQ is read until it is empty.  If the chip's  */
/*  interrupt request line is active, then reading a zero from the ISQ will  */
/*  deactivate the interrupt request line.                                   */
/*                                                                           */
/*****************************************************************************/

void csProcessISQ()
{
   unsigned short Event;

   /* Read an event from the Interrupt Status Queue */
   if ( csInMemoryMode )
      Event = csReadPacketPage( PKTPG_ISQ );
   else
      Event = inw( PORT_ISQ );

   /* Process all the events in the Interrupt Status Queue */
   while ( Event != 0 )
   {
      /* Dispatch to an event handler based on the register number */
      switch ( Event & REG_NUM_MASK )
      {
         case REG_NUM_RX_EVENT:
            csReceiveEvent( Event );
            break;
         case REG_NUM_TX_EVENT:
            csTransmitEvent();
            break;
         case REG_NUM_BUF_EVENT:
		 // @jla add for rdy4txnow interrupt
		    csBufferEvent( Event );
         case REG_NUM_RX_MISS:
         case REG_NUM_TX_COL:
            /* Unused events */
            break;
      }

      /* Read another event from the Interrupt Status Queue */
      if ( csInMemoryMode )
         Event = csReadPacketPage( PKTPG_ISQ );
      else
         Event = inw( PORT_ISQ );
   }
}


/*****************************************************************************/
/*  csReceiveEvent()                                                         */
/*                                                                           */
/*  This routine is called whenever a frame has been received at the chip.   */
/*  This routine gets a data buffer from pNA, copies the received frame      */
/*  into the data buffer and passes the frame up to pNA by calling pNA's     */
/*  Announce_Packet() entry point.                                           */
/*                                                                           */
/*****************************************************************************/

void csReceiveEvent( unsigned short RxEvent )
{
   unsigned short *pFrame;
   unsigned short *pBuff;
   unsigned short *pBuffLimit;
   mblk_t *pMsg;
   unsigned short Length;
   unsigned short Type;
   IA SourceAddr, DestAddr;
   union
   {
      unsigned char  byte[2];
      unsigned short word;
   } Last;

   /* Verify that it is an RxOK event */
   if ( !(RxEvent & RX_EVENT_RX_OK) ) return;

   /* Read the header from the frame buffer */
   if ( csInMemoryMode )
   {
      pFrame = cs_pPacketPage + (PKTPG_RX_LENGTH/2);
      Length = *pFrame++ - HEADER_LENGTH;
      DestAddr.word[0]   = *pFrame++;
      DestAddr.word[1]   = *pFrame++;
      DestAddr.word[2]   = *pFrame++;
      SourceAddr.word[0] = *pFrame++;
      SourceAddr.word[1] = *pFrame++;
      SourceAddr.word[2] = *pFrame++;
      Type = *pFrame++;
   }
   else  /* In IO mode */
   {
      inw( PORT_RXTX_DATA );  /* Discard RxStatus */
      Length = inw( PORT_RXTX_DATA ) - HEADER_LENGTH;
      DestAddr.word[0]   = inw( PORT_RXTX_DATA );
      DestAddr.word[1]   = inw( PORT_RXTX_DATA );
      DestAddr.word[2]   = inw( PORT_RXTX_DATA );
      SourceAddr.word[0] = inw( PORT_RXTX_DATA );
      SourceAddr.word[1] = inw( PORT_RXTX_DATA );
      SourceAddr.word[2] = inw( PORT_RXTX_DATA );
      Type = inw( PORT_RXTX_DATA );
   }

   /* Swap the the bytes around for Intel CPU */
   Type = htons( Type );

   /* Verify that the frame type is acceptable */
   if ( !(Type==FRAME_TYPE_IP || Type==FRAME_TYPE_ARP) )
   {
      /* Discard the received frame */
      csWritePacketPage( PKTPG_RX_CFG,
            csReadPacketPage(PKTPG_RX_CFG) | RX_CFG_SKIP );
      return;
   }

   /* Allocate a data buffer from pNA */
   pMsg = (*cs_p_allocb)( Length, 0 );
   if ( pMsg == NULL )  /* If pNA doesn't have any more buffers */
   {
      /* Discard the received frame */
      csWritePacketPage( PKTPG_RX_CFG,
            csReadPacketPage(PKTPG_RX_CFG) | RX_CFG_SKIP );
      return;
   }

   /* Setup pointers to the buffer for copying */
   pBuff = (unsigned short *)pMsg->b_wptr;
   pBuffLimit = pBuff + (Length/2);

   /* Copy the frame from the chip to the pNA buffer */
   if ( csInMemoryMode )
      while ( pBuff < pBuffLimit ) *pBuff++ = *pFrame++;
   else
      while ( pBuff < pBuffLimit ) *pBuff++ = inw( PORT_RXTX_DATA );

   /* Update the message write pointer */
   pMsg->b_wptr = (unsigned char *)pBuff;

   /* If there is an extra byte at the end of the frame */
   if ( Length & 1 )
   {
      /* Read the byte as a word */
      if ( csInMemoryMode )
         Last.word = *pFrame;
      else
         Last.word = inw( PORT_RXTX_DATA );

      /* Write the byte as a byte */
      *(pMsg->b_wptr)++ = Last.byte[0];
   }

   /* Pass the received frame on up to pNA */
   csPsosIsInit = (*cs_pAnnounce_Packet)( Type, pMsg, Length, csNINumber,
         &SourceAddr, &DestAddr );
}


// @jla added this routine to send frame on rdy4tx interrupt
/*****************************************************************************/
/*  csBufferEvent()                                                         */
/*                                                                           */
/*  This routine is called whenever a buffer event has occurred.             */
/*  It only handles Rdy4TXNow events.  All other buffer events are ignored.  */
/*****************************************************************************/

void csBufferEvent( unsigned short BufEvent )
{

	if ( BufEvent & BUF_EVENT_RDY4TX )
	{
	    /* The chip is ready for transmission now */
	    /* Copy the message to the chip to start the transmit */
	    csCopyTxFrame();
	    /* Free the transmit request message */
	    (*cs_p_freemsg)( cs_pTxReqQueue->pMsg );
	}

}


/*****************************************************************************/
/*  csTransmitEvent()                                                        */
/*                                                                           */
/*  This routine is called whenever the transmission of a frame has          */
/*  completed (either successfully or unsuccessfully).  This routine         */
/*  removes the completed transmit request from the transmit request queue.  */
/*  If there are more transmit requests waiting, then start the transmission */
/*  of the next transmit request.                                            */
/*                                                                           */
/*****************************************************************************/

void csTransmitEvent()
{
   unsigned short BusStatus;

   /* Remove the completed transmit request from the transmit request queue */
   csDequeueTxReq();

   /* While there is still another transmit request to do */
   while ( cs_pTxReqQueue != NULL )
   {
      /* Request to start a new transmit */
      BusStatus = csRequestTransmit();

      /* If there was an error in the transmit bid */
      if ( BusStatus & BUS_ST_TX_BID_ERR )
      {
         /* Discard the bad transmit request */
         (*cs_p_freemsg)( cs_pTxReqQueue->pMsg );
         csDequeueTxReq();
         /* Loop up to do the next transmit request */
      }
      else if ( BusStatus & BUS_ST_RDY4TXNOW )
      {
         /* The chip is ready for transmit now */
         /* Copy the frame to the chip to start transmission */
         csCopyTxFrame();
         /* Free the message block */
         (*cs_p_freemsg)( cs_pTxReqQueue->pMsg );
         break;  /* Exit this routine */
      }
   }
}


/*****************************************************************************/
/*  csReadPacketPage()                                                       */
/*                                                                           */
/*  Reads the PacketPage register at the specified offset.                   */
/*                                                                           */
/*****************************************************************************/

unsigned short csReadPacketPage( unsigned short Offset )
{
   if ( csInMemoryMode )
   {
      return *(cs_pPacketPage+(Offset/2));
   }
   else  /* In IO mode */
   {
      outw( PORT_PKTPG_PTR, Offset );
      return inw( PORT_PKTPG_DATA );
   }
}


/*****************************************************************************/
/*  csWritePacketPage()                                                      */
/*                                                                           */
/*  Writes to the PacketPage register at the specified offset.               */
/*                                                                           */
/*****************************************************************************/

void csWritePacketPage( unsigned short Offset, unsigned short Value )
{
   if ( csInMemoryMode )
   {
      *(cs_pPacketPage+(Offset/2)) = Value;
   }
   else  /* In IO mode */
   {
      outw( PORT_PKTPG_PTR, Offset );
      outw( PORT_PKTPG_DATA, Value );
   }
}


/*****************************************************************************/
/*  csEnqueueTxReq()                                                         */
/*                                                                           */
/*  This routine places a transmit request at the end of the Transmit        */
/*  Request queue.                                                           */
/*                                                                           */
/*****************************************************************************/

unsigned long csEnqueueTxReq( PIA pDestAddr, struct nibrdcast *pSendParms )
{
   PTXREQ pTxReq;

   /* If there are no more transmit request structures available */
   if ( cs_pTxFreeQueue == NULL )
      return FAILURE;

   /* If the transmit request queue is empty */
   if ( cs_pTxReqQueue == NULL )
   {
      /* Move a transmit request structure from the head of the */
      /* free queue to the head of the request queue */
      pTxReq = cs_pTxReqQueue = cs_pTxFreeQueue;
      cs_pTxFreeQueue = cs_pTxFreeQueue->pNext;
   }
   else  /* Transmit request queue is not empty */
   {
      /* Move a transmit request structure from the head of the */
      /* free queue to the tail of the request queue */
      for ( pTxReq=cs_pTxReqQueue; pTxReq->pNext!=NULL; pTxReq=pTxReq->pNext );
      pTxReq->pNext = cs_pTxFreeQueue;
      cs_pTxFreeQueue = cs_pTxFreeQueue->pNext;
      pTxReq = pTxReq->pNext;
   }

   /* Fill in the new transmit request structure */
   pTxReq->pNext     = NULL;
   pTxReq->pDestAddr = pDestAddr;
   pTxReq->pMsg      = (mblk_t *)pSendParms->buff_addr;
   pTxReq->Length    = pSendParms->count;
   pTxReq->Type      = pSendParms->type;

   return SUCCESS;
}


/*****************************************************************************/
/*  csDequeueTxReq()                                                         */
/*                                                                           */
/*  This routine removes a transmit request from the head of the Transmit    */
/*  Request queue.                                                           */
/*                                                                           */
/*****************************************************************************/

void csDequeueTxReq()
{
   PTXREQ pTxReq;

   /* If the transmit request queue is not empty */
   if ( cs_pTxReqQueue != NULL )
   {
      /* Move the transmit request structure at the head of the */
      /* transmit queue to the head of the free queue */
      pTxReq = cs_pTxReqQueue;
      cs_pTxReqQueue = pTxReq->pNext;
      pTxReq->pNext = cs_pTxFreeQueue;
      cs_pTxFreeQueue = pTxReq;
   }
}


#endif /* (BSP_LAN1 == YES) && (BSP_LANCARD_MODEL == CS8900) */

