/* @(#) pSOSystem/386-210: bsps/pc/src/board.c 1.5 95/09/29 12:36:08 */
/***********************************************************************/
/*                                                                     */
/*   MODULE:  bsps/pc/src/board.c                                      */
/*   DATE:    95/09/29                                                   */
/*   PURPOSE: Board Initialization Code for the PC                     */
/*                                                                     */
/*---------------------------------------------------------------------*/
/*                                                                     */
/*          Copyright 1994, 1995, Integrated Systems, Inc.             */
/*                      ALL RIGHTS RESERVED                            */
/*                                                                     */
/*   Permission is hereby granted to licensees of pSOS+ to use or      */
/*   abstract the following computer program for the sole purpose of   */
/*   implementing their pSOS+ based software products.  No other       */
/*   rights to reproduce, use or disseminate this computer program,    */
/*   whether in part or in whole, are granted.                         */
/*                                                                     */
/*   Integrated Systems, Inc. makes no representation or               */
/*   warranties with respect to the performance of this computer       */
/*   program, and specifically disclaims any responsibility for any    */
/*   damages, special or consequential, connected with the use of      */
/*   this program.                                                     */
/*                                                                     */
/***********************************************************************/
#include "bsp.h"
#include "bspfuncs.h"

extern  void            outb();
extern struct idt_entry *get_idtbase();
extern struct gdt_entry *get_gdtbase();
extern int              get_gdtsize();
extern short            get_cs();

#define OCW1    0x21    /* port to 8259 interrupt controller */
#define OCW2    0xA1    /* port to 8259 interrupt controller */


char    *cfgmem;        /* defined in the linker command file */


/***********************************************************************/
/* Perform initializations required before starting pROBE. The         */
/* initializations done here are:                                      */
/*                                                                     */
/*   - set the clock to the desired interrupt rate                     */
/*                                                                     */
/***********************************************************************/

void
InitBoard(void)

{

        long    tickrate;



/***********************************************************************/
/* Set the interrupt frequency of the clock/timer chip to the desired  */
/* clock rate.                                                         */
/***********************************************************************/

        outb(0x43, 0x34);
        tickrate = 1193180L/BSP_TIMER_RATE;
        outb(0x40, (char)tickrate);
        outb(0x40, (char)(tickrate >> 8));


}


/***********************************************************************/
/*   Find a free GDT Selector.                                         */
/*                                                                     */
/*   Find_Free_Gdt_Selector();                                         */
/*                                                                     */
/*   Returns: First free selector, or zero if nore are free.           */
/*                                                                     */
/***********************************************************************/
int
Find_Free_Gdt_Selector()

{

        struct gdt_entry *gdtbase, *gdt_eptr;
        int              gdtsize, selector = 1;

        gdtbase = get_gdtbase();
        gdtsize = get_gdtsize();

        gdt_eptr = gdtbase + 1;

        while(gdtsize--) {
                if(!(gdt_eptr->type1 & 0x80))
                        break;
                gdt_eptr++;
                selector++;
        }

        if(gdtsize <= 0)
                return(0);

        return(selector << 3);

}


/***********************************************************************/
/*   Set up GDT Selector.                                              */
/*                                                                     */
/*   Set_Gdt_Selector(selector, addr);                                 */
/*                  selector = Selector value;                         */
/*                  addr     = Address of memory seg;                  */
/*                                                                     */
/***********************************************************************/
void
Set_Gdt_Selector(selector, base_off, length)

unsigned short selector;
unsigned long base_off, length;

{

        struct gdt_entry *gdtbase, *gdt_eptr;
        unsigned char    type2 = 0x40;

        if(--length >= 0x100000) {
                length /= 4096;
                type2 |= 0x80;
        }

        gdtbase = get_gdtbase();

        gdt_eptr = gdtbase + (selector >> 3);
        gdt_eptr->limit= length;
        gdt_eptr->lw_base = base_off;
        gdt_eptr->hw_lbase = (base_off >> 16);
        gdt_eptr->type1 = 0x93;
        gdt_eptr->type2 = (type2 | (length/0x10000));
        gdt_eptr->hw_hbase = (base_off >> 24);

}


void
Get_Gdt_Selector(selector, base_off, length, type1, type2)

unsigned short selector;
unsigned long *base_off, *length;
unsigned char *type1, *type2;

{

        struct gdt_entry *gdtbase, *gdt_eptr;

        gdtbase = get_gdtbase();

        gdt_eptr = gdtbase + (selector >> 3);
        *length = gdt_eptr->limit | ((gdt_eptr->type2 & 0xF) << 16);
        *base_off = gdt_eptr->lw_base | (gdt_eptr->hw_lbase << 16) | (gdt_eptr->hw_hbase << 24);

        *type1 = gdt_eptr->type1;
        *type2 = gdt_eptr->type2;

}



/***********************************************************************/
/*   Set up IDT vector.                                                */
/*                                                                     */
/*   Set_Idt_Vector(vecnum, addr, flag);                               */
/*                 vecnum = Vector number;                             */
/*                  addr  = Address of ISR;                            */
/*                  flag  = 0 - TRAP GATE, 1 - INTERRUPT GATE.         */
/*                                                                     */
/***********************************************************************/
void
Set_Idt_Vector(vecnum, addr, flag)

unsigned long vecnum, addr, flag;

{

        struct idt_entry *idtbase, *idt_eptr;

        idtbase = get_idtbase();

        idt_eptr = idtbase + vecnum;
        idt_eptr->lw_eip = addr;
        idt_eptr->cseg = get_cs();
        idt_eptr->hw_eip = (addr >> 16);
        idt_eptr->itype = (flag) ? 0x8E00 : 0x8F00;

}


/***********************************************************************/
/*   Init a GDT Selector.                                              */
/*                                                                     */
/*   Init_Gdt_Selector(gdtbase, selector, addr);                       */
/*                  gdtbase  = GDT table address                       */
/*                  selector = Selector value;                         */
/*                  addr     = Address of memory seg;                  */
/*                                                                     */
/***********************************************************************/
void
Init_Gdt_Selector(gdtbase, selector, base_off, length, type1, type2)

struct gdt_entry *gdtbase;
unsigned short selector;
unsigned long base_off, length;
unsigned char type1, type2;

{

        struct gdt_entry *gdt_eptr;

        if(--length >= 0x100000) {
                length /= 4096;
                type2 |= 0x80;
        }

        gdt_eptr = gdtbase + (selector >> 3);
        gdt_eptr->limit= length;
        gdt_eptr->lw_base = base_off;
        gdt_eptr->hw_lbase = (base_off >> 16);
        gdt_eptr->type1 = type1;
        gdt_eptr->type2 = (type2 | (length/0x10000));
        gdt_eptr->hw_hbase = (base_off >> 24);

}

/***********************************************************************/
/*   Init an IDT vector.                                               */
/*                                                                     */
/*   Init_Idt_Vector(idtbase, vecnum, addr, flag);                     */
/*                 idtbase= IDT base address                           */
/*                 vecnum = Vector number;                             */
/*                  addr  = Address of ISR;                            */
/*                  flag  = 0 - TRAP GATE, 1 - INTERRUPT GATE.         */
/*                                                                     */
/***********************************************************************/
void
Init_Idt_Vector(idtbase, vecnum, addr, flag)

struct idt_entry *idtbase;
unsigned long vecnum, addr, flag;

{

        struct idt_entry  *idt_eptr;


        idt_eptr = idtbase + vecnum;
        idt_eptr->lw_eip = addr;
        idt_eptr->cseg = get_cs();
        idt_eptr->hw_eip = (addr >> 16);
        idt_eptr->itype = (flag) ? 0x8E00 : 0x8F00;

}

/***********************************************************************/
/*   Set up IRQ vector.                                                */
/*                                                                     */
/*   Set_Intr_Req(irq, addr, flag);                                    */
/*                  irq_num = Interrupt Request number;                */
/*                  addr  = Address of ISR;                            */
/*                                                                     */
/***********************************************************************/
void
Set_Intr_Req(irq_num, addr)
unsigned long irq_num, addr;
{
        if(irq_num < 8)
                irq_num += PIC1_VBS;
        else
                irq_num += PIC2_VBS - 8;

        Set_Idt_Vector(irq_num, addr, 1);
}



/***********************************************************************/
/*   Enable interrupt on 8259 PIC                                      */
/*                                                                     */
/***********************************************************************/
void Enable_Intr_Req( unsigned long irq_num )
{
   long mask;

   if ( irq_num >= 8 )
      mask = 1 << (irq_num - 8);
   else
      mask = 1 << irq_num;

   mask = ~mask;

   if ( irq_num >= 8 )
   {
      /* Enable the second controller for irq_num */
      outb( OCW2, inb(OCW2) & mask );

      /* The second controller is connected to IRQ2 of the first */
      mask = ~0x4;
   }

   outb( OCW1, inb(OCW1) & mask );
}



/***********************************************************************/
/*   Issue End-of-Interrupt command to the 8259 PIC                    */
/*                                                                     */
/***********************************************************************/
void End_of_Intr( unsigned long irq_num )
{
   if ( irq_num >= 8 )
      outb( OCW2-1, BSP_EOI );

   outb( OCW1-1, BSP_EOI );
}


/***********************************************************************/
/*                                                                     */
/***********************************************************************/
static void
cpy(unsigned int n, char *from, char *to)

{

        while(n--)
                *to++ = *from++;

}


void
StorageRead(unsigned int nbytes, void *start, void *buff)

{

        unsigned long   tmp;


        cfgmem = (char *) 0x500;
        tmp = (unsigned long)cfgmem;
        tmp += (unsigned long)start;

        cpy(nbytes, (char *)tmp, (char *)buff);

}

void
StorageWrite(unsigned int nbytes, void *start, void *buff)

{

        unsigned long   tmp;


        cfgmem = (char *) 0x500;
        tmp = (unsigned long)cfgmem;
        tmp += (unsigned long)start;

        cpy(nbytes, (char *)buff, (char *)tmp);

}
