#include "loopback.h"

// The following is the basic flow of the loopback test program

/* This procedure assumes you are using 10B-T.  Use a "loopback" cable (see
the Q/A on loopback cable fabrication).  A regular 10B-T cable connected to
a hub will not work.

/* Configure RxCTL for Promiscious mode, RxOK */
/*(1) Write 0x0104 to IOBase+0xA (PacketPage Pointer)
(2) Write 0x0180h to IOBase+0xC (PacketPage Data Port)

/* Configure TestCTL (FDX, DisableLT) */
/*(3) Write 0x0118 to IOBase+0xA (PacketPage Pointer)
(4) Write 0x4080 to IOBase+0xC (PacketPage Data Port)

/* Set 10BaseT, SerRxOn, SerTxOn in LineCTL */
/*(5) Write 0x0112 to IOBase+0xA (PacketPage Pointer)
(6) Write 0x00C0 to IOBase+0xC (PacketPage Data Port)

/* Write the TX command */
/*(7) Write 00C0h to IOBase+0x4 (PacketPage Pointer)

/* Write the frame length  (XX = number of bytes to TX) */
/*(8) Write 00XXh to IOBase+0x6 (PacketPage Pointer)

/* Read BusST to verify it is set as 0x0118 (Rdy4TxNow is set) */
/*(9) Write 0x0138 to IOBase+0xA (PacketPage Pointer)
(10) Read IOBase+0xC  Should read 0x0118

/* Copy the TX frame to the on-chip buffer */
/*(11) Write XX/2 words to IOBase+0x0 (TX Data Port)

At this point frame should go out on the wire.

To read the TX'd frame:

/* Read RxEvent for RxOK (0x0104) */
/*(12) Write 0x0124 to IOBase+0xA (PacketPage Pointer)
(13) Read IOBase+0xC  Should read 0x0104 or 0x0504h

Read IOBase+0  This will be the RxStatus (RxEvent) word again.
Read IOBase+0 again.  This will be the RxLength (number of bytes received).
Read IOBase+0 (RxLength/2) times to read complete frame.

*/
/*------------------------------------------
Fabricating a "loopback" cable for testing
------------------------------------------

An easy way to fabricate a "loopback" cable for testing is to take a
PCB 10B-T connector and jumper each row of pins together as shown
in the diagram below.  Insert an ordinary 10B-T cable into the connector.
This will connect the TX pair to the RX pair for a loopback cable.

                    +----+----------+----+
                    |    |          |    |
                    |  o====o====o====o  |
                    |    |          |    |
                    |  o====o====o====o  |
                    |    |          |    |
                    |    +----------+    |
                    |                    |
                    \____________________/


                         Bottom View

*/


int main();
void reset();
int main()
{

	int i,j,receive_frame_size, temp;

   /* Initialize the part */

	/* Configure RxCTL for Promiscious mode, RxOK */
	/*(1) Write 0x0104 to IOBase+0xA (PacketPage Pointer)
	(2) Write 0x0180h to IOBase+0xC (PacketPage Data Port)

	/* Configure TestCTL (FDX, DisableLT, ENDEC loop ) */
	/*(3) Write 0x0118 to IOBase+0xA (PacketPage Pointer)
	(4) Write 0x4080 to IOBase+0xC (PacketPage Data Port)

	/* Set 10BaseT, SerRxOn, SerTxOn in LineCTL */
	/*(5) Write 0x0112 to IOBase+0xA (PacketPage Pointer)
	(6) Write 0x00C0 to IOBase+0xC (PacketPage Data Port)
	*/

   outport( (IO_BASE + PP_POINTER ), 0x0104 );
   outport( (IO_BASE + PP_DATA ), 0x0180 );
   outport( (IO_BASE + PP_POINTER ), 0x0118 );
   outport( (IO_BASE + PP_DATA ), 0x4280 );
   outport( (IO_BASE + PP_POINTER ), 0x0112 );
   outport( (IO_BASE + PP_DATA ), 0x00c0 );

   for (i = 0; i < NO_FRAMES_TO_SEND ; i++)
   {
      /* Write the TX command */
		/*(7) Write 00C0h to IOBase+0x4 (PacketPage Pointer)

		/* Write the frame length  (XX = number of bytes to TX) */
		/*(8) Write 00XXh to IOBase+0x6 (PacketPage Pointer)

		/* Read BusST to verify it is set as 0x0118 (Rdy4TxNow is set) */
		/*(9) Write 0x0138 to IOBase+0xA (PacketPage Pointer)
		(10) Read IOBase+0xC  Should read 0x0118
      */

      outport( (IO_BASE + TX_CMD ), 0x00c0 );
      outport( ( IO_BASE + TX_LENGTH ), SIZE_OF_FRAME * 2 ); // bid for bytes
      outport( (IO_BASE + PP_POINTER), 0x0138 );
      delay(25);
      if (inport( ( IO_BASE + PP_DATA ) ) !=  0x0118)
      {
      	printf("\n\n Bid for transmit failed");
      	exit(FAILURE);
      }

      /* Copy the TX frame to the on-chip buffer */
		/*(11) Write XX/2 words to IOBase+0x0 (TX Data Port) */

      for (j = 0; j < SIZE_OF_FRAME; j++)
      {
      	outport( IO_BASE , WORD_DATA );
      }

		/* To read the TX'd frame: */

		/* Read RxEvent for RxOK (0x0104) */
		/*(12) Write 0x0124 to IOBase+0xA (PacketPage Pointer)
		/* (13) Read IOBase+0xC  Should read 0x0104 or 0x0504h */

		/* Read IOBase+0  This will be the RxStatus (RxEvent) word again.
		Read IOBase+0 again.  This will be the RxLength (number of bytes received).
		Read IOBase+0 (RxLength/2) times to read complete frame. */

      delay( 25 );
      outport ( (IO_BASE + PP_POINTER), 0x0124);
      if ((temp = inport (IO_BASE + PP_DATA)) != 0x0104)
      {
      	printf("\n\n Frame not received");
         printf("\n%4.4x", temp);
         reset();
         exit( FAILURE );
      }

      // now read the base address, should be a repeat of the status
      if ( (temp = inport ( IO_BASE )) != 0x0104)
      {
         printf("\n\n Frame not received -- reading data port");
         printf("\n%4.4x", temp);
         reset();
         exit( FAILURE );
      }

      // now read the base address, should be the length
      receive_frame_size = inport( IO_BASE );
      if (SIZE_OF_FRAME < 30)  // size in words, i.e. pad characters added
      	if (receive_frame_size != 60)  // size in bytes because of pad characters
      	{
      		printf("\n\n Frame received is not the right size < 60");
            printf("\n\n %4.4x", receive_frame_size);
            reset();
            exit(FAILURE);
         }
      if (SIZE_OF_FRAME >= 30)
      	if (receive_frame_size != (SIZE_OF_FRAME * 2))
			{
      		printf("\n\n Frame received is not the right size >= 60");
            printf("\n\n %4.4x  %4.4x", receive_frame_size, (SIZE_OF_FRAME * 2));
            reset();
            exit(FAILURE);
         }

      for (j = 0; j < SIZE_OF_FRAME ; j++ )
      {
      	if ( (temp = inport( IO_BASE )) != WORD_DATA)
         {
         	printf("\n\nFrame data does not match what was sent");
            printf("\n%4.4x", temp);
				reset();
            exit(FAILURE);
         }
         printf("\nFrame Data %4.4x", temp);

      }
      if (SIZE_OF_FRAME < 30) // need to issue a skip to flush pad chars
      {
         outport( IO_BASE + PP_POINTER , 0102);
         temp = inport ( IO_BASE + PP_DATA );
         outport( IO_BASE + PP_DATA , ( temp | SKIP ) );
      }

   }
   reset();
   printf("\n\n Loopback Test Complete");
   return(SUCCESS);
}

void reset()
{

	outport( ( IO_BASE + PP_POINTER ), 0x0114 );
   outport( ( IO_BASE + PP_DATA ), 0x0040 );
   delay(25);
}
