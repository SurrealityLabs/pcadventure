
/* pc386/config.h - PC [34]86 configuration header */

/*
modification history
--------------------
02m,03aug98,cn   new BSP revision id
02l,28jul98,cn   Added INCLUDE_PCI when INCLUDE_FEI_END is defined.
02k,31mar98,cn   Added Enhanced Network Driver support.
02j,24mar98,sbs  corrected SYS_WARM_FD to be default SYS_WARM_TYPE.
02i,18mar98,sbs  added SYS_WARM_BIOS, SYS_WARM_FD, SYS_WARM_ATA. 
                 added SYS_INT_TRAPGATE, SYS_INT_INTGATE.
02h,16jan98,gnn  Removed documentation and support for END, 
		 not supported yet.
02g,28apr97,gnn  Added documentation for END_OVERRIDE and INCLUDE_END.
02f,25apr97,gnn  Added Enhanced Network Driver support.
02e,26feb97,mas  added defs of USER_RESERVED_MEM and LOCAL_MEM_AUTOSIZE; added
		 warm boot parameters (SPR 7806, 7850).
02d,22nov96,dat  fixed warning from NETIF_USR_ENTRIES.
02c,20nov96,hdn  added support for PRO100B.
02b,01nov96,hdn  added support for PCMCIA.
02a,10oct96,dat  release 1.1/1, (Tornado 1.0.1)
01z,03sep96,hdn  added the compression support. removed BOOTABLE macro.
01y,09aug96,hdn  renamed INT_VEC_IRQ0 to INT_NUM_IRQ0.
01x,05aug96,hdn  changed INT_LVL_ENE 0x0b to 0x05(default int level).
01w,19jul96,hdn  added support for ATA driver.
01v,25jun96,hdn  added support for TIMESTAMP timer.
01u,14jun96,hdn  added support for PCI bus.
01t,13jun96,hdn  added INCLUDE_ESMC for SMC91c9x Ethernet driver.
01s,28sep95,dat  new BSP revision id
01r,14jun95,hdn  added INCLUDE_SW_FP for FPP software emulation library.
01q,08jun95,ms   changed PC_CONSOLE defines.
01p,12jan95,hdn  changed SYS_CLK_RATE_MAX to a safe number.
01o,08dec94,hdn  changed EEROM to EEPROM.
01n,15oct94,hdn  changed CONFIG_ELC and CONFIG_ULTRA.
		 added INCLUDE_LPT for LPT driver.
		 added INCLUDE_EEX32 for Intel EtherExpress32.
		 changed the default boot line.
		 moved INT_VEC_IRQ0 to pc.h.
01m,03jun94,hdn  deleted shared memory network related macros.
01l,28apr94,hdn  changed ROM_SIZE to 0x7fe00.
01k,22apr94,hdn  added macros INT_VEC_IRQ0, FD_DMA_BUF, FD_DMA_BUF_SIZE.
		 moved a macro PC_KBD_TYPE from pc.h.
		 added SLIP driver with 9600 baudrate.
01j,15mar94,hdn  changed ULTRA configuration.
		 changed CONSOLE_TTY number from 0 to 2.
01i,09feb94,hdn  added 3COM EtherlinkIII driver and Eagle NE2000 driver.
                 changed RAM_HIGH_ADRS and RAM_LOW_ADRS.
                 changed LOCAL_MEM_SIZE to 4MB.
01h,27jan94,hdn  changed RAM_HIGH_ADRS 0x110000 to 0x00108000.
		 changed RAM_ENTRY 0x10000 to 0x00008000.
01g,17dec93,hdn  added support for Intel EtherExpress driver.
01f,24nov93,hdn  added INCLUDE_MMU_BASIC.
01e,08nov93,vin  added support for pc console drivers.
01d,03aug93,hdn  changed network board's address and vector.
01c,22apr93,hdn  changed default boot line.
01b,07apr93,hdn  renamed compaq to pc.
01a,15may92,hdn  written based on frc386.
*/

/*
This module contains the configuration parameters for the
PC [34]86.
*/

#ifndef	INCconfigh
#define	INCconfigh

/* BSP version/revision identification, before configAll.h */
#define BSP_VER_1_1	1
#define BSP_VERSION	"1.1"
#define BSP_REV		"/3"	/* 0 for first revision */

#define INCLUDE_SCSI2
#include "configAll.h"
#include "pc.h"


/* Include support for Crystal CS8900 Ethernet controller */

#define CS8900_IOBASE                0x300
#define CS8900_MEMBASE               0x0000
#define CS8900_INT_LVL               0xa
#define CS8900_DMA_CHANNEL           0
#define CS8900_MEDIA_TYPE            3
#define CS8900_CFG_FLAGS             0


#define INCLUDE_IF_USR
#define IF_USR_NAME    "cs"
#define IF_USR_ATTACH  csAttach
#define IF_USR_ARG1    (char*) CS8900_IOBASE            /* int  IOAddr        */
#define IF_USR_ARG2    (INT_NUM_IRQ0 + CS8900_INT_LVL)  /* int  IntVector     */
#define IF_USR_ARG3    CS8900_INT_LVL                   /* int  IntLevel      */
#define IF_USR_ARG4    CS8900_MEMBASE                   /* int  MemAddr       */
#define IF_USR_ARG5    CS8900_MEDIA_TYPE                /* int  MediaType     */
#define IF_USR_ARG6    CS8900_DMA_CHANNEL               /* int  DMA Channel   */
#define IF_USR_ARG7    CS8900_CFG_FLAGS                 /* int  Config Flags  */
#define IF_USR_ARG8    NULL                             /* unused             */


#if	CPU==I80486

#define DEFAULT_BOOT_LINE \
"cs(0,0)host:/vxWorks h=90.0.0.1 e=90.0.0.2 u=target pw=password"
#else
#define DEFAULT_BOOT_LINE \
"fd=0,0(0,0)host:/fd0/vxWorks.st h=90.0.0.1 e=90.0.0.2 u=target"
#endif	/* CPU==I80486 */


#if FALSE			/* change FALSE to TRUE for SCSI interface */
#define INCLUDE_SCSI            /* include SCSI driver */
#define INCLUDE_AIC_7880        /* include AIC 7880 SCSI driver */
#define INCLUDE_SCSI_BOOT       /* include ability to boot from SCSI */
#define INCLUDE_DOSFS           /* file system to be used */
#undef  INCLUDE_CDROMFS         /* file system to be used */
#define INCLUDE_TAPEFS          /* file system to be used */
#endif

/* warm start device type */

#define SYS_WARM_BIOS 		0 	/* warm start from BIOS */
#define SYS_WARM_FD   		1 	/* warm start from FD */
#define SYS_WARM_ATA  		2	/* warm start from ATA */

/*
 * Warm boot (reboot) parameters
 */

#define SYS_WARM_TYPE		SYS_WARM_FD /* warm start type */
#define SYS_WARM_FD_DRIVE       0       /* 0 = drive a:, 1 = b: */
#define SYS_WARM_FD_TYPE        0       /* 0 = 3.5" 2HD, 1 = 5.25" 2HD */
#define SYS_WARM_ATA_CTRL       0       /* controller 0 */
#define SYS_WARM_ATA_DRIVE      0       /* 0 = c:, 1 = d: */

/* IDT entry type */

#define SYS_INT_TRAPGATE 	0x0000ef00 	/* trap gate */
#define SYS_INT_INTGATE  	0x0000ee00 	/* int gate */

/* Optional timestamp driver */

#undef	INCLUDE_TIMESTAMP	/* include TIMESTAMP timer for Wind View */

/* Network driver options */

#define INCLUDE_ULTRA		/* include SMC Elite16 Ultra interface */
#define INCLUDE_ENE		/* include Eagle/Novell NE2000 interface */
#define INCLUDE_ELT		/* include 3COM EtherLink III interface */
#define INCLUDE_EEX		/* include INTEL EtherExpress interface */
#define INCLUDE_ESMC		/* include SMC 91c9x Ethernet interface */
#define INCLUDE_SLIP		/* include serial line interface */
#define SLIP_TTY	1	/* serial line IP channel COM2 */
#undef	INCLUDE_ELC		/* include SMC Elite16 interface */
#undef	INCLUDE_EEX32		/* include INTEL EtherExpress flash 32 */
#undef	INCLUDE_EX		/* include Excelan Ethernet interface */
#undef	INCLUDE_ENP		/* include CMC Ethernet interface*/
#undef	INCLUDE_SM_NET		/* include backplane net interface */
#undef	INCLUDE_SM_SEQ_ADDR	/* shared memory network auto address setup */

/* Optional ethernet devices */
 
/*#define INCLUDE_END */             /* Enhanced Network Driver see configNet.h */
/*#define END_OVERRIDE*/             /* define if you are using old boot ROMs. */
 
#ifdef INCLUDE_END
#define	INCLUDE_FEI		/* include Intel Ether Express PRO100B PCI */
#define INCLUDE_FEI_END         /* END-style Intel Ether Express PRO100B PCI */
#define	INCLUDE_PCI		/* include PCI bus library */
#else
#define	INCLUDE_FEI		/* include Intel Ether Express PRO100B PCI */
#endif /* INCLUDE_END */


/* Misc. options */

#if 	FALSE	
#undef  USER_D_CACHE_MODE	/* for the Pentium data cache write-back mode */
#define USER_D_CACHE_MODE	CACHE_COPYBACK
#define	INCLUDE_PCI		/* include PCI bus library */
#define INCLUDE_PCMCIA		/* include PCMCIA drivers */
#ifndef	INCLUDE_ATA
#define INCLUDE_IDE		/* hard disk driver */
#endif
#endif

#define INCLUDE_MMU_BASIC 	/* bundled mmu support */
#undef	VM_PAGE_SIZE
#define VM_PAGE_SIZE		4096

/* 
 * software floating point emulation support. DO NOT undefine hardware fp 
 * support in configAll.h as it is required for software fp emulation.
 */

#define INCLUDE_SW_FP		

#define INCLUDE_DOSFS		/* dosFs file system */
#define INCLUDE_FD		/* floppy disk driver */
#define INCLUDE_LPT		/* parallel port driver */

#ifndef	INCLUDE_IDE
#define INCLUDE_ATA		/* hard disk driver */
#endif

#define IO_ADRS_ELC	0x240
#define INT_LVL_ELC	0x0b
#define INT_VEC_ELC	(INT_NUM_IRQ0 + INT_LVL_ELC)
#define MEM_ADRS_ELC	0xc8000
#define MEM_SIZE_ELC	0x4000
#define CONFIG_ELC	0	/* 0=EEPROM 1=RJ45+AUI 2=RJ45+BNC */

#define IO_ADRS_ULTRA	0x240
#define INT_LVL_ULTRA	0x0b
#define INT_VEC_ULTRA	(INT_NUM_IRQ0 + INT_LVL_ULTRA)
#define MEM_ADRS_ULTRA	0xc8000
#define MEM_SIZE_ULTRA	0x4000
#define CONFIG_ULTRA	0	/* 0=EEPROM 1=RJ45+AUI 2=RJ45+BNC */

#define IO_ADRS_EEX	0x240
#define INT_LVL_EEX	0x0b
#define INT_VEC_EEX	(INT_NUM_IRQ0 + INT_LVL_EEX)
#define NTFDS_EEX	0x00
#define CONFIG_EEX	0	/* 0=EEPROM  1=AUI  2=BNC  3=RJ45 */
/* Auto-detect is not supported, so choose the right one you're going to use */

#define IO_ADRS_ELT	0x240
#define INT_LVL_ELT	0x0b
#define INT_VEC_ELT	(INT_NUM_IRQ0 + INT_LVL_ELT)
#define NRF_ELT		0x00
#define CONFIG_ELT	0	/* 0=EEPROM 1=AUI  2=BNC  3=RJ45 */

#define IO_ADRS_ENE	0x300
#define INT_LVL_ENE	0x05
#define INT_VEC_ENE	(INT_NUM_IRQ0 + INT_LVL_ENE)
/* Hardware jumper is used to set RJ45(Twisted Pair) AUI(Thick) BNC(Thin) */

#define IO_ADRS_ESMC	0x300
#define INT_LVL_ESMC	0x0b
#define INT_VEC_ESMC	(INT_NUM_IRQ0 + INT_LVL_ESMC)
#define CONFIG_ESMC	0	/* 0=EEPROM 1=AUI  2=BNC 3=RJ45 */
#define RX_MODE_ESMC	0	/* 0=interrupt level 1=task level */

#ifdef	INCLUDE_EEX32
#define INCLUDE_EI		/* include 82596 driver */
#define INT_LVL_EI	0x0b
#define INT_VEC_EI	(INT_NUM_IRQ0 + INT_LVL_EI)
#define EI_SYSBUS	0x44	/* 82596 SYSBUS value */
#define EI_POOL_ADRS	NONE	/* memory allocated from system memory */
/* Auto-detect is not supported, so choose the right one you're going to use */
#endif	/* INCLUDE_EEX32 */

#ifdef  INCLUDE_SLIP
#define SLIP_TTY	1	/* serial line IP channel COM2 */
#define SLIP_BAUDRATE	19200	/* baudrate 19200 */
#endif  /* INCLUDE_SLIP */

#ifdef	INCLUDE_FEI
#define	INCLUDE_PCI		/* include PCI bus library */
#define NETIF_USR_DECL \
IMPORT int feiattach();
#define NETIF_USR_ENTRIES \
{"fei", feiattach, (char *)NONE, 0, 0, 0},
#endif	/* INCLUDE_FEI */

#ifdef	INCLUDE_PCMCIA
#define INCLUDE_ATA		/* include ATA driver */
#define INCLUDE_SRAM		/* include SRAM driver */
#ifdef	INCLUDE_NETWORK
#define INCLUDE_ELT		/* include 3COM EtherLink III driver */
#endif	/* INCLUDE_NETWORK */
#endif	/* INCLUDE_PCMCIA */


/* miscellaneous definitions */

#define NV_RAM_SIZE     NONE            /* no NVRAM */

/* SYS_CLK_RATE_MAX depends upon a CPU power and a work load of an application.
 * The value was chosen in order to pass the internal test suit,
 * but it could go up to PIT_CLOCK.
 */
#define SYS_CLK_RATE_MIN  19            /* minimum system clock rate */
#define SYS_CLK_RATE_MAX  (PIT_CLOCK/256) /* maximum system clock rate */
#define AUX_CLK_RATE_MIN  2             /* minimum auxiliary clock rate */
#define AUX_CLK_RATE_MAX  8192          /* maximum auxiliary clock rate */


/* pc console definitions  */

#if	TRUE
#define INCLUDE_PC_CONSOLE 		/*  KBD and VGA are included */
#endif  /* TRUE/FALSE */

#ifdef INCLUDE_PC_CONSOLE

#define	PC_CONSOLE		0	/* console number */
#define	N_VIRTUAL_CONSOLES	2	/* shell / application */
#undef	CONSOLE_TTY		
#define	CONSOLE_TTY		-1

#endif /* INCLUDE_PC_CONSOLE */

#undef	NUM_TTY
#define NUM_TTY			(N_UART_CHANNELS)

/* define a type of keyboard. The default is 101 KEY for PS/2 */

#define PC_KBD_TYPE		PC_PS2_101_KBD
#if	FALSE
#define PC_KBD_TYPE		PC_XT_83_KBD
#endif	/* FALSE */


/* memory addresses */

/* User reserved memory.  See sysMemTop(). */

#define	USER_RESERVED_MEM	0

/*
 * Local-to-Bus memory address constants:
 * the local memory address always appears at 0 locally;
 * it is not dual ported.
 */

#define LOCAL_MEM_LOCAL_ADRS	0x00000000	/* fixed */
#define LOCAL_MEM_BUS_ADRS	0x00000000	/* fixed */
#define LOCAL_MEM_SIZE		0x00400000	/* 4MB w lower mem */

/*
 * Auto-sizing of memory is supported when this option is defined, in which
 * case LOCAL_MEM_SIZE is ignored.  See sysyPhysMemTop().
 */

#define	LOCAL_MEM_AUTOSIZE

/*
 * The following parameters are defined here and in the Makefile.
 * The must be kept synchronized; effectively config.h depends on Makefile.
 * Any changes made here must be made in the Makefile and vice versa.
 */

#ifdef	BOOTCODE_IN_RAM
#define ROM_BASE_ADRS		0x00008000	/* base address of ROM */
#define ROM_TEXT_ADRS		(ROM_BASE_ADRS)	/* booting from A: or C: */
#define ROM_SIZE		0x00090000	/* size of ROM */
#else
#define ROM_BASE_ADRS		0xfff20000	/* base address of ROM */
#define ROM_TEXT_ADRS		(ROM_BASE_ADRS)	/* booting from EPROM */
#define ROM_SIZE		0x0007fe00	/* size of ROM */
#endif

#define RAM_LOW_ADRS		0x00108000	/* VxWorks image entry point */
#define RAM_HIGH_ADRS		0x00008000	/* Boot image entry point */

#endif	/* INCconfigh */
