/* if_cs.c - Crystal Semiconductor CS8900 network interface driver          */
/*                                                                          */
/* Copyright 2000 Crystal Semiconductor Corp.                               */
/*                                                                          */
/*               Last release: v2.07a                                       */
/* Mod level for last release: 07a                                          */


/*
modification history
--------------------
v2.07a,09Oct00, kml 
 -Padded 2 bytes in RxBuf to make IP header in the WORD boundary.
 -Fixed the bug that if CPU type is MIPS, an extra byte is sent
  when an odd-aligned buffer and odd length data are passed.

v2.06a, 22Nov99, kml:
-Take out all MULTICAST related functions when BSD4.3 driver is built.

v2.05a, 09Nov99, kml:
-Fix the bug that in the BSD4.3 version, netJobAdd() should pass the address
 of CS_SOFTC instead of the interface unit number to match the argument passed
 to csEventHandler(CS_SOFTC *pCS).



v2.04a,24Sep99, kml  -Take out IFF_MULTICAST in BSD43 mode because not supported.
                     -Change receiving buffer size from 32 to 64.
                     -Correction: If the memory address parameter is zero, the CS8900 operates in the
                      mode specified by EEPROM or the Config Flag parameter.

03a,14May99,kml  -Added support for Promiscuous Mode.
                 -Added support for Multicasting.
                 -Corredted the calculation of the MIB2 static variables: 
				  if_opackets and if_ipaclets.
				 -Added codes to disable CS8900's interrupt in csInitChip()
				  when SOFT_RESET is defined.
				 -Made modification not to give up the frame when TX_UnderRun
				  occurrs and chip is not ready for TX.
         
02a,31Mar99,kml  converted to BSD44 driver, merge from SENS

01g.25nov97.jla  Added defs to help a page fault with hard resets.
                 HARD_RESET does hard chip resets
                 SOFT_RESET does a softer, kinder sort of reset
                 The routine csResetChip does one or the other based
                 on the define set in if_cs.h

01q,11apr97,rks  Implementd "early tx" support.  Required mods to csAttach
                 (initialization), csInitChip (early tx int enable),
		 csTxNextFrame, and csBufferEvent.

01p,09apr97,rks  Replaced common TX code in csStartOutput and csTransmitEvent
                 with a new routine csTxNextFrame().
		 Added conditional compile for a Tx Queue depth and max TX
		 Queue depth counter if CS_DEBUG_ENABLE defined.

01o,07apr97,rks  Changed queue routines (enqueue and deueue) to make the data
                 update prior to pointer update.  Removed the int lock/unlock
		 around the queue accesses in csEventHandler (no longer needed
		 with the new queue routines).
                 Moved the m_freem call to after the intUnlock in csStartOutput.

01n,01apr97,rks  Implemented a local queue for TX frames.  On csStartOuput call,
                 the interface's queue is drained.  Frames are then taken from
                 the local queue in csStartOutput and at ISR level for transmit
		 to ensure the interface's queue is manipulated only by routines
		 at the same context (csStartOuput and ether_output).

01m,30mar97,rks  Modified the csIntHandler.  Removed the chip int disables and
                 replaced with CLI/STI pairs only around queue manipulations.
		 Also, now use a "NetJobDepth" counter instead of an active flag
		 to determine if another csIntHandler needs to be queued.
                 Moved the netJobAdd logic to the bottom of the ISR and removed
		 it from all the ISR sub-routines.

01l,27mar97,rks  Bracketed mbuff routines in csProcessReceive with splnet/splx.

01k,28feb97,rks  Added circular queue manipulation routines to handle TX mbufs
                 to be freed and RX frames to be handled at the task level.
                 Created generic event handler (csEventHandler) to processe RX
		 frame processing and TX mbuff freeing at the task level.
                 Added a counter to ensure never more than 2 instances of the
		 event handler are queued for tNetTask processing.

01j,27feb97,rks  Added support for the collision counter. Moved support for Rx
                 miss counter to ISR (saves a function call).

01h,25feb97,rks  Modifications for MIPS suppport (prevent word reads from odd
                 addresses in csCopyTXFrame.  Debug macro to replace csError
		 routine. (Greg Rasche)

01g,07jan97,rks  Modified csAttach to remove parameter for specifying
                 Ethernet address.

01f,16dec96,rks  Divided the driver into two files, this file for
                 system-indendent routines and "sysEnet.c" containing
                 target-specific routines and macros for "IO mode" operations.
                 Added BYTE_SWAP macro for all non-constant io values
                 to the CS8900.  Replace pcX86-specific io routine
                 calls with SYS_IN/OUT macros.

01e,12dec96,rks  Moved the pTxFrameChain variable to the CS_SOFTC structure.
                 Moved the int disable in csStartOutput to immediately
                 before the Rdy4TxNow poll.  Mutex'd the call to
                 IF_DEQUEUE in csStartOutput with splnet/splx.

01d,05dec96,rks  Removed the processing of every RX miss and implemented
                 support for RX miss statistics using the RX miss counter
                 with RX Miss Counter Overflow interrupts instead.

01c,25nov96,rks  Added version number to statistics reported by csShow(),
                 Added support for TX on Rdy4Tx interrupts, Created
                 routine csFreeTxFrame() to move call of m_freem()
                 to task level Added statistic reported by csShow for
                 Rdy4Tx events

01b,16nov96,rks  Removed support for collision counter (AnyColliE) to
                 improve system perf.

01a,12jul96,q_s  Written.

*/



/*
DESCRIPTION
This module implements the Crystal Semiconductor CS8900 Ethernet network
interface driver.

This driver's structure is designed to facilitate porting to any architecture
supported by VxWorks.  The routines in this file are system independent.  A
library of system-dependent routines in the file "sysEnet.c" must be provided
for the target system.  This driver supports only one unit per system board.


SYSTEM DEPENDENT SUPPORT ROUTINES
This driver requires five system-dependent support routines.  These five
routines are defined in sysEnet.c.

* sysEnetGetConfig( CS_SOFTC *pCS )
This routine takes configuration parameters not specifed to csAttach(), if
any, from non-volatile storage (e.g. an attached EEPROM) and puts them in
the cs_softc structure.

* sysEnetAddrGet( int Unit, unsigned char *pAddr )
This routine obtains the Ethernet MAC address from non-volatile storage or
from the "csEnetAddr" array in sysEnet.c dependent on the
CS8900_ENET_ADDR_FROM_BOARD flag passed to csAttach() and saves the
Ethernet address to the arpcom structure.

* sysEnetHWInit( CS_SOFTC *pCS )
This routine uses global variables in the cs_softc structure to configure the
adapter for the board-specific IO circuitry and supported media types.

* sysEnetIntEnable( CS_SOFTC *pCS )
This routine enables the interrupt used by the CS8900 at the system level.

* sysEnetIntDisable( CS_SOFTC *pCS )
This routine disables the interrupt used by the CS8900 at the system level.  It
is not currently used by this driver.


INCLUDE FILES: if_cs.h, sysEnet.c
*/



/* INCLUDES */

#include "vxWorks.h"
#include "sysLib.h"
#include "intLib.h"
#include "logLib.h"
#include "netLib.h"
#include "etherLib.h"
#include "stdio.h"
#include "iv.h"
#include "ioctl.h"
#include "taskLib.h"
#include "net/if_subr.h"
#include "if_cs.h"

#include "sysEnet.c" /* lib of BSP specific routines used by CS8900 driver */


/* DEFINES */

#define CS_DRIVER_VER         "2.07a"     /* Driver revsion number */


 
/*********************** debug macro *******************************/
BOOL    csDebug = TRUE;  /* this flag is used to turn DEBUG on or off */

#define CS_DEBUG_ENABLE
#ifdef  CS_DEBUG_ENABLE

#define LOGMSG  if(csDebug)logMsg

#undef LOCAL 
#define LOCAL

typedef struct {
  UINT32 arg1;
  UINT32 arg2;
  UINT32 arg3;
  UINT32 arg4;
} CS_HISTORY_TYPE;

#define CS_HISTORY_SIZE    100
CS_HISTORY_TYPE csHistory[ CS_HISTORY_SIZE ];
UINT32          csHistoryIndex;

/* function prototypes */
STATUS csHistoryInit( void );
STATUS csHistoryShow( void );
STATUS csHistoryAdd( UINT32 arg1, UINT32 arg2, UINT32 arg3, UINT32 arg4 );


#else
#define LOGMSG
#endif

/*********************** end debug macro *******************************/
 


/* FORWARD DECLARATIONS */

STATUS csAttach( int Unit, int IOAddr, int IntVector, int IntLevel,
      int MemAddr, int MediaType, int DMAChannel, int ConfigFlags );
LOCAL STATUS csVerifyChip( CS_SOFTC *pCS );
LOCAL STATUS csInit( int Unit );
LOCAL void csReset( int Unit );
LOCAL int csIoctl( struct ifnet *pIf, int Command, char *pData );
LOCAL STATUS csResetChip( CS_SOFTC *pCS );
LOCAL void csInitChip( CS_SOFTC *pCS );

#ifdef BSD43_DRIVER
LOCAL void	csStartOutput	(int Unit);
LOCAL int	csOutput	(struct ifnet *pIf, struct mbuf *pMbufChain,
				 SOCKADDR *pDst);
#else
LOCAL void	csStartOutput	(CS_SOFTC *pCS);
#endif

LOCAL void csCopyTxFrame( CS_SOFTC *pCS, struct mbuf *pMbufChain );
LOCAL void csIntr( int Unit );
LOCAL void csBufferEvent( CS_SOFTC *pCS, USHORT BuffEvent );
LOCAL void csTransmitEvent( CS_SOFTC *pCS, USHORT TxEvent );
LOCAL void csReceiveEvent( CS_SOFTC *pCS, USHORT RxEvent );
LOCAL void csCopyRxFrame( CS_SOFTC *pCS, PRXBUF pRxBuff );
LOCAL void csProcessReceive( CS_SOFTC *pCS, PRXBUF pRxBuff );
LOCAL STATUS csInitRxBuff( CS_SOFTC *pCS );
LOCAL PRXBUF csAllocRxBuff( CS_SOFTC *pCS );
LOCAL void csFreeRxBuff( CS_SOFTC *pCS, PRXBUF pRxBuff );
void csShow( int Unit, BOOL Zap );
LOCAL USHORT csReadPacketPage( CS_SOFTC *pCS, USHORT Offset );
LOCAL void csWritePacketPage( CS_SOFTC *pCS, USHORT Offset, USHORT Value );
LOCAL void csInitQueue( CIR_QUEUE *Q );
LOCAL void *csDequeue( CIR_QUEUE *Q );
LOCAL STATUS csEnqueue( CIR_QUEUE *Q, void *pBuff );
LOCAL void csEventHandler( CS_SOFTC *pCS );
LOCAL BOOL csQueueEmpty( CIR_QUEUE *Q );
LOCAL void csTxNextFrame( CS_SOFTC *pCS );


/*********************** Functions for Multicasting *************************/
#ifndef BSD43_DRIVER
LOCAL UCHAR  calculateHashIndex(UCHAR *pMulticastAddr);
LOCAL void   updateCrc( USHORT bit );
LOCAL void   csMCastAdd(CS_SOFTC *pCS, char *pData);
LOCAL void   csMCastDel(CS_SOFTC *pCS, char *pData);

/* used to calculate multicast hash index */
int CRC_Poly[] = {1,1,1,0,  1,1,0,1,
		          1,0,1,1,  1,0,0,0,
                  1,0,0,0,  0,0,1,1,
                  0,0,1,0,  0,0,0,0 };
int    CRC[33];

#endif




/* ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ *
 * OS Entry-point Routines                                                 *
 * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ */



/*******************************************************************************
*
* csAttach -
*
* This routine is a major entry point to this network interface driver and is
* called only once per operating system reboot by the operating system startup
* code.  This routine is called before the csInit() routine.
*
* This routine takes passed-in configuration parameters and parameters from
* the EEPROM and fills in the instance global variables in the cs_softc
* structure.  These variables are later used by the csInitChip() routine.
*
* This routine connects the interrupt handler, csIntr(), to the specified
* interrupt vector, initializes the 8259 PIC and resets the CS8900 chip.
*
* Finally, this routine calls the ether_attach() routine, to fill in the ifnet
* structure and attach this network interface driver to the system.  The
* driver's main entry points (csInit(), csIoctl(), csOutput(), csReset()) are
* made visable to the protocol stack.
*
* RETURNS: OK, or ERROR if any of the called routines fail.
*
*/

STATUS csAttach( int Unit, int IOAddr, int IntVector, int IntLevel,int MemAddr, int MediaType, int DMAChannel , int ConfigFlags )
{
   FAST CS_SOFTC *pCS;

   if ( Unit >= CS_MAX_NUM_UNITS )
   {
      LOGMSG("csAttach: Invalid unit number (%d)\n", 
         Unit,0,0,0,0,0 );
      return ERROR;
   }

   pCS = &cs_softc[Unit];

   /* Save the passed-in parameters */
   pCS->IOAddr      = IOAddr;
   pCS->IntLevel    = IntLevel;
   pCS->IntVector   = IntVector;
   pCS->pPacketPage = (USHORT *)MemAddr;
   pCS->MediaType   = MediaType;
   pCS->ConfigFlags = ConfigFlags;

   /* Start out in IO mode */
   pCS->InMemoryMode = FALSE;

   /* Init TX in progress flag */
   pCS->TxInProgress = FALSE;

   /* Init the TX start command */
   pCS->TxStartCMD = CS_INITIAL_START_CMD;
   
   /* Set counters to zero */
   pCS->TxUnderruns      = 0;
   pCS->TotalTxUnderruns = 0;
   pCS->RxDepth          = 0;
   pCS->MaxRxDepth       = 0;
   pCS->MaxTxDepth       = 0;
   pCS->LoanCount        = 0;
   pCS->Rdy4TxInts       = 0;
   pCS->NetJobDepth      = 0;

#ifdef CS_DEBUG_ENABLE
   pCS->TxQueueDepth    = 0;
   pCS->MaxTxQueueDepth = 0;
#endif

   /* Initialize local queues */
   pCS->pTxBuffFreeList = &TxBuffFreeList;
   pCS->pRxBuffProcessList = &RxBuffProcessList;
   pCS->pTxQueue = &TxQueue;
   csInitQueue( pCS->pTxBuffFreeList );
   csInitQueue( pCS->pRxBuffProcessList );
   csInitQueue( pCS->pTxQueue );
   
   /* Allocate the receive frame buffers */
   if ( csInitRxBuff(pCS) == ERROR )
   {
      LOGMSG("csAttach: unit %d Can not allocate receive buffers\n", 
         Unit,0,0,0,0,0 );
      return ERROR;
   }

   /* Verify that it is the correct chip */
   if ( csVerifyChip(pCS) == ERROR )
   {
      LOGMSG("csAttach: unit %d, csVerifyChip failed\n", 
         Unit,0,0,0,0,0 );
      return ERROR;
   }

   /* Get any CS8900 parameters not specifed in network interface table */
   if ( sysEnetGetConfig(pCS) == ERROR )
   {
      LOGMSG("csAttach: unit %d, sysEnetGetConfig failed\n", 
         Unit,0,0,0,0,0 );
      return ERROR;
   }

   /* Get Ethernet addr in BSP-specific manner and copy to ArpCom structure */
   if ( sysEnetAddrGet(Unit,pCS->ArpCom.ac_enaddr) == ERROR )
   {
      LOGMSG("csAttach: unit %d, sysEnetAddrGet failed\n", 
         Unit,0,0,0,0,0 );
      return ERROR;
   }

   /* Setup the interrupt handler and the IDT table entry */
   if ( intConnect(INUM_TO_IVEC(pCS->IntVector),csIntr,Unit) == ERROR )
   {
      LOGMSG("csAttach: unit %d, Can not connect intertupt\n", 
         Unit,0,0,0,0,0 );
      return ERROR;
   }

   /* Enable CS8900 interrupts at the system level */
   if ( sysEnetIntEnable(pCS) == ERROR )
   {
      LOGMSG("csAttach: unit %d, sysEnetIntEnable failed\n", 
         Unit,0,0,0,0,0 );
      return( ERROR );
   }

   /* Reset the chip */
   if ( csResetChip(pCS) == ERROR )
   {
      LOGMSG("csAttach: unit %d, Can not reset chip\n", 
         Unit,0,0,0,0,0 );
      return ERROR;
   }

   /* Attach this network interface driver to the system */

#ifdef BSD43_DRIVER
    ether_attach (&pCS->ArpCom.ac_if, Unit, "cs", csInit, csIoctl, csOutput,
		  (FUNCPTR)csReset);
#else
    ether_attach    (
                    &pCS->ArpCom.ac_if,
                    Unit,
                    "cs",
                    (FUNCPTR) csInit,
                    (FUNCPTR) csIoctl,
                    (FUNCPTR) ether_output, /* generic ether_output */
                    (FUNCPTR) csReset
                    );

    pCS->ArpCom.ac_if.if_start = (FUNCPTR) csStartOutput; 
#endif

     /* Promiscuous@kml Set promiscuous mode if user asked for. */ 
	if ( pCS->ConfigFlags & CFGFLG_PROMISC_MODE ) {
		pCS->ArpCom.ac_if.if_flags |= IFF_PROMISC;
    }


   return OK;
}



/*******************************************************************************
*
* csInit -
*
* This routine is a major entry point and is called to initialize this network
* interface driver.  This routine may be called several times for each
* operating system reboot to dynamically bring the network interface driver
* to an up and running state.  This routine is called by the protocol stack,
* the set_if_addr() routine, and the csIoctl() routine.
*
* This routine resets and then initializes the CS8900 chip.
*
*/

LOCAL STATUS csInit( int Unit )
{
   FAST CS_SOFTC *pCS;

   if ( Unit >= CS_MAX_NUM_UNITS ) 
      return ERROR;

   pCS = &cs_softc[Unit];

   /* Mark the interface as down */
   pCS->ArpCom.ac_if.if_flags &= ~(IFF_UP | IFF_RUNNING);

   LOGMSG("csInit: unit %d, Initializing interface\n",
      pCS->ArpCom.ac_if.if_unit, 0,0,0,0,0 );

   /* Reset the chip */
   if ( csResetChip(pCS) == ERROR )
   {
      LOGMSG("csInit: unit %d, Can not reset the chip\n",
         pCS->ArpCom.ac_if.if_unit, 0,0,0,0,0 );
      return ERROR;
   }

   /* Initialize the chip */
   csInitChip( pCS );

   /* Mark the interface as up and running and supporting multicasting*/
#ifdef BSD43_DRIVER
   pCS->ArpCom.ac_if.if_flags |= (IFF_UP | IFF_RUNNING ); /* Multicast not supported by BSD43. */
#else
   pCS->ArpCom.ac_if.if_flags |= (IFF_UP | IFF_RUNNING | IFF_MULTICAST );
#endif

   return OK;
}




/*******************************************************************************
*
* csReset -
*
* This routine is a major entry point and is called by the protocol stack to
* shut down this network interface driver.  This routine may be called several
* times for each operating system reboot to dynamically bring the network
* interface driver to a non-running state.
*
* This routine resets the CS8900 chip.
*
*/

LOCAL void csReset( int Unit )
{
   FAST CS_SOFTC *pCS;

   if ( Unit >= CS_MAX_NUM_UNITS ) 
      return;

   pCS = &cs_softc[Unit];

   LOGMSG("csReset: unit %d, Resetting interface\n",
     pCS->ArpCom.ac_if.if_unit, 0,0,0,0,0 );

   /* Mark the interface as down */
   pCS->ArpCom.ac_if.if_flags &= ~IFF_RUNNING;

   /* Reset the chip */
   csResetChip( pCS );
}




/*******************************************************************************
*
* csIoctl -
*
* This routine is a major entry point and is called by the protocol stack to
* modify characteristics of this network interface driver.  There are many
* network interface ioctl commands, but this driver only supports two of them:
* Set Interface Address and Set Interface Flags.
*
*/

LOCAL int csIoctl( struct ifnet *pIf, int Command, char *pData )
{
   int State;
   int Result;
   FAST CS_SOFTC *pCS;

   State = splnet();

   pCS = &cs_softc[pIf->if_unit];

   Result = OK;  /* Assume everything will go OK */

   switch( Command )
   {
      case SIOCSIFADDR:  /* Set interface address (IP address) */
         LOGMSG("csIoctl: unit %d, Set interface address\n",
            pCS->ArpCom.ac_if.if_unit, 0,0,0,0,0 );
         Result = set_if_addr( pIf, pData, (UCHAR *)pCS->ArpCom.ac_enaddr );
         /* Note: set_if_addr() calls csInit() */
         break;

      case SIOCSIFFLAGS:  /* Set interface flags */
         LOGMSG("csIoctl: unit %d, Set interface flags\n",
            pCS->ArpCom.ac_if.if_unit, 0,0,0,0,0 );
         
         /* Promiscuous@kml If need to enable the promiscuous mode */
		 if (pIf->if_flags & IFF_PROMISC) {
            pCS->ArpCom.ac_if.if_flags |= IFF_PROMISC;
            pCS->ConfigFlags |= CFGFLG_PROMISC_MODE;
         } else {
            pCS->ArpCom.ac_if.if_flags &= ~IFF_PROMISC;
            pCS->ConfigFlags &= ~CFGFLG_PROMISC_MODE;
		 }

         if ( pIf->if_flags & IFF_UP )
         {
            /* Mark the interface as up and running */
            pCS->ArpCom.ac_if.if_flags |= (IFF_UP | IFF_RUNNING);

            /* Initialize the interface */
            csInit( pIf->if_unit );
         }
         else  /* The interface is down */
         {
            /* Mark the interface as down */
            pCS->ArpCom.ac_if.if_flags &= ~(IFF_UP | IFF_RUNNING);

            /* Reset the chip */
            csResetChip( pCS );
         }
         break;

#ifndef BSD43_DRIVER
	 case SIOCADDMULTI:
		 if ( !pData) {
		    Result = EINVAL;  /* Invalid argument */
            break;
         }
         csMCastAdd (pCS, pData);
         break;


	 case SIOCDELMULTI:
		 if ( !pData) {
		    Result = EINVAL;  /* Invalid argument */
            break;
         }
         csMCastDel(pCS, pData);
         break;
#endif

      default:
         Result = EINVAL;  /* Invalid argument */
         break;
   }

   splx( State );

   return Result;
}



#ifdef BSD43_DRIVER
/*******************************************************************************
*
* csOutput -
*
* This routine is a major entry point and is called by the protocol stack to
* transmit a packet across the LAN.  The packet data is passed to this routine
* in a chain of mbuf structures.
*
* This routine calls the ether_output() routine, which in turn calls the
* csStartOutput() routine.  The ether_output() routine resolves the destination
* IP address to it's Ethernet address, builds an Ethernet header and prepends
* the Ethernet header to the mbuf chain.  The mbuf chain is added to the end
* of the network interface driver's transmit queue.  
*
*/

LOCAL int csOutput( struct ifnet *pIf, struct mbuf *pMbufChain, SOCKADDR *pDst )
{
   FAST CS_SOFTC *pCS;

   pCS = &cs_softc[pIf->if_unit];

   /* Call ether_ouput to queue the TX frame */
   return ether_output( pIf, pMbufChain, pDst, (FUNCPTR)csStartOutput,
         &pCS->ArpCom );
}

#endif /* BSD43_DRIVER */


/* ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ *
 * Interrupt-handler Routines                                              *
 * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ */


/*******************************************************************************
*
* csIntr -
*
* This routine in the interrupt service routine.  This routine is called by
* VxWorks wrapper code whenever the CS8900 chip generates and interrupt.  The 
* wrapper code issues an EOI command.
*
* This routine processes the events on the Interrupt Status Queue.  The events
* are read one at a time from the ISQ and the appropriate event handlers are
* called.  The ISQ is read until it is empty.  Reading a zero from the ISQ will
* deassert the interrupt request line.
*
* RETURNS: Nothing
*
*/

LOCAL void csIntr( int Unit )
{
   FAST CS_SOFTC *pCS;
   USHORT Event;
   struct ifnet *pIf;

   if( Unit >= CS_MAX_NUM_UNITS ) 
      return;

   pCS = &cs_softc[Unit];
   pIf = &pCS->ArpCom.ac_if;

   /* Ignore any interrupts that happen while the chip is being reset */
   if( pCS->Resetting )
      return;

   /* Set locale flag */
   pCS->InISR = TRUE;

   /* Read an event from the Interrupt Status Queue */
   if( pCS->InMemoryMode )
      Event = csReadPacketPage( pCS, PKTPG_ISQ );
   else
      Event = SYS_ENET_IN_WORD( (pCS->IOAddr)+PORT_ISQ );

   /* Process all the events in the Interrupt Status Queue */
   while( Event != 0 )
   {
      /* Dispatch to an event handler based on the register number */
      switch ( Event & REG_NUM_MASK )
      {
         case REG_NUM_RX_EVENT:
            csReceiveEvent( pCS, Event );
            break;

         case REG_NUM_TX_EVENT:
            csTransmitEvent( pCS, Event );
            break;

         case REG_NUM_BUF_EVENT:
            csBufferEvent( pCS, Event );
            break;

         case REG_NUM_RX_MISS: 
            /* Read the Rx Miss count (clears the counter). */
	    /* Miss count is in the 10 MSBs */
            pCS->ArpCom.ac_if.if_ierrors += ( (BYTE_SWAP(Event)) >> 6); 

            LOGMSG("csRxMissEvent: unit %d,, %d added to RX miss counter\n",
	       pCS->ArpCom.ac_if.if_unit, ( (BYTE_SWAP(Event)) >> 6),0,0,0,0 );
            break;

         case REG_NUM_TX_COL:  
            /* Read the collision counter (clears the counter). */           
	    /* Collision count is in the 10 MSBs */
            pCS->ArpCom.ac_if.if_collisions += ( (BYTE_SWAP(Event)) >> 6); 

            LOGMSG("csTxColEvent: unit %d, %d added to collision counter\n",
               pCS->ArpCom.ac_if.if_unit, ( (BYTE_SWAP(Event)) >> 6),0,0,0,0 );
            break;
  
         default: 
            LOGMSG("csIntr: unit %d, Unknown interrupt event: %04X\n",
               pCS->ArpCom.ac_if.if_unit, (BYTE_SWAP(Event)),0,0,0,0 );
            break;
      }

      /* Read another event from the Interrupt Status Queue */
      if ( pCS->InMemoryMode )
         Event = csReadPacketPage( pCS, PKTPG_ISQ );
      else
         Event = SYS_ENET_IN_WORD( (pCS->IOAddr)+PORT_ISQ );
   }
   
   /* Ensure task-level event handler is running */
   if( pCS->NetJobDepth < 2 )
   {
      pCS->NetJobDepth++;
	  netJobAdd ((FUNCPTR)csEventHandler, (int)pCS, 0, 0, 0, 0);
   }

   /* Clear locale flag */
   pCS->InISR = FALSE;
}


/*******************************************************************************
*
* csBufferEvent -
*
* The routine is called whenever an event occurs regarding the transmit and
* receive buffers within the CS8900 chip.  The only buffer events we 
* currently handle are Rdy4TX interrupts, Tx Underruns, and SW ints.
*
*/

LOCAL void csBufferEvent( CS_SOFTC *pCS, USHORT BufEvent )
{

   USHORT BusStatus;

  if ( BufEvent & BUF_EVENT_TX_UNDR )
   {

      /* TX underrun occured */
      pCS->TxUnderruns++;

      /* Modify start command if total underruns > threshold value */
      /* by setting TX start command to next increment */
      if( pCS->TxUnderruns == CS_TX_UNDRUN_TRHSHOLD )
      {
          /* Reset the threshold counter */
          pCS->TxUnderruns = 0;
          
          /* Select the next TxStartCommand */ 
          if( pCS->TxStartCMD == TX_CMD_START_5 )
             pCS->TxStartCMD = TX_CMD_START_381;

          else if( pCS->TxStartCMD == TX_CMD_START_381 )
             pCS->TxStartCMD = TX_CMD_START_1021;

	  else pCS->TxStartCMD = TX_CMD_START_ALL;
      }
       
      /* Try to TX the frame again */
      if ( pCS->InMemoryMode )
      {
	     csWritePacketPage( pCS, PKTPG_TX_CMD, pCS->TxStartCMD );
	     csWritePacketPage( pCS, PKTPG_TX_LENGTH, BYTE_SWAP(pCS->TxLength) );
      }
      else  /* In IO mode */
      {
	     SYS_ENET_OUT_WORD( (pCS->IOAddr)+PORT_TX_CMD, pCS->TxStartCMD );
	     SYS_ENET_OUT_WORD( (pCS->IOAddr)+PORT_TX_LENGTH, 
	     BYTE_SWAP(pCS->TxLength));
      }

      /* Read BusStatus register which indicates success of the request */
      BusStatus = csReadPacketPage( pCS, PKTPG_BUS_ST );

      if ( BusStatus & BUS_ST_RDY4TXNOW )
      {
	    /* On-chip buffer space available -- start transmission */
	    csCopyTxFrame( pCS, pCS->pTxFrameChain );
      } /* @kml Do NOT give up the frame. */
     /* else
      {*/
	    /* Give up on this frame */
	    /* Queue the mbuf chain to be freed at task level */
	 /*   csEnqueue( pCS->pTxBuffFreeList, pCS->pTxFrameChain );*/

	    /* Set TX not in progress */
	 /*   pCS->pTxFrameChain = NULL;
	    pCS->TxInProgress = FALSE;*/

	    /* Update output stats */
	   /* pCS->ArpCom.ac_if.if_opackets--;*/
  /* @kml	 The definition of the MIB-II variable ifOutUcastPkts in Interface
	   group from RFC 1158 is "The total  number of  packets that higher-level 
	   protocols requested be transmitted to a subnetwork-unicast address, 
	   INCLUDE those that were discarded or not sent."*/

	   /* pCS->ArpCom.ac_if.if_oerrors++;*/

	    /* Start TX of the next frame if any */
	    /*csTxNextFrame( pCS );*/
      /*}*/

      LOGMSG("csBufferEvent: unit %d, Transmit underrun\n",
         pCS->ArpCom.ac_if.if_unit, 0,0,0,0,0 );

      pCS->TotalTxUnderruns++;
   }


   else if ( BufEvent & BUF_EVENT_RDY4TX )
   {
      (pCS->Rdy4TxInts) += 1;

      /* The chip is ready for transmission now */

      /* If a TX is pending, copy the frame to the chip to start transmission */
      if( pCS->pTxFrameChain != NULL )
      {
         csCopyTxFrame( pCS, pCS->pTxFrameChain );
      }
   }


   else if ( BufEvent & BUF_EVENT_SW_INT )
   {
      LOGMSG("csBufferEvent: unit %d, Software initiated interrupt\n",
         pCS->ArpCom.ac_if.if_unit, 0,0,0,0,0 );
   }

}




/*******************************************************************************
*
* csTransmitEvent -
*
* This routine is called whenever the transmission of a packet has completed
* successfully or unsuccessfully.  If the transmission was not successful,
* then the output error count is incremented.  If there are more packets in the
* transmit queue, then the next packet is started immediately.
*
*/

LOCAL void csTransmitEvent( CS_SOFTC *pCS, USHORT TxEvent )
{
   struct ifnet *pIf;

   pIf = &pCS->ArpCom.ac_if;
   
   /* WE only get here if the transmit in progress has completed, either 
    * successfully or due to an error condition.  In any event, queue the 
    * mbuf chain for freeing at task level and NULL the frame pointer to mark
    * the TX no longer in progress.
    */

   csEnqueue( pCS->pTxBuffFreeList, pCS->pTxFrameChain );
   pCS->pTxFrameChain = NULL;
   pCS->TxInProgress = FALSE;   

   /* If there were any errors transmitting this frame */
   if ( TxEvent & (TX_EVENT_LOSS_CRS | TX_EVENT_SQE_ERR | TX_EVENT_OUT_WIN |
            TX_EVENT_JABBER | TX_EVENT_16_COLL) )
   {
      /* Increment the output error count */

  /* @kml	 The definition of the MIB-II variable ifOutUcastPkts in Interface
	   group from RFC 1158 is "The total  number of  packets that higher-level 
	   protocols requested be transmitted to a subnetwork-unicast address, 
	   INCLUDE those that were discarded or not sent."*/

	  /*pIf->if_opackets--;*/
      pIf->if_oerrors++;

      /* If debugging is enabled then log error messages */
      if ( csDebug == TRUE )
      {
	 if ( TxEvent & TX_EVENT_LOSS_CRS )
	 {
	    LOGMSG("csTransmitEvent: unit %d, Loss of carrier\n",
	       pCS->ArpCom.ac_if.if_unit, 0,0,0,0,0 );
	 }
	 if ( TxEvent & TX_EVENT_SQE_ERR )
	 {
	    LOGMSG("csTransmitEvent: unit %d, SQE error\n",
	       pCS->ArpCom.ac_if.if_unit, 0,0,0,0,0 );
	 }
	 if ( TxEvent & TX_EVENT_OUT_WIN )
	 {
	    LOGMSG("csTransmitEvent: unit %d, Out-of-window collision\n",
	       pCS->ArpCom.ac_if.if_unit, 0,0,0,0,0 );
	 }
	 if ( TxEvent & TX_EVENT_JABBER )
	 {
	    LOGMSG("csTransmitEvent: unit %d, Jabber\n",
	       pCS->ArpCom.ac_if.if_unit, 0,0,0,0,0 );
	 }
	 if ( TxEvent & TX_EVENT_16_COLL )
	 {
	    LOGMSG("csTransmitEvent: unit %d, 16 collisions\n",
	       pCS->ArpCom.ac_if.if_unit, 0,0,0,0,0 );
	 }
      }
   } 


   /* Previous TX complete so start the next TX now if more to transmit */
   csTxNextFrame( pCS );
}




/*******************************************************************************
*
* csReceiveEvent -
*
* This routine is called whenever a packet is received at the chip.  If the
* packet is received with errors, then the input error count is incremented.
* If the packet is received OK, then the data is copied to an internal receive
* buffer and processed at task level (in csEventHandler). 
*
* RETURNS: Nothing
*/

LOCAL void csReceiveEvent( CS_SOFTC *pCS, USHORT RxEvent )
{
   struct ifnet *pIf;
   PRXBUF pRxBuff;

   pIf = &pCS->ArpCom.ac_if;

   /* If the frame was not received OK */
   if ( !(RxEvent & RX_EVENT_RX_OK) )
   {
      /* Increment the input error count */
      pIf->if_ierrors++;

      /* If debugging is enabled then log error messages */
      if ( csDebug == TRUE )
      {
         /* If an error bit is set */
         if ( RxEvent != REG_NUM_RX_EVENT )
         {
            if ( RxEvent & RX_EVENT_RUNT )
            {
              LOGMSG("csReceiveEvent: unit %d, Runt\n",
                 pCS->ArpCom.ac_if.if_unit, 0,0,0,0,0 );
            }
            if ( RxEvent & RX_EVENT_X_DATA )
            {
              LOGMSG("csReceiveEvent: unit %d, Extra data\n",
                 pCS->ArpCom.ac_if.if_unit, 0,0,0,0,0 );
            }
            if ( RxEvent & RX_EVENT_CRC_ERR )
            {
               if ( RxEvent & RX_EVENT_DRIBBLE )
               {
                  LOGMSG("csReceiveEvent: unit %d, Alignment error\n",
                     pCS->ArpCom.ac_if.if_unit, 0,0,0,0,0 );
               }
               else
               {
                  LOGMSG("csReceiveEvent: unit %d, CRC Error\n",
                     pCS->ArpCom.ac_if.if_unit, 0,0,0,0,0 );
               }
            }
            else if ( RxEvent & RX_EVENT_DRIBBLE )
            {
               LOGMSG("csReceiveEvent: unit %d, Dribble bits\n",
                  pCS->ArpCom.ac_if.if_unit, 0,0,0,0,0 );
            }
         }
      }

      /* Skip this error frame */
      csReadPacketPage( pCS, PKTPG_RX_LENGTH );
      csWritePacketPage( pCS, PKTPG_RX_CFG,
         csReadPacketPage(pCS,PKTPG_RX_CFG) | RX_CFG_SKIP );

      return;
   }

   /* Get a receive frame buffer */
   pRxBuff = csAllocRxBuff( pCS );

   if ( pRxBuff == NULL )  /* If no buffer available */
   {
      /* Increment the input error count */
      pIf->if_ierrors++;
      
#if ( ! STRESS_TESTING )
      LOGMSG("csReceiveEvent: unit %d, No receive buffer available\n",
         pCS->ArpCom.ac_if.if_unit, 0,0,0,0,0 );
#endif

      /* Must read the length of all received frames */
      csReadPacketPage( pCS, PKTPG_RX_LENGTH );

      /* Skip the received frame */
      csWritePacketPage( pCS, PKTPG_RX_CFG,
            csReadPacketPage(pCS,PKTPG_RX_CFG) | RX_CFG_SKIP );
      return;
   }

   /* Copy the received frame from the chip to the buffer */
   csCopyRxFrame( pCS, pRxBuff );

   /* Queue a pointer to the buffer to be processed at task level */
   csEnqueue( pCS->pRxBuffProcessList, (PTXBUF)pRxBuff );

}



/*******************************************************************************
* csEventHandler -
*
* This routine runs at the task level to processes RX frames and frees TX'd 
* mbuf chains queued at the ISR level.  Up to two instances of this
* routine may be queued to tNetTask to prevent a race condition between final
* checking of a queue here and an enqueue at the ISR level.  A netJob
* "counter" is decremented each time this routine starts.
*
* RETURNS: Nothing.
*
*/

LOCAL void csEventHandler( CS_SOFTC *pCS )
{
   void  *pBuff;

   if( pCS->NetJobDepth > 0 ) 
       pCS->NetJobDepth--;
      
   while( !csQueueEmpty( pCS->pRxBuffProcessList ) )
   {
      /* Process an RX frame */  
      pBuff = csDequeue( pCS->pRxBuffProcessList );
      csProcessReceive( pCS, pBuff ); 
   }

   while( !csQueueEmpty( pCS->pTxBuffFreeList ) )
   {
      /* Free up the TX'd mbuf chains */
      pBuff = csDequeue( pCS->pTxBuffFreeList );
      m_freem( pBuff );
   }
}






/* ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ *
 * Transmit-releated Routines                                              *
 * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ */



/*******************************************************************************
*
* csStartOutput -
*
* This routine is called to start the transmission of the packet at the head
* of the transmit queue.  This routine is called by the ether_output() routine
* when a new packet is added to the transmit queue. 
*
* RETURNS: Nothing
*
*/

#ifdef BSD43_DRIVER 
LOCAL void csStartOutput( int Unit )
{
   FAST CS_SOFTC *pCS;
   FAST struct mbuf *pMbuf;
   struct ifqueue *pTxQueue;
   int Spl;
   BOOL  QError;

   if ( Unit >= CS_MAX_NUM_UNITS ) 
      return;

   pCS = &cs_softc[Unit];

#else /* BSD4.4 DRIVER */

LOCAL void csStartOutput
    (
    CS_SOFTC * pCS		/* pointer to control structure */
    )
    {
   FAST struct mbuf *pMbuf;
   struct ifqueue *pTxQueue;
   int Spl;
   BOOL  QError;
#endif /* BSD43_DRIVER */


   pTxQueue = &pCS->ArpCom.ac_if.if_snd;

   /* Note the maximum depth of the transmit queue */
   if ( pTxQueue->ifq_len > pCS->MaxTxDepth )
      pCS->MaxTxDepth = pTxQueue->ifq_len;

   /* Drain the interface's send queue into the local TX queue */

   while ( pTxQueue->ifq_head != NULL )
   {
      Spl = splnet();
      /* Dequeue an mbuf chain from the transmit queue */
      IF_DEQUEUE( pTxQueue, pMbuf );
      splx( Spl );
      
      QError = csEnqueue( pCS->pTxQueue, pMbuf );

      if ( QError )
      {
	    /* TxQueue is full -- dump the frame and exit loop */	     
	    m_freem( (PTXBUF)pMbuf );

	    /* Update output stats */
	    pCS->ArpCom.ac_if.if_oerrors++;

	    LOGMSG("csStartOutput: unit %d, Transmit queue overflow\n",
	           pCS->ArpCom.ac_if.if_unit, 0,0,0,0,0 );

	    /* Local TX queue is full so exit loop */
	    break;
      }

	  /* @kml*/
	 pCS->ArpCom.ac_if.if_opackets++;

#ifdef CS_DEBUG_ENABLE
      pCS->TxQueueDepth++;
      if ( pCS->TxQueueDepth > pCS->MaxTxQueueDepth )
	 pCS->MaxTxQueueDepth = pCS->TxQueueDepth;
#endif

   }


   /* Transmit another frame if a TX is not currently in progress */
   if ( !pCS->TxInProgress ) 
   {
      csTxNextFrame( pCS );
   }
}



/*******************************************************************************
* csTxNextFrame -
*
* This routine start the TX of the next frame in the local TX send queue.
* If an error occurs, the output error count is incremented and the mbuf chain
* is freed, either by immediately calling mfree_m() if we are at task level, 
* or queueing the mbuf chain for release at the task level if we are currently
* at the ISR level.
*
* RETURNS: Nothing
*
*/

LOCAL void csTxNextFrame ( CS_SOFTC *pCS )
{
   int State = 0;
   USHORT BusStatus;
   PMBUF  pMbuf;

   /* etherOutputHookRtn is not supported in a standard way.  It does not
    * perform an "alternative TX operation".  To do so would require copying
    * the TX data to a local linear buffer (too expensive).  Since we don't 
    * have a linear buffer, simply pass a NULL as the second and third 
    * parameters.
    */

   if (etherOutputHookRtn != NULL)
   {
	  

      (* etherOutputHookRtn) (&pCS->ArpCom, NULL, NULL);
   }


   /* Transmit the next frame in the local TxQueue */

   while( !csQueueEmpty( pCS->pTxQueue ) )
   {
	   
#ifdef CS_DEBUG_ENABLE
      pCS->TxQueueDepth--;
#endif

      if ( !pCS->InISR )
      {
	 /* Ensure the transmit bid and copy to chip is atomic */
	 State = intLock( );
      }

      pCS->pTxFrameChain = csDequeue( pCS->pTxQueue );
	 
      /* Find the total length of the data to transmit */
      pCS->TxLength = 0;
      for ( pMbuf = pCS->pTxFrameChain; pMbuf!=NULL; pMbuf=pMbuf->m_next )
      {
	 pCS->TxLength += pMbuf->m_len;
      }

      /* Bid for space on the chip and start the TX if bid successful */
      if ( pCS->InMemoryMode )
      {
	 csWritePacketPage( pCS, PKTPG_TX_CMD, pCS->TxStartCMD );
	 csWritePacketPage( pCS, PKTPG_TX_LENGTH, BYTE_SWAP(pCS->TxLength) );
      }
      else  /* In IO mode */
      {

	 SYS_ENET_OUT_WORD( (pCS->IOAddr)+PORT_TX_CMD, pCS->TxStartCMD );
	 SYS_ENET_OUT_WORD( (pCS->IOAddr)+PORT_TX_LENGTH, 
	    BYTE_SWAP(pCS->TxLength));

      }

      /* Read BusStatus register which indicates success of the request */
      BusStatus = csReadPacketPage( pCS, PKTPG_BUS_ST );

      if ( BusStatus & BUS_ST_RDY4TXNOW )
      {
	   /* The chip is ready for transmission now */
	   /* Copy the frame to the chip to start transmission */
	   csCopyTxFrame( pCS, pCS->pTxFrameChain );

	   /* Mark TX as in progress */
	   pCS->TxInProgress = TRUE;


	   if ( !pCS->InISR )
	   {
	    /* Re-enable interrupts at the CPU */
	    intUnlock( State );
	   }


	   /* Transmission now in progress */
	   break;
      }
      else
      {
	 /* If there was an error in the transmit bid */
	 if ( BusStatus & BUS_ST_TX_BID_ERR )
	 {
	    /* Set TX not in progress */
	    pMbuf = pCS->pTxFrameChain;
	    pCS->pTxFrameChain = NULL;
	    pCS->TxInProgress = FALSE;

	    if ( !pCS->InISR )
	    {
	       /* Re-enable interrupts at the CPU */
	       intUnlock( State);

	       /* Free the bad mbuf chain */
	       m_freem( pMbuf );
	    }
	    else
	    {
	       /* queue the mbuf chain to be freed at task level */
	       csEnqueue( pCS->pTxBuffFreeList, pMbuf );
	    }

	    /* Update output stats */
  /* @kml	 The definition of the MIB-II variable ifOutUcastPkts in Interface
	   group from RFC 1158 is "The total  number of  packets that higher-level 
	   protocols requested be transmitted to a subnetwork-unicast address, 
	   INCLUDE those that were discarded or not sent."*/

	   /* pCS->ArpCom.ac_if.if_opackets--;*/
	    pCS->ArpCom.ac_if.if_oerrors++;

	    LOGMSG("csStartOutput: unit %d, Transmit bid error (too big)\n",
	       pCS->ArpCom.ac_if.if_unit, 0,0,0,0,0 );

	    /* Loop up to transmit the next chain */
	 }
	 else
	 {
	    /* Start the TX on Rdy4Tx interrupt */
	    /* TX buff space not available now. */

	    /* Mark TX as in progress */
	    pCS->TxInProgress = TRUE;

	    if ( !pCS->InISR )
	    {
	       /* Re-enable interrupts at the CPU */
	       intUnlock( State );
	    }
	    
	    /* Exit loop */
	    break;
	 }
      }
   }
}



/*******************************************************************************
*
* csCopyTxFrame -
*
* This routine copies the packet from a chain of mbufs to the chip.  When all
* the data has been copied, then the chip automatically begins transmitting
* the data.
*
* The reason why this "simple" copy routine is so long and complicated is
* because all reads and writes to the chip must be done as 16-bit words.
* If an mbuf has an odd number of bytes, then the last byte must be saved
* and combined with the first byte of the next mbuf.  Also, some processors,
* such as the MIPS do not allow word writes to non-word aligned addresses.
*
*/

LOCAL void csCopyTxFrame( CS_SOFTC *pCS, struct mbuf *pMbufChain )
{
   struct mbuf *pMbuf;
   FAST USHORT *pFrame;
   FAST USHORT *pBuff;
   FAST USHORT *pBuffLimit;
   IOADDR TxDataPort;
   UCHAR  *pStart;
   USHORT  Length;
   BOOL HaveExtraByte;
   union
   {
      UCHAR  byte[2];
      USHORT word;
   } Straddle;

   /* Initialize frame pointer and data port address */
   pFrame = pCS->pPacketPage + (PKTPG_TX_FRAME/2);
   TxDataPort = pCS->IOAddr + PORT_RXTX_DATA;

   HaveExtraByte = FALSE;  /* Start out with no extra byte */

   /* Process the chain of mbufs */
   for ( pMbuf=pMbufChain; pMbuf!=NULL; pMbuf=pMbuf->m_next )
   {

      /* Setup starting pointer and length */
      pStart = mtod( pMbuf, UCHAR * );
      Length = pMbuf->m_len;

#if (CPU_FAMILY == MIPS || CPU_FAMILY == ARM)
      /* if the mbuf payload starts on an odd address boundary */
      if( (UINT32)pStart & 0x01 )
      {
         /* If there is an extra byte left over from the previous mbuf */
         if ( HaveExtraByte )
         {
            /* Add the first byte from this mbuf to make a word */
            Straddle.byte[1] = *pStart;
 
            /* Write the word which straddles the mbufs to the chip */
            if ( pCS->InMemoryMode )
               *pFrame++ = Straddle.word;
            else
               SYS_ENET_OUT_WORD( TxDataPort, Straddle.word );
 
            /* Adjust starting pointer and length */
            pStart++;
            Length--;

            HaveExtraByte = FALSE;
         }
         else
         {
            while( Length>=2 )
            {
               /* fetch 16 bits, 8 bits at a time */
               Straddle.byte[0] = *(UCHAR *)pStart++;
               Straddle.byte[1] = *(UCHAR *)pStart++;
    
               /* Write the word which straddles the mbufs to the chip */
               if ( pCS->InMemoryMode )
                  *pFrame++ = Straddle.word;
               else
                  SYS_ENET_OUT_WORD( TxDataPort, Straddle.word );
    
               Length -= 2;
            }
/* @kml Fixed the bug that if CPU type is MIPS, an extra byte is sent
 when an odd-aligned buffer and odd length data are passed.*/
/*            if ( Length == 1 )
            {
               HaveExtraByte = TRUE;

               // Save the extra byte for later 
               Straddle.byte[0] = *(UCHAR *)pStart++;
            }
*/
         }
      }
#endif

      /* If there is an extra byte left over from the previous mbuf */
      if ( HaveExtraByte )
      {
         /* Add the first byte from this mbuf to make a word */
         Straddle.byte[1] = *pStart;

         /* Write the word which straddles the mbufs to the chip */
         if ( pCS->InMemoryMode )
            *pFrame++ = Straddle.word;
         else
            SYS_ENET_OUT_WORD( TxDataPort, Straddle.word );
   
         /* Adjust starting pointer and length */
         pStart++;
         Length--;

#if (CPU_FAMILY == MIPS || CPU_FAMILY == ARM)
         while( Length>=2 )
         {
            /* fetch 16 bits, 8 bits at a time */
            Straddle.byte[0] = *(UCHAR *)pStart++;
            Straddle.byte[1] = *(UCHAR *)pStart++;
 
            /* Write the word which straddles the mbufs to the chip */
            if ( pCS->InMemoryMode )
               *pFrame++ = Straddle.word;
            else
               SYS_ENET_OUT_WORD( TxDataPort, Straddle.word );

            Length -= 2;
         }
#endif
      }

      /* Point pBuff to the correct starting point */
      pBuff = (USHORT *)pStart;

      /* If there are odd bytes remaining in the mbuf */
      if ( Length & 1 )
      {
         HaveExtraByte = TRUE;

         /* Point pBuffLimit to the extra byte */
         pBuffLimit = (USHORT *)(pStart+Length-1);
      }
      else  /* There is an even number of bytes remaining */
      {
         HaveExtraByte = FALSE;

         /* Point pBuffLimit to just beyond the last word */
         pBuffLimit = (USHORT *)(pStart+Length);
      }

      /* Copy the words in the mbuf to the chip */
      if ( pCS->InMemoryMode )
      {
         while ( pBuff < pBuffLimit ) 
            *pFrame++ = *pBuff++;
      }
      else
      {
         while ( pBuff < pBuffLimit ) 
            SYS_ENET_OUT_WORD( TxDataPort, *pBuff++ );
      }

      /* If there is an extra byte left over in this mbuf */
      if ( HaveExtraByte )
      {
         /* Save the extra byte for later */
         Straddle.byte[0] = *(UCHAR *)pBuff;
      }

   } /* end Process the chain of mbufs */

   /* If there is an extra byte left over from the last mbuf */
   if ( HaveExtraByte )
   {
      /* Add a zero byte to make a word */
      Straddle.byte[1] = 0;

      /* Write the last word to the chip */
      if ( pCS->InMemoryMode )
         *pFrame = Straddle.word;
      else
         SYS_ENET_OUT_WORD( TxDataPort, Straddle.word );
   }
}






/* ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ *
 * Receive-related Routines                                                *
 * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ */


/*******************************************************************************
*
* csCopyRxFrame -
*
* This routine copies a received frame from the chip to a receive buffer.
*
*/

LOCAL void csCopyRxFrame( CS_SOFTC *pCS, PRXBUF pRxBuff )
{
   FAST USHORT *pFrame;
   FAST USHORT *pBuff;
   FAST USHORT *pBuffLimit;
   FAST int RxDataPort;
   USHORT RxLength, RxStatus;

   /* Initialize the frame pointer and data port address */
   pFrame = pCS->pPacketPage + (PKTPG_RX_LENGTH/2);
   RxDataPort = pCS->IOAddr + PORT_RXTX_DATA;

   /* Get the length of the received frame */
   if ( pCS->InMemoryMode )
   {
      RxLength = *pFrame++;
      pRxBuff->Length = BYTE_SWAP( RxLength );
   }
   else  /* In IO mode */
   {
      RxStatus = SYS_ENET_IN_WORD( RxDataPort );  /* Discard RxStatus */
      RxLength = SYS_ENET_IN_WORD( RxDataPort );
      pRxBuff->Length = BYTE_SWAP( RxLength );
   }


   /* Setup pointers to the buffer for copying */
   pBuff = (USHORT *)pRxBuff->Data;
   pBuffLimit = pBuff + ((pRxBuff->Length+1)/2);

   /* Copy the frame from the chip to the buffer */
   if ( pCS->InMemoryMode )
   {
      while ( pBuff < pBuffLimit ) 
         *pBuff++ = *pFrame++;
   }
   else
   {
      while ( pBuff < pBuffLimit ) 
         *pBuff++ = SYS_ENET_IN_WORD( RxDataPort );
   }
}


/*******************************************************************************
*
* csProcessReceive -
*
* This routine processes a received packet.  The received packet was copied to
* a receive buffer at interrupt time and this routine processses the receive
* buffer at task time via netTask().
*
* If a recieve hook routine is specified, then the packet is given to the
* hook routine for processing.  If the received packet does not use trailers
* and the packet is large, then a cluster mbuf is built that points to the
* receive buffer directly.  If a cluster mbuf is not used, then the packet
* is copied to an mbuf chain.  The cluster mbuf or mbuf chain is then passed
* up to the protocol stack.
*
*/

LOCAL void csProcessReceive( CS_SOFTC *pCS, PRXBUF pRxBuff )
{
   struct ifnet *pIf;
   struct mbuf *pMbufChain;
   struct ether_header *pEtherHeader;
   UCHAR *pData;
   int DataLength;
   int Spl;
   
#ifdef BSD43_DRIVER
   int TrailerOffset;
   USHORT Type;
#endif /* BSD43_DRIVER */

 

   pIf = &pCS->ArpCom.ac_if;

   /*pIf->if_ipackets++;*/

   /* If a hook routine is specified */
   if ( etherInputHookRtn != NULL )
   {
      /* Call the hook routine */
      if ( (*etherInputHookRtn)(pIf,pRxBuff->Data,pRxBuff->Length) != 0 )
      {
         /* The hook routine has handled the received frame */
         csFreeRxBuff( pCS, pRxBuff );
         return;
      }
   }

   /* Setup working variables */
   pEtherHeader = (struct ether_header *)pRxBuff->Data;
   pData = &pRxBuff->Data[SIZEOF_ETHERHEADER];
   DataLength = pRxBuff->Length - SIZEOF_ETHERHEADER;

#ifdef BSD43_DRIVER
   /* Check if the received frame uses trailers */
   check_trailer( pEtherHeader, pData, &DataLength, &TrailerOffset, pIf );

   /* Save the type because build_cluster() will overwrite it */
   Type = pEtherHeader->ether_type;
#endif

#if (CPU_FAMILY != MIPS )
   
   /* Current VxWorks build_cluster routine causes a bus fault with the MIPS
    * processor.  Likely due to an addressing violation.
    */
#ifdef BSD43_DRIVER
   /* If trailers are not used and there is enough data for clustering */
   if ( (TrailerOffset==0) && USE_CLUSTER(DataLength) )
#else
   if ( USE_CLUSTER(DataLength) )
#endif /* BSD43_DRIVER */
   {
      /* Build a cluster mbuf that points to my receive buffer */
      Spl = splnet( );
      pMbufChain = build_cluster( pData, DataLength, pIf, MC_LOANED,
         &pRxBuff->RefCount, (FUNCPTR)csFreeRxBuff, (int)pCS, (int)pRxBuff, 0 );
      splx( Spl );
      if ( pMbufChain != NULL )
      {
         pRxBuff->Status = RXBUF_LOANED;
         pCS->LoanCount++;
      }
      else 
      {
	 csFreeRxBuff( pCS, pRxBuff );
      }
   }
   else  /* Can not do clustering */

#endif

   {
      /* Copy the received data to a chain of mbufs */
      Spl = splnet( );

#ifdef BSD43_DRIVER
      pMbufChain = copy_to_mbufs( pData, DataLength, TrailerOffset, pIf );
#else
      pMbufChain = copy_to_mbufs( pData, DataLength, 0, pIf ); /*Cannot use Trailer*/ 
#endif

      splx( Spl );
      csFreeRxBuff( pCS, pRxBuff );
   }

   /* If could not get an mbuf */
   if ( pMbufChain == NULL )
   {
      pIf->if_ierrors++;
      LOGMSG( "csProcessReceive: unit %d, No receive mbuf available\n",
         pCS->ArpCom.ac_if.if_unit, 0,0,0,0,0 );
      return;
   }

   /* Pass the mbuf chain up to the protocol stack */
   Spl = splnet( );

   /* @kml */
   pIf->if_ipackets++;

#ifdef BSD43_DRIVER
    do_protocol_with_type(Type, pMbufChain, &pCS->ArpCom, DataLength);
#else /* BSD4.4 DRIVER */
    do_protocol(pEtherHeader, pMbufChain, &pCS->ArpCom, DataLength);
#endif /* BSD4.4 DRIVER */

   splx( Spl );
}




/*******************************************************************************
*
* csInitRxBuff -
*
* This routine initializes the network interface driver's collection of
* receive buffers.  The receive buffers are allocated from system memory
* and linked together in a linked list of free receive buffers.
*
*/

LOCAL STATUS csInitRxBuff( CS_SOFTC *pCS )
{
   PRXBUF pRxBuff;
   PRXBUF pRxLast;

   /* Allocate the receive frame buffers */
   pCS->pFreeRxBuff = (PRXBUF)malloc( sizeof(RXBUF)*CS_NUM_RX_BUFFERS );
   if ( pCS->pFreeRxBuff == NULL ) 
   {
     return ERROR;
   }

   /* Link all the receive frame buffers together on the free list */
   pRxLast = pCS->pFreeRxBuff + CS_NUM_RX_BUFFERS - 1;
   for ( pRxBuff=pCS->pFreeRxBuff; pRxBuff<pRxLast; pRxBuff++ )
   {
      pRxBuff->pNext  = pRxBuff+1;
      pRxBuff->Status = RXBUF_FREE;
   }
   pRxLast->pNext  = NULL;
   pRxLast->Status = RXBUF_FREE;

   return OK;
}



/*******************************************************************************
*
* csAllocRxBuff -
*
* This routine removes a receive buffer from the free receive buffer list.
*
*/

LOCAL PRXBUF csAllocRxBuff( CS_SOFTC *pCS )
{
   PRXBUF pRxBuff;

   if ( pCS->pFreeRxBuff == NULL ) 
   {
     return NULL;
   }

   /* Remove a buffer from the free list */
   pRxBuff = pCS->pFreeRxBuff;
   pCS->pFreeRxBuff = pRxBuff->pNext;
   pRxBuff->pNext = NULL;

   /* Init the reference count to zero */
   pRxBuff->RefCount = 0;

   /* The buffer is now allocated */
   pRxBuff->Status = RXBUF_ALLOCATED;

   /* Increment number of receive buffers currently in use */
   pCS->RxDepth++;
   if ( pCS->RxDepth > pCS->MaxRxDepth )
   {
      pCS->MaxRxDepth = pCS->RxDepth;
   }

   return pRxBuff;
}



/*******************************************************************************
*
* csFreeRxBuff -
*
* This routine returns an allocated receive buffer back to the free list.
*
*/

LOCAL void csFreeRxBuff( CS_SOFTC *pCS, PRXBUF pRxBuff )
{
   int IntState;

   /* Disable interrupts at the CPU so csAllocRxBuff() will not interrupt */
   IntState = intLock();

   /* Put the buffer at the head of the free list */
   pRxBuff->pNext = pCS->pFreeRxBuff;
   pCS->pFreeRxBuff = pRxBuff;

   /* The buffer is now free */
   pRxBuff->Status = RXBUF_FREE;

   /* Decrement the outstanding receive depth */
   pCS->RxDepth--;

   /* Re-enable interrupts at the CPU */
   intUnlock( IntState );

}




/* ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ *
 * Misc. Routines                                                          *
 * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ */



/*******************************************************************************
* csInitQueue -
*
* Initializes an array-implemented circular queue.
*
* RETURNS: Nothing.
*
*/
LOCAL void csInitQueue( CIR_QUEUE *Q )
{
   Q->Head = Q->Tail = 0;
}



/*******************************************************************************
* csQueueEmpty -
*
* Checks the queue's status.
*
* RETURNS: TRUE if queue is empty, FALSE if queue is not empty.
*
*/

LOCAL BOOL csQueueEmpty( CIR_QUEUE *Q )
{
   if( Q->Head == Q->Tail )
      return TRUE;  /* Queue is empty */
   else
      return FALSE;
}




/*******************************************************************************
* csDequeue -
*
* This routine removes a pointer to a value from the end off an 
* array-implemented circular queue.  Assumes the queue is not empty.
*
* RETURNS: Pointer to the dequeued value.
*
*/
LOCAL void *csDequeue( CIR_QUEUE *Q )
{
   FAST void  *Element;

   Element = Q->Queue[Q->Head];
   Q->Head = (Q->Head == CS_MAX_QUEUE) ? 0 : (Q->Head + 1);
   return Element;

}



/*******************************************************************************
* csEnqueue -
*
* This routine adds a pointer to a value to the front of an array-implmented
* circular queue.
*
* RETURNS: OK, or ERROR if the enqueue would cause a queue overflow.
*
*/
LOCAL STATUS csEnqueue( CIR_QUEUE *Q, void *pBuff )
{
   /* If queue is full return ERROR */
   if ( Q->Tail == ((Q->Head == 0) ? CS_MAX_QUEUE : (Q->Head -1)) )
   {
      LOGMSG("csEnqueue: unit %d, Queue Overflow\n",
         0,0,0,0,0,0 );
      return ERROR;    /* Queue overflow */
   }

   /* Else, add data to the queue and return OK */
   Q->Queue[Q->Tail] = pBuff;
   Q->Tail = (Q->Tail == CS_MAX_QUEUE) ? 0 : (Q->Tail + 1);

   return OK;
}



/*******************************************************************************
*
* csVerifyChip -
*
* This routine verifies that the Ethernet chip is present and correct.
*
*/

LOCAL STATUS csVerifyChip( CS_SOFTC *pCS )
{
   USHORT wrVal, rdVal;
   USHORT errorCount = 0;
   USHORT x;

   /* Verify that we can read from the chip */
   x = csReadPacketPage( pCS, PKTPG_EISA_NUM );
   if ( x == 0xFFFF )
   {
      LOGMSG("csInit: unit %d, can't read from chip (I/O address correct?)\n",
         pCS->ArpCom.ac_if.if_unit, 0,0,0,0,0 );
      return ERROR;
   }

   /* Verify that the chip is a Crystal Semiconductor chip */
   if ( x != EISA_NUM_CRYSTAL )
   {
      LOGMSG("csInit: unit %d, Chip is not a Crystal Semiconductor chip\n",
         pCS->ArpCom.ac_if.if_unit, 0,0,0,0,0 );
      return ERROR;
   }

   /* Verify that the chip is a CS8900 */
   x = csReadPacketPage(pCS,PKTPG_PRODUCT_ID);
   x &= PROD_ID_MASK;
   if ( x != PROD_ID_CS8900)
   {
      LOGMSG("csInit: unit %d, Chip is not a CS8900p\n",
         pCS->ArpCom.ac_if.if_unit, 0,0,0,0,0 );
      return ERROR;
   }

    /* walk a one in the memory of the enet controller */
    for( wrVal = 0x0001; wrVal != 0; wrVal <<= 1 )
    {
 
      for( x=0x150; x<= 0x15d; x+=2 )
      {
        /* write out value - don't swap bytes */
        csWritePacketPage( pCS, x, wrVal );
   
        /* read back value - don't swap bytes */
        rdVal = csReadPacketPage( pCS, x );
  
        if( wrVal != rdVal )
        {
          if( errorCount <=10 )
          {
            LOGMSG("csVerifyChip:  ERROR reg %04X, wrVal %04X, rdVal %04X\n",
              x, 
              (unsigned int) BYTE_SWAP(wrVal), 
              (unsigned int) BYTE_SWAP(rdVal),0,0,0 );
          }
          errorCount++;
        }
      }
    } /* end walking one test */

    /* write incrementing value test */
    for( x=0x150, wrVal=0x0101; x<= 0x15d; x+=2, wrVal+=0x0101 )
    {
      /* write out value - don't worry about swapping bytes */
      csWritePacketPage( pCS, x, wrVal );
    } 

    /* read incrementing value test */
    for( x=0x150, wrVal=0x0101; x<= 0x15d; x+=2, wrVal+=0x0101 )
    {
      /* read back value - don't worry about swapping bytes */
      rdVal = csReadPacketPage( pCS, x );
 
      if( wrVal != rdVal )
      {
        LOGMSG("\ncsVerifyChip:  ERROR reg %04X, wrVal %04X, rdVal %04X\n",
              x, 
              (unsigned int) BYTE_SWAP(wrVal), 
              (unsigned int) BYTE_SWAP(rdVal),0,0,0 );
        errorCount++;
      }
    } /* end walking one test */

    if( errorCount != 0 )
    {
      LOGMSG("csVerifyChip: ERROR SRAM test failed, errorCount %d\n", 
        errorCount,0,0,0,0,0 );
      return( ERROR );
    }

   return OK;
}



/*******************************************************************************
*
* csInitChip -
*
* This routine uses the instance global variables in the cs_softc structure to
* initialize the CS890.
*
*/

LOCAL void csInitChip( CS_SOFTC *pCS )
{
   PIA    pIA;
   USHORT RxCtl;/*Promiscuous@kml*/

   /* Configure the adapter for board-specific IO and media type support */
   sysEnetHWInit( pCS );

   /* Initialize the config and control registers */
   csWritePacketPage( pCS, PKTPG_RX_CFG, RX_CFG_ALL_IE );
   csWritePacketPage( pCS, PKTPG_RX_CTL,
         RX_CTL_RX_OK_A | RX_CTL_IND_A | RX_CTL_BCAST_A | RX_CTL_MCAST_A);
   csWritePacketPage( pCS, PKTPG_TX_CFG, TX_CFG_ALL_IE );
   csWritePacketPage( pCS, PKTPG_BUF_CFG, BUF_CFG_ALL_IE ); 

   /* Put Ethernet address into the Individual Address register */
   pIA = (PIA)pCS->ArpCom.ac_enaddr;
   csWritePacketPage( pCS, PKTPG_IND_ADDR,   pIA->word[0] );
   csWritePacketPage( pCS, PKTPG_IND_ADDR+2, pIA->word[1] );
   csWritePacketPage( pCS, PKTPG_IND_ADDR+4, pIA->word[2] );

   /* Set the interrupt level in the chip */
   if ( pCS->IntLevel == 5 )
      csWritePacketPage( pCS, PKTPG_INT_NUM, BYTE_SWAP(3) );
   else
      csWritePacketPage( pCS, PKTPG_INT_NUM, BYTE_SWAP( (pCS->IntLevel)-10 ) );

   /* Promiscuous@kml If need to enable the promiscuous mode */
   if ( pCS->ConfigFlags & CFGFLG_PROMISC_MODE ) {
	  RxCtl=csReadPacketPage(pCS,PKTPG_RX_CTL);
      RxCtl |= (RX_CTL_PROM_A|RX_CTL_MCAST_A|RX_CTL_RX_OK_A | RX_CTL_IND_A | RX_CTL_BCAST_A);
      csWritePacketPage( pCS, PKTPG_RX_CTL, RxCtl );

	  LOGMSG ("csInitChip() Setting promiscuous mode on!\n", 0, 0, 0, 0, 0, 0);
   } else {
	  LOGMSG ("csInitChip() Setting promiscuous mode off!\n", 0, 0, 0, 0, 0, 0);
   }

     
   /* Enable reception and transmission of frames */
   csWritePacketPage( pCS, PKTPG_LINE_CTL,
   csReadPacketPage(pCS,PKTPG_LINE_CTL) | LINE_CTL_RX_ON | LINE_CTL_TX_ON );

   /* Enable interrupt at the chip */
   csWritePacketPage( pCS, PKTPG_BUS_CTL,
   csReadPacketPage(pCS,PKTPG_BUS_CTL) | BUS_CTL_INT_ENBL );
}



/*******************************************************************************
*
* csResetChip -
*
* This routine resets the CS8900 chip.
*
*/

LOCAL STATUS csResetChip( CS_SOFTC *pCS )
{
   int y;
   int x;
   UCHAR dummyVal;

   LOGMSG("csResetChip: unit %d, Reseting the chip......\n",
         pCS->ArpCom.ac_if.if_unit,0,0,0,0,0);

/*@kml assign an initial values to avoid "unused variable" warning when compiling*/
   x=0;
   dummyVal=0;
   
#ifdef HARD_RESET
   /* Disable interrupts at the CPU so reset command is atomic */
   y = intLock();

   /* We are now resetting the chip */
   /* A spurious interrupt is generated by the chip when it is reset. */
   /* This variable informs the interrupt handler to ignore this interrupt. */
   pCS->Resetting = TRUE;

   /* Issue a reset command to the chip */
   csWritePacketPage( pCS, PKTPG_SELF_CTL, SELF_CTL_RESET );

   /* Re-enable interrupts at the CPU */
   intUnlock( y );

   /* If transmission was in progress, it is not now */
   pCS->TxInProgress = FALSE;
   pCS->pTxFrameChain = NULL;

   /* The chip is always in IO mode after a reset */
   pCS->InMemoryMode = FALSE;

   /* Initialize locale flag */
   pCS->InISR = FALSE;

   /* Delay for 125 micro-seconds (one eighth of a second) */
   taskDelay( sysClkRateGet()/8 );

   /* Transition SBHE to switch chip from 8-bit to 16-bit */
   dummyVal = SYS_ENET_IN_BYTE( (pCS->IOAddr)+PORT_PKTPG_PTR );
   dummyVal = SYS_ENET_IN_BYTE( (pCS->IOAddr)+PORT_PKTPG_PTR+1 );
   dummyVal = SYS_ENET_IN_BYTE( (pCS->IOAddr)+PORT_PKTPG_PTR );
   dummyVal = SYS_ENET_IN_BYTE( (pCS->IOAddr)+PORT_PKTPG_PTR+1 );

   /* If EEPROM present, wait up to 125 mSec for EEPROM not busy*/
   y = sysClkRateGet()/8;
   for ( x=0; x<y; x++ )
   {
      if( !(csReadPacketPage(pCS,PKTPG_SELF_ST)&SELF_ST_SI_BUSY) )
         break;
   }
   if ( x == y )
      return ERROR;

   /* Wait up to 125 mSec for initialization is become done */
   for ( x=0; x<y; x++ )
   {
      if ( csReadPacketPage(pCS,PKTPG_SELF_ST)&SELF_ST_INIT_DONE )
         break;
   }
   if ( x == y )
      return ERROR;

   /* Reset is no longer in progress */
   pCS->Resetting = FALSE;

   return OK;
#else
   /* Disable interrupts at the CPU so reset command is atomic */
   y = intLock();

   pCS->Resetting = TRUE;
   /* Disable RX and TX */
   csWritePacketPage(pCS,PKTPG_LINE_CTL, csReadPacketPage(pCS, PKTPG_LINE_CTL) & ~(LINE_CTL_RX_ON | LINE_CTL_TX_ON));

   /* @kml Disable interrupt at the chip to avoid no detection of 
           interrupts by OS when the chip restarts. */
   csWritePacketPage( pCS, PKTPG_BUS_CTL,
           csReadPacketPage(pCS,PKTPG_BUS_CTL) & ~BUS_CTL_INT_ENBL );

   /* issue some skip commands to clear out any incoming frames */
  csWritePacketPage(pCS,PKTPG_RX_CFG, csReadPacketPage(pCS, PKTPG_RX_CFG) | RX_CFG_SKIP);
  csWritePacketPage(pCS,PKTPG_RX_CFG, csReadPacketPage(pCS, PKTPG_RX_CFG) | RX_CFG_SKIP);
  csWritePacketPage(pCS,PKTPG_RX_CFG, csReadPacketPage(pCS, PKTPG_RX_CFG) | RX_CFG_SKIP);

   /* @kml Comment out to avoid TX_UnderRun Interrupt */
  /*issue some force commands to clean out anything in the tx part of the chip */
  /*SYS_ENET_OUT_WORD( (pCS->IOAddr)+PORT_TX_CMD, TX_CMD_FORCE );
  SYS_ENET_OUT_WORD( (pCS->IOAddr)+PORT_TX_LENGTH, 0x0000); 
  SYS_ENET_OUT_WORD( (pCS->IOAddr)+PORT_TX_CMD, TX_CMD_FORCE );
  SYS_ENET_OUT_WORD( (pCS->IOAddr)+PORT_TX_LENGTH, 0x0000);
  */

  /* Re-enable interrupts at the CPU */
   intUnlock( y );

   /* If transmission was in progress, it is not now */
   pCS->TxInProgress = FALSE;
   pCS->pTxFrameChain = NULL;

   /* The chip is always in IO mode after a reset */
   pCS->InMemoryMode = FALSE;

   /* Initialize locale flag */
   pCS->InISR = FALSE;

   /* Reset is no longer in progress */
   pCS->Resetting = FALSE;

   return OK;

#endif
}


/*******************************************************************************
*
* csReadPacketPage -
*
* This routine reads a word from the PacketPage at the specified offset.
*
*/

LOCAL USHORT csReadPacketPage( CS_SOFTC *pCS, USHORT Offset )
{
   if ( pCS->InMemoryMode )
   {
      return *((pCS->pPacketPage)+(Offset/2));
   }
   else  /* In IO mode */
   {
      Offset = BYTE_SWAP( Offset );
      SYS_ENET_OUT_WORD( (pCS->IOAddr)+PORT_PKTPG_PTR, Offset );
      return SYS_ENET_IN_WORD( (pCS->IOAddr)+PORT_PKTPG_DATA );
   }
}


/*******************************************************************************
*
* csWritePacketPage -
*                                                                                                                             *
* This routine writes a value to the PacketPage at the specified offset.
* 
* The offset is byte swapped if needed before writing to the PacketPage
* pointer.  The value is not byte swapped here. It must be byte swapped
* in the call to this function if byte swapping is required (it is not for 
* frame data).
*
*/

LOCAL void csWritePacketPage( CS_SOFTC *pCS, USHORT Offset, USHORT Value )
{
   if ( pCS->InMemoryMode )
   {
      *((pCS->pPacketPage)+(Offset/2)) = Value;
   }
   else  /* In IO mode */
   {
      Offset = BYTE_SWAP( Offset );
      SYS_ENET_OUT_WORD( (pCS->IOAddr)+PORT_PKTPG_PTR, Offset );
      SYS_ENET_OUT_WORD( (pCS->IOAddr)+PORT_PKTPG_DATA, Value );
   }
}



/*******************************************************************************
*
* csShow -
*
* This routine displays configuration and statistical information about the
* network interface driver.  This routine is usually invoked from the shell.
* If the Zap parameter is not zero, then all statistics are reset to zero.
*
*/

void csShow( int Unit, BOOL Zap )
{
   FAST CS_SOFTC *pCS;
   struct ifnet *pIf;
   USHORT RxMisses;
   USHORT Collisions;

   if ( Unit >= CS_MAX_NUM_UNITS )
   {
      printf("cs%d - Invalid unit number\n", Unit );
      return;
   }

   pCS = &cs_softc[Unit];
   pIf = &pCS->ArpCom.ac_if;

   /* Read the Rx Miss count. */
   RxMisses = csReadPacketPage( pCS, PKTPG_RX_MISS ); 
   RxMisses = (BYTE_SWAP( RxMisses )) >> 6; /* 6 LSBs are register number */

   /* Add the RX miss count to the input error counter */
   pIf->if_ierrors += RxMisses;

   /* Read the collision count. */
   Collisions = csReadPacketPage( pCS, PKTPG_TX_COL ); 
   Collisions = (BYTE_SWAP( Collisions )) >> 6; /* 6 LSBs are register number */

   /* Add the collision count to the collision counter */
   pIf->if_collisions = (pIf->if_collisions + Collisions);

   if ( Zap )
   {
      /* Reset all the statistics to zero */
      pIf->if_ipackets   = 0;
      pIf->if_opackets   = 0;
      pIf->if_ierrors    = 0;
      pIf->if_oerrors    = 0;
      pIf->if_collisions = 0;

      /* Reset counters to zero */
      pCS->TotalTxUnderruns = 0;
      pCS->Rdy4TxInts       = 0;
      pCS->RxDepth          = 0;
      pCS->MaxRxDepth       = 0;
      pCS->MaxTxDepth       = 0;
      pCS->LoanCount        = 0;

#ifdef CS_DEBUG_ENABLE
   printf("Current TXQ Depth: %d\n", pCS->TxQueueDepth );
   printf("Max TXQ Depth    : %d\n", pCS->MaxTxQueueDepth );
#endif
   
   }

   printf("Show cs%d: ", Unit );
   printf("Crystal Semiconductor CS8900 %s Driver Ver. %s\n",
     CS_BSP_TYPE, CS_DRIVER_VER);
   printf("\n");
   printf("I/O Address      : 0x%lX\n", (u_long)pCS->IOAddr );
   printf("Interrupt Level  : %d\n",   pCS->IntLevel );
   printf("Interrupt Vector : %d\n",   pCS->IntVector );
   printf("Access Mode      : ");
   if ( pCS->InMemoryMode )
   {
      printf("Memory Mode\n");
      printf("Memory Address   : 0x%lX\n", (u_long)pCS->pPacketPage );
   }
   else printf("I/O Mode\n");

   printf("TX Start Command : 0x%04X\n",pCS->TxStartCMD );

   printf("Media Type       : ");
   switch ( pCS->MediaType )
   {
      case MEDIA_AUI:
         printf("AUI\n");
         break;
      case MEDIA_10BASE2:
         printf("10Base2\n");
         break;
      case MEDIA_10BASET:
         if ( pCS->ConfigFlags & CFGFLG_FDX )
            printf("10BaseT, FDX\n");
         else
            printf("10BaseT\n");
         break;
      default:
         printf("Unknown\n");
         break;
   }

   printf("Interface Flags  : ");
   if ( pIf->if_flags & IFF_UP ) printf("UP"); else printf("DOWN");
   if ( pIf->if_flags & IFF_RUNNING )     printf(", RUNNING");
   if ( pIf->if_flags & IFF_BROADCAST )   printf(", BROADCAST");
   if ( pIf->if_flags & IFF_LOOPBACK )    printf(", LOOPBACK");
   if ( pIf->if_flags & IFF_POINTOPOINT ) printf(", POINTOPOINT");
   if ( pIf->if_flags & IFF_NOTRAILERS )  printf(", NOTRAILERS");
   if ( pIf->if_flags & IFF_NOARP )       printf(", NOARP");
   if ( pIf->if_flags & IFF_PROMISC )     printf(", PROMISC");
#ifndef BSD43_DRIVER
   if ( pIf->if_flags & IFF_ALLMULTI )    printf(", ALLMULTI");
   if ( pIf->if_flags & IFF_MULTICAST )    printf(", MULTICAST");
#endif
   printf("\n");

   printf("Input Packets    : %d\n", (int) pIf->if_ipackets );
   printf("Output Packets   : %d\n", (int) pIf->if_opackets );
   printf("Input Errors     : %d\n", (int) pIf->if_ierrors  );
   printf("Output Errors    : %d\n", (int)pIf->if_oerrors  );
   printf("Collisions       : %d\n", (int)pIf->if_collisions );
   printf("Tx Underruns     : %d\n", pCS->TotalTxUnderruns );
   printf("Rdy4TX Int Count : %d\n", pCS->Rdy4TxInts );
   printf("Current Tx Depth : %d\n", pIf->if_snd.ifq_len );
   printf("Current Rx Depth : %d\n", pCS->RxDepth );
   printf("Maximum Tx Depth : %d\n", pCS->MaxTxDepth );
   printf("Maximum Rx Depth : %d\n", pCS->MaxRxDepth );
   printf("Loan Count       : %d\n", pCS->LoanCount );

#ifdef CS_DEBUG_ENABLE
   printf("Current TXQ Depth: %d\n", pCS->TxQueueDepth );
   printf("Max TXQ Depth    : %d\n", pCS->MaxTxQueueDepth );
#endif
   
   printf("\n");
}



#ifdef CS_DEBUG_ENABLE

STATUS csHistoryInit( void )
{

  /* initialize history */
  csHistoryIndex = 0;
  bzero( (char *)&csHistory, sizeof(csHistory) );

  return(OK);
}



STATUS csHistoryShow( void )
{
  int i;

  if( csHistoryIndex == 0 )
    return(OK);

  for( i=(csHistoryIndex-1); i>=0; i-- )
  {
    printf("%d %08X %08X %08X %08X\n", 
      i,
      csHistory[i].arg1,
      csHistory[i].arg2,
      csHistory[i].arg3,
      csHistory[i].arg4 );
  }

  return(OK);
}
    
    
STATUS csHistoryAdd( UINT32 arg1, UINT32 arg2, UINT32 arg3, UINT32 arg4 )
{

  if( csHistoryIndex < CS_HISTORY_SIZE )
  {
      csHistory[ csHistoryIndex ].arg1 = arg1;
      csHistory[ csHistoryIndex ].arg2 = arg2;
      csHistory[ csHistoryIndex ].arg3 = arg3;
      csHistory[ csHistoryIndex ].arg4 = arg4;

      csHistoryIndex++;
  }

  return(OK);
}

#endif /* CS_DEBUG_ENABLE */



#ifndef BSD43_DRIVER

/******************************************************************************
*
* csCalculateHashIndex()
*
******************************************************************************/

LOCAL USHORT csCalculateHashIndex( UCHAR *pMulticastAddr )
{
   UCHAR  HashIndex;
   UCHAR  AddrByte;
   int   Byte;
   int   Bit, j;

   /* Prime the CRC */
   for (j = 0; j < 32; j++ ) CRC[j] = 1;

   /* For each of the six bytes of the multicast address */
   for ( Byte=0; Byte<6; Byte++ )
   {
      AddrByte = *pMulticastAddr++;

      /* For each bit of the byte */
      for ( Bit=0; Bit<8; Bit++ )
      {
         updateCrc( (AddrByte >> Bit) & 1 );
      }
   }

   /* Take the least significant six bits of the CRC and copy them */
   /* to the HashIndex in reverse order.                           */
   HashIndex = 0;
   for( Bit=0,HashIndex=0; Bit<6; Bit++ )
   {
      HashIndex = (HashIndex << 1) + CRC[Bit];
   }

   return HashIndex;

} /* end of CalculateHashIndex() */


/***********************************************************************/
LOCAL void updateCrc( USHORT bit )
{
	int j;

   /* >> 1 the crc, use high bit (now CRC[32]) as control bit */
   for (j = 32; j > 0; j--) CRC[j] = CRC[j - 1];
   CRC[0] = 0;

   /* if bit ^ (control bit) = 1, set CRC = CRC ^ polynomial */
   if (bit ^ CRC[32])
   {
   	for ( j = 0; j < 32; j++)
      {
         CRC[j] ^= CRC_Poly[j];
      }
   }
}

/******************************************************************************
*
* csMcastAdd - Add one Multicast address
*
*******************************************************************************
*/

LOCAL void csMCastAdd(CS_SOFTC *pCS, char *pData){
   USHORT  MulticastTable[4];
   UCHAR   HashIndex;
   int i;

   HashIndex=csCalculateHashIndex((UCHAR *)pData);

   /* Disable RX and TX */
   csWritePacketPage(pCS,PKTPG_LINE_CTL, 
	    csReadPacketPage(pCS,PKTPG_LINE_CTL) & ~(LINE_CTL_RX_ON|LINE_CTL_TX_ON));

   /* Read the Multicast filter table from the chip */
   for (i=0; i<4; i++) {
     MulticastTable[i]=csReadPacketPage(pCS,PKTPG_LOGIC_ADDRESS_FILTER+i*2);
   }
 
   /* Set the bit of the multicast address ON */
   MulticastTable[ HashIndex/16]  |=  1 << (HashIndex%16);  

  /* Write the Multicast filter table to the chip */
  for (i=0; i<4; i++) {
     csWritePacketPage(pCS,PKTPG_LOGIC_ADDRESS_FILTER+i*2, MulticastTable[i]);
  }

  /* Enable reception and transmission of frames */
  csWritePacketPage( pCS, PKTPG_LINE_CTL,
       csReadPacketPage(pCS,PKTPG_LINE_CTL) | LINE_CTL_RX_ON | LINE_CTL_TX_ON );

}



/******************************************************************************
*
* csMcastDel - Delete one Multicast address
*
*******************************************************************************
*/

LOCAL void csMCastDel(CS_SOFTC *pCS, char *pData){
   USHORT  MulticastTable[4];
   UCHAR   HashIndex;
   int i;

   HashIndex=csCalculateHashIndex((UCHAR *)pData);

   /* Disable RX and TX */
   csWritePacketPage(pCS,PKTPG_LINE_CTL, 
	    csReadPacketPage(pCS,PKTPG_LINE_CTL) & ~(LINE_CTL_RX_ON|LINE_CTL_TX_ON));

   /* Read the Multicast filter table from the chip */
   for (i=0; i<4; i++) {
     MulticastTable[i]=csReadPacketPage(pCS,PKTPG_LOGIC_ADDRESS_FILTER+i*2);
   }
 
   /* Set the bit of the multicast address OFF */
   MulticastTable[ HashIndex/16]  &= (~(1 << (HashIndex%16)));       
 
   /* Write the Multicast filter table to the chip */
   for (i=0; i<4; i++) {
     csWritePacketPage(pCS,PKTPG_LOGIC_ADDRESS_FILTER+i*2,MulticastTable[i]);
   }

   /* Enable reception and transmission of frames */
   csWritePacketPage( pCS, PKTPG_LINE_CTL,
       csReadPacketPage(pCS,PKTPG_LINE_CTL) | LINE_CTL_RX_ON | LINE_CTL_TX_ON );

}


#endif  /* non-define BSD4.3 */